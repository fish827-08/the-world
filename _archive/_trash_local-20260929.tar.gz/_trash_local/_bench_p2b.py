"""P2② A/B 基准：移动决策快路径（on）vs 参考逐个体循环（off），T4 同款配置。

⚠️ 夹具说明（诚实边界）：T4 真轨迹前 25 tick 就会从 N≈3000 崩到 ≈870（P1 §注）⇒
**逐个体成本测不准**。故本夹具每 tick 把能量钉住（`_energy` 保底）以维持 N≈3000 与
高移动者比例 ⇒ 测的是「同 N 下移动决策段」的成本，**不是**生态轨迹成本。
配置本身与 T4 逐字段一致（`experiments/p1_profile.make_cfg` + `apply_post_build`，k=2.5）。

用法：.venv\\Scripts\\python.exe _trash_local/_bench_p2b.py [--ticks 60]
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from simulation.sphere_engine import SphereEngine            # noqa: E402
from experiments.p1_profile import make_cfg                  # noqa: E402
from experiments.scaling_rescale import apply_post_build     # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def bench(fast: bool, ticks: int, warm: int, args) -> dict:
    cfg, notes = make_cfg(args.seed, args.rows, args.cols, args.pop, args.patches,
                          False, True, args.speed_max, args.gain, args.subdiv,
                          args.k, args.max_count)
    eng = SphereEngine(cfg)
    apply_post_build(eng, notes)
    eng._batch_move_on = bool(fast)

    n_batches = 0
    orig = SphereEngine._move_decide_batch

    def counting(self, *a, **k):
        nonlocal n_batches
        n_batches += 1
        return orig(self, *a, **k)

    SphereEngine._move_decide_batch = counting
    try:
        def pin() -> None:
            eng._energy[:] = np.maximum(eng._energy, 300.0)

        pin()
        for _ in range(warm):
            eng.step()
            pin()
        t0 = time.perf_counter()
        for _ in range(ticks):
            eng.step()
            pin()
        dt = time.perf_counter() - t0
    finally:
        SphereEngine._move_decide_batch = orig
    ms = dt / ticks * 1000.0
    n = len(eng._id)
    return {"fast": fast, "ms_tick": ms, "N": n, "us_ind": ms * 1000.0 / max(n, 1),
            "n_batches": n_batches, "ticks": ticks}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--rows", type=int, default=480)
    ap.add_argument("--cols", type=int, default=960)
    ap.add_argument("--pop", type=int, default=3000)
    ap.add_argument("--patches", type=int, default=480)
    ap.add_argument("--speed-max", dest="speed_max", type=float, default=0.125)
    ap.add_argument("--gain", type=float, default=0.125)
    ap.add_argument("--subdiv", type=int, default=80)
    ap.add_argument("--k", type=float, default=2.5)
    ap.add_argument("--max-count", dest="max_count", type=int, default=30000)
    ap.add_argument("--ticks", type=int, default=60)
    ap.add_argument("--warm", type=int, default=10)
    a = ap.parse_args()

    rows: list[dict] = []
    for fast in (False, True):
        t0 = time.time()
        r = bench(fast, a.ticks, a.warm, a)
        r["wall_s"] = time.time() - t0
        rows.append(r)
        tag = "快路径 on " if fast else "参考循环 off"
        print(f"[{tag}] {r['ms_tick']:.1f} ms/tick | N={r['N']} | "
              f"{r['us_ind']:.2f} μs/体 | 批调用 {r['n_batches']} | 夹具耗时 {r['wall_s']:.0f}s",
              flush=True)

    off, on = rows[0], rows[1]
    sp = off["ms_tick"] / max(on["ms_tick"], 1e-9)
    print(f"\n加速比（整 tick）: {off['ms_tick']:.1f} → {on['ms_tick']:.1f} ms "
          f"= **{sp:.2f}×**（省 {off['ms_tick'] - on['ms_tick']:.1f} ms/tick）")
    print(f"构成核查: 快路径批调用 = {on['n_batches']}/{a.ticks + a.warm} tick"
          f"（含 warm；参考臂 = {off['n_batches']} ⇒ 应为 0）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
