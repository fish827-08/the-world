**T-G 补交：`_step_corpse_decay` 全场调用 profile（v1 前置数据）＋ 一处口径更正**

派工：R233 §七 T-G（T-F 已于 `d82bb21` 交付）。提交：`dacf30d`（已 push；`ls-remote` 对账一致）。
文件：`experiments/corpse_call_profile.py`（新，一条命令可重跑：`python experiments/corpse_call_profile.py`）。
**生产代码未动**（T-G 只出数据；子集化留 v1）。

## 一、实测（S2 同款档 + corpse 开；1500 tick；本机静默、单进程、同种子同 N）

- **调用量**：`bo>0` 占 **84.0%**（1260/1500 tick）—— 几乎每 tick 都在付全场代价；
  `|bo|` 中位 **69** / 均值 73.5 / p95 127 / max 133 ⇒ 子集/全场 ≈ **0.016%**
  （全场 460 800 格 ⇒ 白算 ≈ 6600×）
- **逐位等价**：两版 digest（grid / corpse_boost / corpse_energy / corpse_age / decayed_e / tick / N / ΣE）
  **1500/1500 全等** ⇒ 子集化是**纯优化，零行为风险**
- **配对 ms/tick**（每 50 tick 均值）：`bo>0` 窗口 原版 **80.84** vs 子集 **54.93** ⇒ **Δ 25.91 ms/tick**
  （全窗口 Δ 23.77）。⚠️ 口径：同窗对照 `bo==0` 窗口 Δ **9.89**（应 ~0）= 顺序两臂的漂移
  ⇒ 保守取**漂移校正值 ≈ 16 ms/tick**。墙钟：原版 119 s vs 子集 83 s（两臂都含每 tick 采样哈希开销）
- **外推 [外推，按本机实测]**：`bo>0` 占 84% ⇒ **60k 单 run 省 ≈ 13–22 分钟**（取 Δ 16 或 25.9）

**改动量**：`_regrowth_amount(tick, idx)` 子集接口 R217 已有 ⇒ **~3 行**（与腐烂分支同款
`np.flatnonzero(bo)` 写法；prototype 见脚本内 `step_corpse_decay_subset`）。

## 二、🔴 口径更正：「S2 本体是 corpse 开的臂」**不成立**（影响 v1 排期）

R233/T-D 备注里这条经核**与代码不符**：
- `corpse_enabled` **默认 False**；S2 线脚本（`s2_depletion_probe.py` / `steady_k_probe.py`）**都不开 corpse**；
  开 corpse 的是 **A4 线**（`a4_verify_capacity.py --corpse-enabled`）与 `p1corpse` preset。
- 附实测（S2 同款、**corpse 关**，300 tick）：corpse 路径 `_regrowth_amount` 调用 **0 次**、
  `_corpse_boost/_corpse_energy` 恒 0；`_step_corpse_decay` 关档残留 **0.185 ms/tick**（两条全场掩码比较）。

⇒ **结论**：corpse 子集化**不在旗舰 60k 的关键路径上**（旗舰 corpse 关）；上表收益只对 corpse 开臂
（A4 / p1corpse / 未来 corpse 系实验）成立。v1 排期请按此**降权或独立成项** —— 压 rd 档成本的仍是
资源再生子集化主项。

## 三、下一步（明晚 v1）

- **主项**：rd 再生子集化（T-D 三改动）＋ 预登记验收：① digest 逐 tick 对拍 ② 分母补算靶向单测
  ③ `rd ∧ sparse ⇒ bgzero` 构造期 fail-loud ④ 不动默认值；
- **corpse 项**：若 corpse 臂仍要跑 ⇒ 顺手带上（~3 行，收益 13–22 min/60k）；否则降权；
- **可选新增**（等所有者裁）：续跑「重建配置指纹 == 快照指纹」fail-loud 校验（R237 教训 ㉘ 的工程化，≤30 行 + 1 测试）。
