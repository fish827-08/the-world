"""MEMORY.md 压缩 pass 4（09-23，收尾）：目标 <23.6KB。"""
from pathlib import Path

P = Path(".workbuddy/memory/MEMORY.md")
s = P.read_text(encoding="utf-8")
before = len(s.encode("utf-8"))
REPS = [
 ("- 冒烟实测（`_rerun_logs/_smoke_cap/`，09-21）：**关档 88.7% 个体能量超上限**（囤积=常态）｜\n"
  "  开档 `mean_energy` **715→267**、捕食**真实出手成功率 0.3464→0.3771（+8.9%）**、饿死 +24%/被捕食 −13%",
  "- 冒烟实测（`_rerun_logs/_smoke_cap/`）：**关档 88.7% 个体能量超上限**（囤积=常态）｜开档 `mean_energy` **715→267**、捕食真实出手成功率 **0.3464→0.3771**、饿死 +24%/被捕食 −13%"),
 ("- **走全 Rust 的门槛**：`perc_radius=8` **且** `noise=0` **且** `tau=0` **且**关 `learning_bottleneck` **且**关 `arbitrary_codebook`（`_d2_asym` 管移动三条 / `_d2_repro` 管繁殖）⇒ 等于关整个 D2 ⇒ **\"auto\" 不可行**（精确条件见 R147 §四）",
  "- **走全 Rust 的门槛**：`perc_radius=8` 且 `noise=0` 且 `tau=0` 且关 `learning_bottleneck`/`arbitrary_codebook`（`_d2_asym`/`_d2_repro`）⇒ 等于关整个 D2 ⇒ **\"auto\" 不可行**（细节 R147 §四）"),
 ("- **寿命** = `2400 × lifespan_mult × (1+7·g3)` = **2400–19200 tick**（成熟 0.15×/老年 0.75×；维持 ×1.6/×1.4）｜**四季 ❌ 无**（`tilt_rad` 预留 0）｜**光照/温度场、斑点=植物、光合 g8+扎根 g19 均已接线**（`photo_max=0.1`；`--photo-max 0` = 不删基因位的中性化）",
  "- **寿命** = `2400×lifespan_mult×(1+7·g3)` = **2400–19200 tick**（成熟 0.15×/老年 0.75×）｜**四季 ❌ 无**（`tilt_rad`=0）｜**光照/温度场、斑点=植物、光合 g8+扎根 g19 已接线**（`photo_max=0.1`）"),
 ("4. 后续（等 P1/P2 判读）：calib2 ｜ PR `feat/predator-dash` 按 L2 规格重写 ｜ Q1 口径 v2 ｜\n"
  "   数据仓 provenance ｜ 300k 的 g16 均值+方差（均 `[云端]`）\n"
  "5. 长期：脆弱性钩子（R141，P1）｜四季/庇护所入纪元｜**C3 发送者回报**（唯一未接线的承重条件）",
  "5. 后续（均 `[云端]`）：calib2 ｜ PR `feat/predator-dash` 按 L2 规格重写 ｜ Q1 口径 v2 ｜ 数据仓 provenance｜\n"
  "   长期：脆弱性钩子｜四季/庇护所入纪元｜**C3 发送者回报**（唯一未接线的承重条件）"),
]
ok, skip = 0, []
for old, new in REPS:
    n = s.count(old)
    if n == 1:
        s = s.replace(old, new); ok += 1
    else:
        skip.append((n, old[:40]))
P.write_text(s, encoding="utf-8")
after = len(s.encode("utf-8"))
print(f"MEMORY.md {before} -> {after} ({after - before:+d})  应用 {ok}/{len(REPS)}")
for n, t in skip:
    print(f"  跳过(命中 {n}): {t}")
