"""P2② 跨提交 digest：T4 同款夹具跑固定 tick，打印末态指纹（供 97b7fc2 对拍）。

夹具 = T4 逐字段配置（480×960 / k=2.5 / subdiv 80 / pop 3000 / use_sim_core=False /
subpos on），每 tick 钉住能量维持 N≈3000（同 `_bench_p2b.py`）。

用法：.venv\\Scripts\\python.exe _p2b_digest.py [--ticks 150]
"""
from __future__ import annotations

import argparse
import hashlib
import sys
from pathlib import Path

import numpy as np

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
if (HERE / "simulation").is_dir():
    sys.path.insert(0, str(HERE))
else:
    sys.path.insert(0, str(HERE.parents[0]))

from simulation.sphere_engine import SphereEngine            # noqa: E402
from experiments.p1_profile import make_cfg                  # noqa: E402
from experiments.scaling_rescale import apply_post_build     # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ticks", type=int, default=150)
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()
    cfg, notes = make_cfg(a.seed, 480, 960, 3000, 480, False, True,
                          0.125, 0.125, 80, 2.5, 30000)
    e = SphereEngine(cfg)
    apply_post_build(e, notes)
    for _ in range(a.ticks):
        e.step()
        e._energy[:] = np.maximum(e._energy, 300.0)
    h = hashlib.blake2b(digest_size=16)
    for arr in (e._flat, e._energy, e._genes, e._id, e._trust, e._interpret,
                e._work_memory, e._stomach, e.signals._marks, e.resources._grid):
        h.update(np.ascontiguousarray(arr).tobytes())
    print(f"ticks={a.ticks} seed={a.seed} N={len(e._id)} "
          f"flat_sum={int(e._flat.sum())} energy_sum={float(e._energy.sum()):.6f} "
          f"rng_draws={e.rng.draws}")
    print(f"blake2b16={h.hexdigest()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
