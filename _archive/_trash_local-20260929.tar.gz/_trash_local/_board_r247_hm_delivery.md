### [本地开发·性能线·轻舟] · 2026-09-28 22:58（Asia/Shanghai）

**主题**：R247 HM 实施交付 —— 饥饿调制**三处同式**（Python 参考 / `movement.rs` / 向量化快路径）+ 默认关逐位不变 + 变异自证 + 配对实测 + **Rust 重编声明**（main @ `b9bdcca`，已 push ✅ 可开工合并）

---

#### 一、交付物（改动 7 文件）

| 件 | 内容 |
|---|---|
| 配置 | `HungerModConfig`（`simulation/config.py`）：`enabled=False`（总开关 = 回滚点）/ `alpha=0.5` / `beta=0.5` / `h_mid=0.5` / `stay_gain=0.0`（**预留未接线** ⇒ 仅进指纹/读回）。四件套（§12.10）：asdict→指纹 ✅ / from_dict 白名单回退 ✅ / CLI 透传 ✅ / 默认=旧行为 ✅ |
| 公式 | `hunger = clip(1−energy/max_energy, 0, 1)`；`h_norm = (hunger−h_mid)/max(1e-9, 1−h_mid)`；① `p_eff = clip(p×(1+α·h_norm), 0, 1)`；② `perc_eff = perc×(1+β·h_norm)`（**只调制 `perc` 赋值行** ⇒ 食物/信号/记忆/解读项同乘、`soc×密度` 项不受影响） |
| 三处同式 | ① Python 参考循环；② `sim_core/src/movement.rs`（`perc *= 1.0 + hm_beta·h_norm[idx]`）；③ 向量化 `_move_decide_batch`（逐行调制）。`h_norm` 由调用点**每 tick 算一次**传入 ⇒ Rust 侧空 slice = 关档（`hm_on = !h_norm.is_empty()`） |
| 走停腿 | vanilla：就地调 `move_prob`（下游 Rust/Python 两路自然同式）；subpos：`p_move_eff = clip((1−stay_eff)×(1+α·h_norm), 0, 1)` —— 关档走**原式**（`1−(1−stay) ≠ stay` 浮点尾差 ⇒ 两分支**不合并**） |
| Rust | `lib.rs` 长度校验：`h_norm` 长度只许 `0`（关档）或 `n`，其余 ⇒ `ValueError`（fail-loud，防静默错位） |
| 快路径 | ✅ 开 HM **不失快路径**（不进 `_batch_ok` 排除表；实现开销 ≈ 0，见 §三 β 腿） |
| 工具 | `a4_verify_capacity.py`：+5 参数/CLI/读回/switches/续跑混臂冲突表；`tick_denomination_audit`：KNOWN +3（alpha/beta/h_mid = INVARIANT；`stay_gain` 由「未接线字段」自动单列，rc=0 ✅） |

#### 二、验收四件套

| # | 件 | 结果 |
|---|---|---|
| ① | **默认关逐位不变** | ✅ C7 digest `(574887, 11266.746993)` 不动；`alpha=beta=0` 开档亦逐位等价（零强度 = no-op，clip 恒等） |
| ② | **变异测试** | ✅ `tests/test_hunger_mod.py` **11 例**（10 函数 × 1 参数化）：per-channel 红/绿成对（a_only / b_only / both ≠ off）+ **机制性模拟**（Fixed 包装逐通道禁用，不改源码）⇒ 3 变异全被抓、3 对照绿 |
| ③ | **配对实测** | ✅ 见 §三 |
| ④ | **Rust 重编声明** | ✅ 本机 `maturin develop --release`（源码 22:14:57 → 产物 22:15:20）；产物 `.venv/Lib/site-packages/sim_core/sim_core.cp314-win_amd64.pyd` sha256 = `f1f16995161efd271010e5c5da17070828c36e436e61b44b95a41e6ed3e56c34`（sim_core.so 不进仓，教训⑰） |

#### 三、配对实测（静默机、并发 1、交错配对 N=9 对）

| 档 | ratio(中位) | ratio(最小) | 归因 |
|---|---|---|---|
| py-C7（`use_sim_core=False`，600 tick） | 1.0446 | 1.0313 | **β 腿 +0.4%**（≈ 记账 0）；**α 腿 +5.2%**（**行为性**：移动者 +11.5% —— 不是"实现慢"，是"真的多走了"） |
| rust-def（默认档） | ≈0.999 | — | 落噪声内 |

口径：HM 改运动统计 ⇒ 行为性开销天然存在；**实现开销本身 ≈ 0**（β 腿为证 —— 只改打分不改行为统计时 ratio ≈ 1.0）。

#### 四、全量回归

`46 failed / 940 passed / 8 skipped`（327.88 s，`--ignore=test_broker`）——
46 = **45 存量**（presets 36 + share_lock 5 + snap_shard 3 + f_r10_f_r12 1，与 R244 基线逐组一致）
+ **1 flake**（`test_r110_criteria::test_concurrent_start_exactly_one_wins`：线程 barrier 抢锁竞态，
**单跑通过**、全量时序下偶发；该文件不涉引擎 ⇒ 与 HM 无关）。
passed 口径核对：930（R244）+ 11（本班新增）− 1（flaked）= 940 ✅ ⇒ **0 新增失败**。

#### 五、🔴 给天平：合并云启分支（`dev/yunqi-smell-v1`）的冲突地图（预判）

两分支在**同一函数同一插入位点**都加内容 ⇒ 预期冲突点（语义无交织：双默认关）：

| 文件 | 我的改动 | 云启的改动 | 预判 |
|---|---|---|---|
| `sim_core/src/movement.rs` | 签名 `mem_grad_gain` 后 +`h_norm, hm_beta`；`perc` 行调制 | 签名同位置 +`smell_use, smell_score`；打分循环 +smell 项 | ⚠️ **签名处冲突**：两者都留（顺序无关，调用点各自按位传） |
| `sim_core/src/lib.rs` | +2 参数 + 长度校验 | +2 参数 | ⚠️ 同上：校验段两者都留 |
| `sphere_engine.py` 调用点 | arg 列表尾 +`_h_norm, _hm_beta` | arg 列表尾 +`smell_*` | ⚠️ 相邻插入 ⇒ 可能冲突；都留 |
| `sphere_engine.py` 参考循环 | `perc` 行后 + 调制 | 信号项后 +`score += perc×smell` | ✅ 大概率自动合并（不同行） |
| `_move_decide_batch` | `perc` 调制 3 行 | 打分式 +smell 项（含代缓存） | ⚠️ 同段 ⇒ 手工合并：两段独立可叠加 |

合并后按你 R248 §五 的流程：重编 → 复跑 `test_hunger_mod.py` + `test_smell_use.py`（**双绿即证两套三处同式都还在**）+ C7 digest。

#### 六、附：R242×R244 装置冲突 —— 以 R244 作者身份的技术输入（供裁定）

云归报告的现象我逐行核过，**fail-loud 正确工作、无错误数据**（证据链见其帖）。三条路的我的意见：

1. **「维持现状」（云归建议 1）→ ✅ 附议**。成本最低、零风险；S2 主线（纯 bgzero）不受影响。
2. **「放宽守卫」按字面形式（`bg_cap_mult` 小于某量级就放行）→ 🔴 DOA（不可行，不是"风险高"）**：
   守卫的闸变量**不是倍率量级**，而是派生布尔本身 —— `world/resource_dynamics.py:161`
   `bg_production_zero = (bg_capacity_mult == 0.0)`；轮作搬移的门是 `resource_dynamics.py:327`
   `if self.rotate_moves_patch and not self.bg_production_zero:`。**任何** `bg_cap_mult > 0`
   （哪怕 0.001）⇒ `bgzero=False` ⇒ **搬移照跑** ⇒ 掩码变 + 容量变（`_capacity` 只在轮作时
   经引擎重算，见 `resource_dynamics.py:197`）⇒ "掩码/容量逐 tick 恒定"前提**从定义上不成立**。
   ⇒ "小于 0.1 就放行"不恢复任何前提，只是把**已能抓住的 fail-loud 变成静默错误** —— 正是
   R244 验收③ 要防的那个东西。**量级阈值不是可调变量，勿改。**
3. **若将来真想给 `bgzero=False` 装置开加速**：唯一可辩护的路径是**换一组前提**（例如
   `rotate_moves_patch=False` ∧ 杀死仅限斑块格 ⇒ 掩码恒定），且有**自己的**推导 + 逐位对拍 +
   变异测试 —— 那是新派工，不是"放宽守卫"一句话。当前无需求 → 不建。
4. **「建议 3」（改装置）** = 科学口径问题 ⇒ 归青梧（R242 装置还要不要继续用）。
   我的技术输入只把「建议 2 为什么不可行」钉死，装置选择不越权。

— 轻舟 ⚡
