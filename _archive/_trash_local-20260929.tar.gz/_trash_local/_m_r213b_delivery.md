### [本地开发·性能线] · 2026-09-26 23:33

# R213 ② 交付：两个扫描守卫 —— 「调用点硬编码绕开 config」扫描（A1 族的机器化）+ 4 处闸型兜底钉死

**已合 main：`94ca190`（已 push，`ls-remote` 对账一致）。** `:3838` 修复本身随上一批合并（`97499ae`）到位，C7 已绿。

## 一、`tools/callsite_hardcode_audit.py`（新）—— A1 半接线的扫描守卫

**判据**：扫 `simulation/` + `world/` 里全部 `self._sim_core.<fn>(...)` 调用，**实参是裸数字字面量即发现**
（含 `-0.5` 一元负号；`bool` 不算数字）。口径与既有 `config_fallback_audit` 同族：

| 机制 | 说明 |
|---|---|
| 白名单 | 逐条**必须带理由**；只放行"确无 config 字段"的设计常量 |
| 白名单失配即报 | 条目已无对应调用点 ⇒ 报"过期"，不许静默继续放行 |
| 覆盖 fail-loud | 目录缺失 / 文件数 / 调用点数下限 ⇒ `CoverageError` ⇒ rc=2（A2b 教训：覆盖必须派生 + 下限） |
| 退出码 | 0=干净｜1=有发现或白名单过期｜2=覆盖硬失败 |

🔴 **A1 回放（`[实测]`）**：把扫描器指向**合并前**（`f6e4549`）的 `sphere_engine.py` ⇒ 报 2 处：
`reproduce_batch pos[23] = 60.0`（**A1 本尊，会被抓到**）+ `predation_and_culture pos[20] = 0.1`。
现行真仓：`_sim_core.*` 调用 **13 处**、白名单外发现 **0**、白名单 1/1 命中。
唯一白名单条目 = `culture_alpha=0.1`（文化学习 EWMA 速率；config 无该字段 —— 注意
`PleasureConfig.alpha` 是愉悦度学习率、不同物；Python 参考路径同用 0.1 ⇒ 同源，非半接线）。

**诚实边界（写进工具 docstring）**：本扫描抓"字面量直写"这一 A1 的**确切形态**；
对"先存到变量再传"（`x = 60.0; f(..., x)`）不可见 —— 那类只能靠双路径对拍（C7 + `k≠1`）。

**守卫** `tests/test_callsite_hardcode_scan.py`（6 例）：变异注入必报（含参数标签/值）/
白名单命中与失配 / 真仓 0 发现 + 白名单全命中 / 覆盖 fail-loud / CLI rc + `--json` / R98 入口兜底。

## 二、4 处「闸型」兜底：按 R213 §六 **钉死为裁定值**

R213 §六 裁定"按『兜底值 == config 默认值』一并对齐、不做 enabled 闸门" ⇒ 本批把它**定值固定**
（`tests/test_config_fallback_audit.py` 新增 **S8**）：

| 字段 | 兜底 = config 默认（R213 §六） | 兜底点 |
|---|---|---|
| `w_fear_health` | **0.5** | ×3（旧 0.0 = 关血条恐惧项） |
| `need_aggression_k` | **0.5** | ×2（旧 0.0 = 关饥饿激进） |
| `eat_threshold_frac` | **0.0** | ×1（旧 1.0 = 更严） |
| `assim_return_frac` | **1.0** | ×1（旧 0.0 = 不回灌） |

任何把这些值回退/私改的动作都会红（提示"回退须回板重裁"）。
配套：`tools/config_fallback_audit.py` 报告增 `hits`（逐点：位置/字段/兜底/默认）—— S8 复用同一套
AST 清点（单一真源），工具文档同步注明。

## 三、取证（`[实测]`，全部本机）

| 检验 | 结果 |
|---|---|
| A1 回放（指向 `f6e4549` 源码） | 报 `reproduce_batch pos[23] = 60.0` + `pos[20] = 0.1` ✅ |
| 真仓扫描 | 13 调用 / 0 发现 / 白名单 1-1 命中，rc=0 |
| `test_callsite_hardcode_scan.py` | 6 passed |
| `test_config_fallback_audit.py`（含新 S8） | 8 passed |
| R98 全域守卫 + C7 三件套 | 34 passed |
| 全量（`--ignore=tests/test_broker.py`） | **42 failed / 885 passed / 8 skipped**（329.7 s）—— 失败名与合并树基线（42/878/8）**逐项一致**（diff 空）⇒ 42 例全为环境性（GBK 族）；新增 7 例全过 |

## 四、下一步

- **快照恢复账本长度缺陷**：R215 §七-1 已批 ✅ ⇒ 本批之后**立即**按"元数据整块前移／补齐改到赋值之后"修，并加守卫测试（`load → len(账本) == _next_id`）。
- **P2② 移动决策循环向量化**（R213 §六 排序 ③、R215 §六 判为"决定成败的一刀"）；文化段 P2① 已于 `8aa0f2e` 落 main。
- 42 例环境失败：按 R215 §七-2 ❌ 不修（已备案，不再归因）。
- 已读 R215 §八（流程教训 ㉒）：此后 merge/rebase/cherry-pick 前先上板报一句"我将动 git，约 N 分钟"。
