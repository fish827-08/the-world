import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import numpy as np

rng = np.random.default_rng(7)
bad = 0
for K in (2, 3, 7, 8, 9, 16, 33, 64, 100, 257, 500):
    a = (rng.standard_normal((K, 16)) *
         10.0 ** rng.integers(-25, 25, size=(K, 16)))
    m1 = a.mean(axis=0)
    m2 = np.add.reduceat(a, np.array([0]), axis=0)[0] / K
    same = m1.tobytes() == m2.tobytes()
    exact = np.array_equal(m1.view(np.int64), m2.view(np.int64))
    print(f"K={K:4d} 单段 reduceat==mean: bytes={same} int64={exact}")
    if not exact:
        bad += 1

# 多段：与逐段分开算 mean 对比
for trial in range(200):
    segs = rng.integers(1, 60, size=rng.integers(1, 8))
    n = int(segs.sum())
    a = (rng.standard_normal((n, 16)) * 10.0 ** rng.integers(-20, 20, size=(n, 16)))
    starts = np.concatenate(([0], np.cumsum(segs)[:-1]))
    r = np.add.reduceat(a, starts, axis=0) / segs[:, None]
    off = 0
    for i, s in enumerate(segs):
        m = a[off:off + s].mean(axis=0)
        if m.tobytes() != r[i].tobytes():
            bad += 1
            print(f"  多段不一致 trial={trial} seg={i} len={s}")
        off += s
print("多段 200 trial 完成，不一致计数 =", bad)

# true_divide int64 除数 vs numpy 内部 /rcount
a = rng.standard_normal((13, 16)) * 1e17
m1 = a.mean(axis=0)
s = a.sum(axis=0)
m3 = s / 13
print("mean == sum/int:", m1.tobytes() == m3.tobytes())

# unique inverse 行为
x = rng.integers(0, 10, size=1000)
u, inv = np.unique(x, return_inverse=True)
print("unique inverse shape:", inv.shape, "dtype", inv.dtype, "roundtrip ok:", np.array_equal(u[inv], x))
