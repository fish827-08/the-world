#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""只读：解析回收站 $I 元数据，列出「原始路径 + 删除时间」。

用途：核实 2026-09-24 那次清理究竟移走了什么，以及有没有 09-24 当天修改过的开发文件。
$I 结构（Vista+，version 2）：
    [0:8]   版本号 (8 bytes, LE u64)
    [8:16]  文件大小
    [16:24] 删除时间（Windows FILETIME）
    [24:28] 路径长度（含结尾 \0，UTF-16 代码单元数）
    [28:]   原始路径（UTF-16LE，以 \0\0 结尾）
"""
import ctypes
import os
import struct
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def filetime_to_dt(ft: int):
    if not ft:
        return None
    # FILETIME = 1601-01-01 起的 100ns
    return datetime(1601, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=ft / 10)


def parse_i(p: Path):
    try:
        b = p.read_bytes()
    except OSError:
        return None
    if len(b) < 28:
        return None
    ver = struct.unpack_from("<Q", b, 0)[0]
    size = struct.unpack_from("<Q", b, 8)[0]
    ft = struct.unpack_from("<Q", b, 16)[0]
    dt = filetime_to_dt(ft)
    path = None
    if ver >= 2:
        ln = struct.unpack_from("<I", b, 24)[0]
        raw = b[28:28 + ln * 2]
        path = raw.decode("utf-16-le", errors="ignore").rstrip("\x00")
    else:
        path = b[24:].decode("utf-16-le", errors="ignore").rstrip("\x00")
    return {"size": size, "deleted": dt, "path": path}


def main():
    root = Path(r"C:\$Recycle.Bin")
    if not root.is_dir():
        print("读不到 C:\\$Recycle.Bin")
        return
    rows = []
    skipped = []
    for sid in root.iterdir():
        if not sid.is_dir():
            continue
        try:
            entries = list(sid.iterdir())
        except (PermissionError, OSError):
            skipped.append(sid.name)          # 例如 S-1-5-18（SYSTEM 的回收站，无权读）
            continue
        for f in entries:
            if not f.name.startswith("$I"):
                continue
            r = parse_i(f)
            if r and r["path"]:
                rows.append(r)
    rows.sort(key=lambda r: (r["deleted"] or datetime.min.replace(tzinfo=timezone.utc)))
    print(f"回收站条目数：{len(rows)}"
          + (f"（跳过无权访问的 SID：{skipped}）" if skipped else "") + "\n")
    print("| 删除时间 | 大小 | 原始路径 |")
    print("|---|---|---|")
    for r in rows:
        d = r["deleted"].astimezone().strftime("%m-%d %H:%M") if r["deleted"] else "?"
        sz = r["size"]
        for u in ("B", "KB", "MB", "GB"):
            if sz < 1024:
                s = f"{sz:.1f}{u}"
                break
            sz /= 1024
        print(f"| {d} | {s} | `{r['path']}` |")

    # 重点核查：有没有落在**仓库本体**源码目录里的（排除隔离目录内部的副本）
    guard = ("/simulation/", "/world/", "/experiments/", "/tests/", "/tools/",
             "/docs/", "/collab-toolkit/", "/core/")
    live = [r for r in rows if "_trash_purge_" not in (r["path"] or "")]
    hits = [r for r in live if any(g in (r["path"] or "").replace("\\", "/") for g in guard)]
    print(f"\n### 隔离目录**以外**的条目：**{len(live)}** 个")
    print(f"### 🔴 其中落在仓库源码目录（simulation/world/experiments/tests/tools/docs/core）的：**{len(hits)}** 个")
    for r in hits:
        print(f"  - {r['path']}")
    if not hits:
        print("  ⇒ **0 个** —— 本次清理未触碰仓库本体的任何源码目录。")


if __name__ == "__main__":
    main()
