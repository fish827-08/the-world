"""P2② cProfile A/B：同夹具、同 tick 数，两臂自时间 top 表（定位"省下的 23.6 ms"来自哪段）。

用法：.venv\\Scripts\\python.exe _trash_local/_prof_p2b.py [--ticks 40]
"""
from __future__ import annotations

import argparse
import cProfile
import io
import pstats
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from simulation.sphere_engine import SphereEngine            # noqa: E402
from experiments.p1_profile import make_cfg                  # noqa: E402
from experiments.scaling_rescale import apply_post_build     # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def arm(fast: bool, warm: int, ticks: int, top: int) -> None:
    cfg, notes = make_cfg(42, 480, 960, 3000, 480, False, True,
                          0.125, 0.125, 80, 2.5, 30000)
    e = SphereEngine(cfg)
    apply_post_build(e, notes)
    e._batch_move_on = bool(fast)

    def run(n: int) -> None:
        for _ in range(n):
            e.step()
            e._energy[:] = np.maximum(e._energy, 300.0)

    run(warm)
    pr = cProfile.Profile()
    t0 = time.perf_counter()
    pr.enable()
    run(ticks)
    pr.disable()
    dt = time.perf_counter() - t0
    st = pstats.Stats(pr)
    st.sort_stats("tottime")
    buf = io.StringIO()
    st.stream = buf
    st.print_stats(top)
    st.stream = sys.stdout
    tag = "快路径 on " if fast else "参考循环 off"
    print(f"\n===== 臂 {tag}｜{dt / ticks * 1000:.1f} ms/tick（被 profile 放大，仅看占比）"
          f"｜N={len(e._id)} =====")
    for line in buf.getvalue().splitlines():
        if line.strip():
            print(line)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--ticks", type=int, default=40)
    ap.add_argument("--warm", type=int, default=10)
    ap.add_argument("--top", type=int, default=12)
    a = ap.parse_args()
    arm(False, a.warm, a.ticks, a.top)
    arm(True, a.warm, a.ticks, a.top)
