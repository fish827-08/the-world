"""定位 py 臂 vs rust 臂的 N 轨迹分歧来源（P1 副产物，纯观测）。

思路：同一 config（仅 use_sim_core 不同）造两台引擎，逐 tick 比较
  * t=0 初始状态（资源格 / 位置 / 能量 / 基因）
  * 之后每 tick 的 `resources._grid` 最大绝对差 + 首个差异 tick
把「资源再生下沉 Rust」这一条（regrow_patchy vs Python regrow）单独拎出来对拍，
以判定分歧是**资源管线**还是**种群段**。

用法：.venv\\Scripts\\python.exe _trash_local/_divcheck.py [--ticks 30]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from experiments.p1_profile import make_cfg          # noqa: E402
from simulation.sphere_engine import SphereEngine    # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def build(use_sim_core: bool, pop: int, pin_cd_scale: float = 0.0):
    c, notes = make_cfg(seed=42, rows=480, cols=960, pop=pop, patches=480,
                        use_sim_core=use_sim_core, subpos=False,
                        speed_max=0.125, gain=0.125, subdiv=80, k=2.5,
                        max_count=30000)
    if pin_cd_scale > 0:
        # 只把这一个字段"回钉"到 60（= Rust 调用点硬编码值）⇒ 两臂应恢复逐位一致
        c.organisms.repro_cooldown_gene_scale = float(pin_cd_scale)
    e = SphereEngine(c)
    return e


def maxdiff(a: np.ndarray, b: np.ndarray) -> float:
    if a.shape != b.shape:
        return float("inf")
    return float(np.max(np.abs(a.astype(np.float64) - b.astype(np.float64)))) if a.size else 0.0


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ticks", type=int, default=30)
    ap.add_argument("--pop", type=int, default=5000)
    ap.add_argument("--stride", type=int, default=1)
    ap.add_argument("--from-tick", type=int, default=0)
    ap.add_argument("--pin-cd-scale", type=float, default=0.0)
    a = ap.parse_args()

    py = build(False, a.pop, a.pin_cd_scale)
    rs = build(True, a.pop, a.pin_cd_scale)

    print(f"== t=0 初始状态对拍（py vs rust），pop={a.pop} ==")
    print(f"  N:              py={len(py._id)}  rust={len(rs._id)}")
    print(f"  resources.grid  maxdiff={maxdiff(py.resources._grid, rs.resources._grid):.3e}")
    print(f"  capacity        maxdiff={maxdiff(py.resources._capacity, rs.resources._capacity):.3e}")
    print(f"  patch_mask      diff_cells={int(np.count_nonzero(py.resources._patch_mask != rs.resources._patch_mask))}")
    print(f"  flat(pos)       diff_count={int(np.count_nonzero(py._flat != rs._flat))}")
    print(f"  energy          maxdiff={maxdiff(py._energy, rs._energy):.3e}")
    print(f"  genes           maxdiff={maxdiff(py._genes, rs._genes):.3e}")
    print(f"  rng(after init) py={py.rng.bit_generator.state['state']['state']}  "
          f"rust={rs.rng.bit_generator.state['state']['state']}")

    print(f"\n== 逐 tick 全状态对拍 ==")
    first = None
    for t in range(1, a.ticks + 1):
        py.step()
        rs.step()
        d = maxdiff(py.resources._grid, rs.resources._grid)
        dp = maxdiff(py.resources._capacity, rs.resources._capacity)
        dn = 0 if len(py._id) == len(rs._id) else 1
        de = maxdiff(py._energy, rs._energy)
        dg = maxdiff(py._genes, rs._genes)
        dfl = int(np.count_nonzero(py._flat != rs._flat)) if py._flat.shape == rs._flat.shape else -1
        any_diff = (d > 0) or (dp > 0) or dn or (de > 0) or (dg > 0) or (dfl != 0)
        flag = ""
        if any_diff and first is None:
            first = t
            flag = "  <== 首个分歧"
        if t <= 5 or (t % a.stride == 0 and t >= a.from_tick) or flag:
            print(f"  t={py._tick:>4}  N py={len(py._id):>5} rust={len(rs._id):>5}"
                  f"  grid={d:.2e} cap={dp:.2e} E={de:.2e} gene={dg:.2e} pos_diff={dfl}"
                  f"{flag}")
        if first is not None and t >= first + 3:
            break

    if first is None:
        print(f"\n⇒ 前 {a.ticks} tick 全状态逐位一致")
    else:
        print(f"\n⇒ 首个分歧出现在 t={first}")


if __name__ == "__main__":
    main()
