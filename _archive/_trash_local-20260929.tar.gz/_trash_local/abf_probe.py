#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""独立复核 `analyze_bimodal_fitness.py` 的"无内部谷"判定。

🔴 疑点：报告 C 组 `cost×200` 的读数
    W: g=0 → 1.0000 | g=.3 → 0.4750 | g=.5 → 0.3750 | g=.7 → 0.4750 | g=1 → 1.0000
   两端高、中间低 ⇒ 形状上就是"谷"，但脚本判"无内部谷"。

本脚本做三件事：
  1) 解析求导（不依赖 np.gradient，避开 gate 跳变污染）
  2) 网格找全局最小点位置（判定"内部"还是"边界"）
  3) 复刻原脚本的驻点检测，打印它为什么漏掉
"""
import sys

import numpy as np

sys.stdout.reconfigure(encoding="utf-8") if hasattr(sys.stdout, "reconfigure") else None

COEF, GATE, GAIN = 0.2, 0.3, 0.5
FLOOR, CEIL, R, C = 0.1, 0.9, 0.4, 0.1
# 复刻原脚本的判据参数（必须逐字一致）
TOL = 1e-6
N = 200001


def sigma(g, e_self, e_prey):
    return np.clip((e_self / max(e_self + e_prey, 1e-9)) * (0.5 + g * GAIN), FLOOR, CEIL)


def W(g, k, F, e_self, e_prey, hunger, cs):
    g = np.asarray(g, dtype=float)
    p = g * COEF * hunger
    N_ = np.clip((e_self / max(e_self + e_prey, 1e-9)) * (0.5 + g * GAIN), FLOOR, CEIL)
    return (1.0 - g) ** k * F + (g > GATE) * (p * N_ * e_prey * R - p * C * cs)


def analytic_min(k, e_self, e_prey, hunger, cs, F=1.0):
    """在 (GATE, 1] 上解析找驻点：dW/dg = -k(1-g)^(k-1) + (-A + 2B g)，A/B 由展开得。"""
    ratio = e_self / max(e_self + e_prey, 1e-9)
    lo = ratio * 0.5
    hi = ratio * (0.5 + GAIN)
    # 在 g 使 s 未被 clip 命中的区间内：W' = -k(1-g)^{k-1} - a*c*cs + a*r*e_prey*(lo + 2*hi2*g)
    #   其中 s(g) = ratio*(0.5+GAIN*g) = lo + GAIN*ratio*g
    a = COEF * hunger
    slope_const = a * (R * e_prey * lo - C * cs)
    slope_lin = a * R * e_prey * GAIN * ratio
    g = np.linspace(GATE + 1e-9, 1.0, 400001)
    s_unclipped = lo + GAIN * ratio * g
    in_clip = (s_unclipped > FLOOR + 1e-12) & (s_unclipped < CEIL - 1e-12)
    dw = np.where(in_clip, -k * (1.0 - g) ** (k - 1) * F + slope_const + 2 * slope_lin * g,
                  np.nan)
    # 找符号变化
    s = np.sign(dw)
    turns = []
    for i in range(1, len(g)):
        if np.isnan(s[i]) or np.isnan(s[i - 1]):
            continue
        if s[i] != s[i - 1] and s[i] != 0:
            turns.append(g[i])
    return g, dw, turns


def main():
    print("=" * 96)
    print("§1 逐解析：cost_scale 扫描 —— W 的最小点落在哪？（k=2, e=150/150, hunger=0.5, F=1）")
    print("=" * 96)
    print(f"{'cost×':>6} | {'W(0)':>8} {'argmin':>8} {'W(min)':>8} {'W(1)':>8} | "
          f"{'内部极小?':>9} | {'解析驻点(GATE,1)':>40}")
    rows = []
    for cs in (1, 5, 10, 20, 30, 50, 80, 100, 150, 200, 500, 1000):
        g = np.linspace(0.0, 1.0, N)
        w = W(g, 2.0, 1.0, 150.0, 150.0, 0.5, cs)
        i = int(np.argmin(w))
        gm, wm, w0, w1 = g[i], w[i], w[0], w[-1]
        interior = 0.02 < gm < 0.98
        is_valley = interior and wm < min(w0, w1) - 1e-9
        gs, dw, turns = analytic_min(2.0, 150.0, 150.0, 0.5, cs)
        rows.append((cs, w0, gm, wm, w1, is_valley, turns))
        print(f"{cs:>6} | {w0:>8.4f} {gm:>8.4f} {wm:>8.4f} {w1:>8.4f} | "
              f"{('✅ 是' if is_valley else '❌ 否'):>9} | "
              f"{('、'.join(f'{t:.4f}' for t in turns[:3]) or '—'):>40}")

    print("\n" + "=" * 96)
    print("§2 复刻原脚本的驻点检测，看它漏在哪（以 cost×200 为例）")
    print("=" * 96)
    k, cs = 2.0, 200.0
    g = np.linspace(0.0, 1.0, N)
    w = W(g, k, 1.0, 150.0, 150.0, 0.5, cs)
    dw = np.gradient(w, g)
    idx = np.where(g > GATE)[0]
    gw, dww = g[idx], dw[idx]
    sign = np.sign(dww)
    turns = np.where(np.diff(sign) != 0)[0]
    print(f"grid n={N}  网格间距={g[1]-g[0]:.2e}")
    print(f"gate 处 W 跳变：W(0.3-)={W(0.3 - 1e-9, k,1.0,150,150,.5,cs):.6f} → "
          f"W(0.3+)={W(0.3 + 1e-9, k,1.0,150,150,.5,cs):.6f}")
    print(f"跳变处 np.gradient 最大绝对值 = {np.nanmax(np.abs(dww)):.3e}"
          f"  （来自不连续，不是真实斜率）")
    print(f"sign 变号点个数 = {len(turns)}；这些点的 g 值：")
    for i in turns[:8]:
        print(f"    i={i:>7d}  g={gw[i]:.6f}  dww={dww[i]:.3e}  "
              f"W={w[idx[i]]:.6f}  → 脚本会 {'跳过(i<=0/末尾)' if (i <= 0 or i >= len(gw)-1) else '进入极值判定'}")
    # 复刻极值类型判定
    print("\n  逐点复刻原脚本的极值判定：")
    for i in turns[:8]:
        if i <= 0 or i >= len(gw) - 1:
            print(f"    g={gw[i]:.6f} → **被 `if i <= 0 or i >= len(gw)-1: continue` 跳过**")
            continue
        jl = i - 20 if i >= 20 else 0
        jr = min(i + 20, len(idx) - 1)
        sl = w[idx[i]] - w[idx[jl]]
        sr = w[idx[jr]] - w[idx[i]]
        kind = ("极小(谷)" if (sl < -TOL and sr > TOL)
                else "极大(峰)" if (sl > TOL and sr < -TOL) else "**未分类（判据不成立）**")
        print(f"    g={gw[i]:.6f}  slope_l={sl:+.3e}  slope_r={sr:+.3e}  → {kind}")

    print("\n" + "=" * 96)
    print("§3 结论")
    print("=" * 96)
    valleys = [(cs, wm, w0, w1) for cs, w0, _gm, wm, w1, ok, _t in rows if ok]
    if valleys:
        print(f"🔴 在 {len(valleys)}/{len(rows)} 组 cost× 上，W 存在**内部极小**：")
        for cs, wm, w0, w1 in valleys:
            print(f"    cost×{cs:<5} W(min)={wm:.4f} < W(0)={w0:.4f} 且 < W(1)={w1:.4f}"
                  "  ⇒ 两端高、中间低 = 破坏性选择形态")
        print("\n⇒ 报告 §3.4 的『C. 提高攻击成本 6/6 无内部谷』与读数**不一致**，需复核。")
    else:
        print("✅ 复现报告结论：所有 cost× 上均无内部极小。")


if __name__ == "__main__":
    main()
