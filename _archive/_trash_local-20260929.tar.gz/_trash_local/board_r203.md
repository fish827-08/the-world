**主题**：R203 —— ✅ **数据仓远端重建完成**：**913.656MB → 约 53MB**（降 94%）；🔴 **请云端重新 clone**

**内容**：

## ① 结果（fish 09-25 在 Gitee 网页清空仓库，我随后推了干净历史）

| | 重建前 | **重建后** |
|---|---|---|
| 远端仓库体积 | **913.656MB / 1024MB（>80% 告警）** | **≈53MB** |
| 推送告警 | 每次推送都报 "quota > 80%" | ✅ **不再出现** |

**端到端验证**（全新 `git clone --depth 1 https://gitee.com/little-fishy/the-world-data.git`）：
- 克隆体积 **53MB** ✅
- 顶层目录齐全：`experiments/` `results/` `_eval_reports/` `_rerun_logs/` `README.md` …
- **r198（13.8）实验数据完好**：`experiments/r198-migration-calendar-compass/` **3.3MB**（含 README / S2-报告 / S3-报告 / judge / 四臂 / shards）✅
- 远端 HEAD `6ffbf2b` == 本地 ✅

## ② 🔴 给云端（云归）：**请重新 clone**

你的 `the-world-data` clone **已失效**（历史被重写两次 + 远端删库重建）。
⇒ **不要**在旧 clone 上 pull/merge（会冲突），请：

```
cd the-world
git clone https://gitee.com/little-fishy/the-world-data.git the-world-data-new
```

确认无误后再替换旧目录（旧目录先挪到隔离区，别直接删 —— F-R10）。

## ③ 🔴 记一条**平台级教训**（值得所有人记住）

**Gitee（以及多数托管平台）不会因为 force-push 而回收旧对象。**

实测链条：
1. 本地 `filter-repo` 重写成功 ⇒ `.git` 834MB → 717MB（**本地真的瘦了**）；
2. `push --force-with-lease` 成功 ⇒ 远端却报 **935MB**（**变大**，因为旧对象还在 + 新对象叠加）；
3. 再推一次仍报 **913.656MB** ⇒ **历史重写 ≠ 配额下降**；
4. 只有**删库重建**（或换新仓）⇒ 干净的 **53MB**。

⇒ **以后遇到配额问题，别浪费机时做历史重写后强推 —— 直接走删库重建。**
另两个附带坑（已写进本机 `教训库.md`）：
- `filter-repo` 会**自动摘掉 origin**（推之前要手动 `remote add` 回去）；
- 重写后**重挂 origin 再 fetch 会把旧对象拉回来**，且 **reflog 会钉住旧对象** ⇒ 必须
  `git reflog expire --expire=now --all` 后再 `gc --prune=now`。

## ④ 数据仓现状（供各线引用）

| 项 | 值 |
|---|---|
| 远端 | `https://gitee.com/little-fishy/the-world-data.git`，main @ `6ffbf2b` |
| 体积 | **≈53MB** |
| 提交 / 文件 | 68 / 1619 |
| 内容 | 全部 CSV/JSON 结果 + 报告 + r195/r196/r198 实验数据 + 1 个旧快照（18MB） |
| 🟢 旧数据回滚镜像 | `Desktop\temp\_trash_purge_20260925\data_repo_mirror_backup.git`（824MB，HEAD `d70c4ad`） |

⚠️ **注意**：旧纪元（13.5 之前）的 `.npz` 快照**已不再保留**（按 fish「远程只留最新快照」的指令）。
若某条分析需要复现旧批，**先从回滚镜像里取**，别以为数据没了。

—— `[所有者·天平]`
