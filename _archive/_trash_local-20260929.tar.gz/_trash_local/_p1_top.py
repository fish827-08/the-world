"""line_profiler 输出解析器（P1 交付用）—— 出「累计时间前 N 表」。

line_profiler 的 txt 每段形如：
    Function: <qualname> at line <L>
    Line #      Hits         Time  Per Hit   % Time  Line Contents
    ==============================================================
      2999        ...        ...   ...      ...     for i, idx in enumerate(mi):
本脚本把每段的**非注释行**按 Time 降序取前 N，并给出该行占**该函数**的 %。

用法：
    .venv\\Scripts\\python.exe _trash_local/_p1_top.py <file.txt> [<file2.txt> ...] --top 10
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

FN_RE = re.compile(r"^Function:\s+(?P<name>.+?)\s+at line\s+(?P<line>\d+)\s*$")
ROW_RE = re.compile(r"^\s*(?P<line>\d+)\s+(?P<hits>\d+)\s+(?P<time>[\d.]+)\s+"
                    r"(?P<per>[\d.]+)\s+(?P<pct>[\d.]+)\s+(?P<src>.*)$")


def parse(path: Path) -> dict[str, dict]:
    """注意：line_profiler 的 txt 里 `Total time:` **在** `Function:` 头之前
    ⇒ 必须先存 pending 再挂到下一个 Function 段（否则整体错位一段）。"""
    sections: dict[str, dict] = {}
    cur = None
    pending_total: float | None = None
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        m = FN_RE.match(raw)
        if m:
            cur = f"{m.group('name')} (L{m.group('line')})"
            sections[cur] = {"rows": [], "total": pending_total}
            pending_total = None
            continue
        if raw.startswith("Total time:"):
            pending_total = float(raw.split(":", 1)[1].strip().split()[0])
            cur = None
            continue
        r = ROW_RE.match(raw)
        if r and cur is not None and int(r.group("hits")) > 0:
            src = r.group("src").strip()
            if not src or src.startswith("#"):
                continue                      # 注释行不参与排名
            sections[cur]["rows"].append({
                "line": int(r.group("line")), "hits": int(r.group("hits")),
                "time": float(r.group("time")), "pct": float(r.group("pct")),
                "src": src,
            })
    return sections


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    ap.add_argument("--top", type=int, default=10)
    ap.add_argument("--min-pct", type=float, default=0.0)
    a = ap.parse_args()

    for f in a.files:
        p = Path(f)
        secs = parse(p)
        print(f"\n######## {p.name} ########")
        for name, d in secs.items():
            tot = d["total"]
            rows = sorted(d["rows"], key=lambda r: -r["time"])
            print(f"\n== {name}｜总 {tot:.4f} s（{len(d['rows'])} 行有耗时）==")
            print(f"{'行号':>7}{'hits':>9}{'Time(s)':>10}{'占比':>8}  源码")
            print("-" * 110)
            for r in rows[:a.top]:
                if r["pct"] < a.min_pct:
                    break
                src = r["src"] if len(r["src"]) <= 78 else r["src"][:75] + "..."
                print(f"{r['line']:>7}{r['hits']:>9}{r['time'] * 1e-7:>10.4f}{r['pct']:>7.2f}%  {src}")
            rest = rows[a.top:]
            if rest:
                s = sum(r["time"] for r in rest) * 1e-7
                sp = sum(r["pct"] for r in rest)
                print(f"{'其余':>7}{len(rest):>9}{s:>10.4f}{sp:>7.2f}%  （{len(rest)} 行合计）")


if __name__ == "__main__":
    main()
