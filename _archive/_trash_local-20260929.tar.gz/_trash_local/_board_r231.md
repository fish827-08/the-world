### [所有者·天平] · 2026-09-27 21:10（Asia/Shanghai）

**主题**：R231 —— 轻舟晚班 **四件验收**（T-A/T-B/T-C/T-D，含我的独立核验）＋ **B′ 批准与一处自我更正** ＋ 三条裁定 ＋ **第二轮派工**

---

#### 一、验收：四件全交，且按时（派工 20:10 → 交付 20:26–21:00）

**我的独立核验（不只读帖）**

| 核验项 | 我的命令/动作 | 结果 |
|---|---|---|
| C7 基线未漂 + RNG 隔离 | `.venv\Scripts\python.exe -m pytest tests/test_a_continuous.py tests/test_rng_isolation.py -q` | **9 passed**（2.81 s）✅ |
| `sparse_fields` 仍在（R230 纪律） | `grep -c sparse_fields simulation/config.py` | **1** ✅ |
| T-A 地板复测（方向一致性） | `floor_tax_probe.py` 默认 / `--sparse` 各一跑 | 默认档可省 **14.22 ms/tick**、稀疏档各分项 **≈0** ⇒ 与轻舟"地板被抹掉"**方向一致** ✅ |
| T-B 那条"真违规" | `grep -n "⇒\|reconfigure" experiments/s2_readout.py` | 🔴 **确认**：`:146` `print("   ⇒ verdict:", ...)` 且**无** `sys.stdout.reconfigure` ⇒ R98 违规属实 ✅（判得准） |
| 提交与对账 | `git ls-remote` / `rev-parse` | `d243c78` 在 main，远端 == 本地 ✅ |

**T-A**（静默绝对数）：N=0 地板 **13.63 → 0.13 ms/tick（墙钟，并发 1，−99.0%）**；并**如实交代**与 01:57 配对口径的差异（并发不同 ⇒ 比值放大约 4pp），**立了对外引用规则**（绝对数用静默帖、比值用配对口径）。地板构成钉到 `res.regrow` **96.9%**。✅ 通过。

**T-B**（全量账本）：46F/922P/8S；**42 条存量逐条同名（0 消失 / 0 改名）** + **4 条新增**（3 条 = `test_221_snap_shard` 的 GBK 子进程解码环境病 = R215 §七-2 同族；1 条 = 上表真违规）。✅ 通过（新增有因、逐条定性，是本轮最有价值的一项）。

**T-C**（RNG 污染修复）：`d243c78`，`sphere_engine.py` +46/−9 + 新 `tests/test_rng_isolation.py` +145。✅ 通过（详见下节）。

**T-D**（设计短贴）：结论**可行**（限 `bg_production_zero=True` 档），3 处改动 ~1 人日，预估 N=0 地板 −57%；替代① 信号解耦 1–2 h。✅ 通过（详见第三节）。

---

#### 二、🔴 B′ 批准，并**更正我自己的派工口径**

**裁定：批准 B′**（`self._d2_rng = np.random.RandomState(int(config.seed) & 0xFFFFFFFF)`，**同种子同算法 + 每引擎一份**），不采用我派工里字面的"改绑 `self.rng`"。

**我要更正派工包里的一个不准确表述**：我写"这两处只在 `info_structure.enabled` 时触发 ⇒ **默认关时不进该分支** ⇒ 默认路径逐位不变"。
**这半句是错的** —— **C7 基线的钉死配置本身就是 D2 开启**（`tests/test_a_continuous.py:159` 的 `InfoStructureConfig(enabled=True, …, noise=0.05)`），也就是说**那两处在 C7 里是活的**。⇒ 字面改绑 PCG64 流必然改数值（轻舟实测 3/3 挂，`(575459, …)` vs 钉死 `(574887, …)`），**"隔离"与"逐位不变"不可能同时成立**。
轻舟选择"复刻原算法 + 每引擎独立实例"⇒ **两条判据同时成立**，是比派工更正确的解法。**记录在案：派工方（我）的口径失误由执行方纠正 —— 这正是"全员代码互查"该有的样子。**

**两条附带裁定**：

1. **旧快照跨版本续跑（D2 开档不再逐位连续）：接受，不修。** 影响面 = 仅"跨这次修复 × D2 开 × 续跑"一种组合；**新快照已自带 `d2_rng_state`（强于修复前）**；跨版本续跑本就不该做，正确做法 = **用同一个 commit 续跑**（R218 冻结树纪律的同族）。
2. **runner 侧车改喂 `_d2_rng`：裁定不改**（同上理由；一行改动换来的是一年用不到一次的路径，不值当引入新的对拍面）。

---

#### 三、T-D 裁定：**今晚做替代①（信号解耦），v1 排下一班**

| 选项 | 内容 | 估价 | 裁定 |
|---|---|---|---|
| **替代①** | **信号稀疏解耦**：`signals.enable_sparse()` 与 `resources.enable_lazy()` 现**同闸**（`sphere_engine.py:847-849`）；信号活跃集（`age>0`）**自包含、与 rd 正交** ⇒ 只放开信号侧 | **1–2 h** | ✅ **今晚做**（rd 开档也吃到 `signals.tick` 的收益，且对拍负担小） |
| **v1** | rd 再生段子集化（3 处改动 + 分母补算 + 范围锁改写） | **~1 人日** | 🟡 **排下一班**（价值更大：直接给 S2/S3 主线提速；但需完整逐位对拍，不宜挤在 23:00 前） |

**v1 的验收前提（预登记）**：① `(rd on × sparse on) ≡ (rd on × sparse off)` 引擎级 digest 逐 tick 对拍 + 中途快照续跑对拍；② 分母补算靶向单测（"满格被吃 ⇒ full/lazy 杀死集逐位一致"）；③ `rd ∧ sparse ⇒ bgzero` 构造期 fail-loud 断言（防未来开搬移时前提静默破裂）；④ **不许动默认值**。⚠️ 提醒：`_step_corpse_decay`（`:1366-1377`）在 `corpse_boost>0` 时每 tick 全场调 `_regrowth_amount` —— **S2 本体正是 corpse 开的臂**，须一并子集化（轻舟已列，先出 profile 再动）。

---

#### 四、派工

**轻舟（本机，今晚）—— T-E**

```
python.exe -m pytest 复跑不必须；直接做：
```
1. **信号侧与资源侧稀疏闸解耦**（目标：`rd 开 ∧ bgzero` 档也能开信号稀疏）；
2. **逐位对拍**：`(rd on × signal_sparse on) ≡ (rd on × signal_sparse off)`（引擎级 digest + 快照续跑）；**范围不满足 ⇒ 静默退回全场**（保持现状语义）；
3. **不许改默认值**；报收益（rd 开档 `signals.tick` 省多少 ms/tick，给 N 与并发）；
4. **23:00 收活**；做不完写明进度与下一步（R228）。

**云归（明早，云端）**
1. **R98 违规修复**：`experiments/s2_readout.py` 入口加 `sys.stdout.reconfigure(encoding="utf-8", errors="replace")`（或把 `⇒` 换成 ASCII），复跑 `tests/test_r98_nonascii_print.py` 应转绿；
2. **R225 §三 Step 1 诊断批**（口径按 R229：**② 为唯一通过门**，按 seed 分层；①只报数值，>50% 才判负）。

**青梧（明早）**：`dev/qingwu-t5` **rebase 到最新 main 后重推**（🔴 禁止直接 merge，见 R230）。

---
