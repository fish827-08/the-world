"""T-G 附核：corpse 关（S2/旗舰 默认档）时，_step_corpse_decay 是否仍付全场代价。"""
from __future__ import annotations
import sys, time
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
from experiments.scaling_rescale import apply_post_build
from experiments.steady_k_probe import make_cfg
from simulation.sphere_engine import SphereEngine

c, notes = make_cfg(seed=42, rows=480, cols=960, pop=2000, patches=480,
                    subpos=True, speed_max=0.125, gain=0.125, subdiv=80,
                    k=2.5, max_count=30000, rgm=1.195)
c.simulation.use_sim_core = False
c.resource_dynamics.enabled = True          # S2/旗舰同档：rd 开、corpse 关（默认）
e = SphereEngine(c)
apply_post_build(e, notes)
assert e.config.corpse_wound.corpse_enabled is False, "前提：corpse 关"

# 计数：_regrowth_amount 被 _step_corpse_decay 调用了几次
calls = [0]
orig_ra = type(e.resources)._regrowth_amount
def counting_ra(self, tick, idx=None):
    calls[0] += 1
    return orig_ra(self, tick, idx)
type(e.resources)._regrowth_amount = counting_ra
try:
    t0 = time.perf_counter()
    for _ in range(300):
        e.step()
    dt = time.perf_counter() - t0
finally:
    type(e.resources)._regrowth_amount = orig_ra

print(f"[corpse 关] 300 tick：墙钟 {dt:.1f}s（{dt/300*1e3:.1f} ms/tick）")
print(f"           _regrowth_amount 总调用 {calls[0]} 次（其中 corpse 路径 0 次 = 期望）")
print(f"           _corpse_boost.max={int(e._corpse_boost.max())} _corpse_energy.sum={float(e._corpse_energy.sum()):.0f}"
      f"（应恒 0 ⇒ 无全场调用、无 boost）")
# 单独计时 _step_corpse_decay（关档下的残留代价）
import timeit
t = timeit.timeit(lambda: e._step_corpse_decay(), number=200) / 200 * 1e3
print(f"           _step_corpse_decay 关档单次 = {t:.3f} ms/tick（两条全场掩码比较的残留）")
