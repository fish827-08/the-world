"""合并后冒烟：smell ON + HM ON 同时开启，Python 路径 vs Rust 路径逐位对拍。

这是两侧测试都没覆盖的**交叉场景**（分支测试只单开 smell；HM 测试只单开 HM）。
判据：同种子同配置、两路径状态逐位一致；且与「双双关闭」基线不同（证明两条接线都活着）。
"""
import numpy as np

from simulation.config import SimConfig
from simulation.sphere_engine import SphereEngine


def run(rust: bool, smell: bool, hm: bool, seed: int = 11, ticks: int = 120):
    c = SimConfig(seed=seed)
    c.world.rows, c.world.cols = 8, 12
    c.population.initial_count = 12
    c.resources.distribution = "uniform"
    c.simulation.use_sim_core = rust
    if smell:
        c.smell.channels = ("food", "risk", "kin")
        c.smell.use_in_move = True
    if hm:
        c.hunger_mod.enabled = True
        c.hunger_mod.alpha = 0.5
        c.hunger_mod.beta = 0.5
    e = SphereEngine(c)
    for _ in range(ticks):
        e.step()
    P = len(e._id)
    return (
        tuple(int(x) for x in e._flat[:P]),
        tuple(round(float(x), 12) for x in e._energy[:P]),
        int(e._tick),
    )


base_rust = run(True, False, False)
base_py = run(False, False, False)
print("两路径基线(全关)一致:", base_rust == base_py)

both_rust = run(True, True, True)
both_py = run(False, True, True)
print("两路径(双开)一致:", both_rust == both_py)

print("双开 vs 全关(rust)不同:", both_rust != base_rust)
print("双开 vs 全关(py)不同:", both_py != base_py)

hm_only_rust = run(True, False, True)
smell_only_rust = run(True, True, False)
print("HM-only vs 全关不同:", hm_only_rust != base_rust)
print("smell-only vs 全关不同:", smell_only_rust != base_rust)
print("双开结果:", both_rust)
