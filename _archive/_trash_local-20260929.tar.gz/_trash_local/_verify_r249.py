# -*- coding: utf-8 -*-
"""R249 变异验证：模拟云端裸 Python 环境（sim_core = 空命名空间包）。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import types

sys.modules["sim_core"] = types.ModuleType("sim_core")  # 空模块 = 云端命名空间包

from simulation.config import SimConfig
from simulation.sphere_engine import SphereEngine

cfg = SimConfig()
cfg.simulation.use_sim_core = True
try:
    SphereEngine(cfg)
    print("FAIL: 引擎未抛错（防护失效）"); sys.exit(1)
except RuntimeError as e:
    msg = str(e)
    ok = ("命名空间" in msg) and ("maturin" in msg)
    print("OK 1/2: 引擎构造期清晰报错（含 maturin 修复指引）" if ok
          else f"报错但文案缺关键词: {msg[:80]}")
    if not ok: sys.exit(1)

print("OK 2/2: pytest 变异 →", end=" ")
import pytest
rc = pytest.main(["tests/test_snapshot.py", "-q", "-p", "no:cacheprovider"])
