#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""只读核查：把候选清理项的性质判清楚（不做任何删除/移动）。"""
import os
import subprocess
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

ROOT = Path(r"C:\Users\圣羽\Desktop\temp")
REPO = ROOT / "tempCode" / "the-world"


def human(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f}{u}"
        n /= 1024
    return f"{n:.1f}TB"


def size_of(p: Path):
    total = nf = 0
    for dp, dn, fn in os.walk(p):
        for f in fn:
            try:
                total += os.path.getsize(os.path.join(dp, f))
                nf += 1
            except OSError:
                pass
    return total, nf


def head(p: Path, n=10):
    print(f"\n--- {p} ---")
    if not p.exists():
        print("（不存在）")
        return
    if p.is_file():
        print(f"FILE {human(p.stat().st_size)}")
        return
    try:
        with os.scandir(p) as it:
            items = sorted(it, key=lambda e: e.name)[:n]
    except OSError as exc:
        print(f"读取失败：{exc}")
        return
    for e in items:
        q = Path(e.path)
        if e.is_dir(follow_symlinks=False):
            b, nf = size_of(q)
            print(f"  [DIR ] {e.name:<34} {human(b):>9}  {nf} files")
        else:
            try:
                print(f"  [FILE] {e.name:<34} {human(e.stat().st_size):>9}")
            except OSError:
                pass
    extra = len(list(os.scandir(p))) - len(items)
    if extra > 0:
        print(f"  ...（另有 {extra} 项）")


def is_git(p: Path):
    return (p / ".git").exists()


print("=" * 78)
print("A. 仓库内 `.git` 与 worktree 现状")
print("=" * 78)
for args in (["worktree", "list"], ["status", "--short"], ["stash", "list"]):
    r = subprocess.run(["git", *args], cwd=REPO, capture_output=True, text=True,
                       encoding="utf-8", errors="ignore")
    print(f"\n$ git {' '.join(args)}")
    print((r.stdout or r.stderr or "").strip()[:900] or "（空）")

print("\n" + "=" * 78)
print("B. `_rerun_logs` 内部构成（快照是否可弃）")
print("=" * 78)
rl = REPO / "_rerun_logs"
if rl.is_dir():
    for dp, dn, fn in os.walk(rl):
        rel = os.path.relpath(dp, rl)
        if rel.count(os.sep) <= 0:
            b, nf = size_of(Path(dp))
            print(f"  {rel:<40} {human(b):>9}  {nf} files")
    snap = rl / "snap"
    if snap.is_dir():
        b, nf = size_of(snap)
        npz = sum(1 for dp, _dn, fn in os.walk(snap) for f in fn if f.endswith(".npz"))
        print(f"\n  ⇒ `snap/` = {human(b)} / {nf} files / 其中 .npz = {npz}")

print("\n" + "=" * 78)
print("C. 仓库内各「陈旧副本 / 备份 / 临时」项（判断是否有 .git、是否有近期改动）")
print("=" * 78)
for name in ("_backup_full_20260912", "_gitee_review", "digital-life-sphere",
             "digital_life", ".git.backup-20260913-pre-slim", ".git.backup-20260912",
             "data", "_reclone_tmp", "_wt_r19", "sim_core", "_clockcheck",
             "_tmp_chk_1789751321", "long_bat_rp300_m025_s42.csv"):
    p = REPO / name
    if not p.exists():
        print(f"  {name:<36} （不存在）")
        continue
    b, nf = size_of(p)
    print(f"  {name:<36} {human(b):>9} {nf:>6} files  git={is_git(p)}")

print("\n" + "=" * 78)
print("D. 仓库内 `_tmp_pytest_*` / `_pt_h*` / `_tmp_*` 汇总")
print("=" * 78)
tot = cnt = 0
for e in sorted(os.scandir(REPO), key=lambda x: x.name):
    nm = e.name
    if nm.startswith("_tmp") or nm.startswith("_pt_h"):
        b, nf = size_of(Path(e.path))
        tot += b
        cnt += 1
print(f"  共 {cnt} 个临时目录，合计 {human(tot)}")

print("\n" + "=" * 78)
print("E. `tempCode` 内其他项目（需你确认是否还要）")
print("=" * 78)
for name in ("rag-kb", "agentmemory-use", "AI-CODE-DEVELOPMENT-RULES.md"):
    p = ROOT / "tempCode" / name
    if p.exists():
        b, nf = size_of(p)
        print(f"  {name:<36} {human(b):>9} {nf:>6} files  git={is_git(p)}")
head(ROOT / "tempCode" / "rag-kb", 6)

print("\n" + "=" * 78)
print("F. `Desktop\\temp` 顶层散落文件/目录的性质")
print("=" * 78)
for name in ("extReview", "extReview2", "_r165_old", "_r163_old", "_bt135full",
             "_bt_w0full3", "_bt_w0full2", "_bt_w0full", "_r163_bt3", "_r163_bt",
             "_bt_r110"):
    p = ROOT / name
    if p.exists():
        b, nf = size_of(p)
        print(f"  {name:<36} {human(b):>9} {nf:>6} files  git={is_git(p)}")
head(ROOT / "extReview", 6)
