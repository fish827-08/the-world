"""探针：快照恢复后首次死亡压缩 —— ARS 六数组长度未同步（R215-b，temp 不入库）。"""
from __future__ import annotations

import sys
import tempfile
import os

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

sys.path.insert(0, ".")
from simulation.config import SimConfig            # noqa: E402
from simulation.sphere_engine import SphereEngine  # noqa: E402

cfg = SimConfig(seed=42)
cfg.world.rows = 60
cfg.world.cols = 120
cfg.population.initial_count = 100
cfg.resources.distribution = "patchy"
cfg.simulation.use_sim_core = True
cfg.organisms.maturity_fraction = 1e-6

e1 = SphereEngine(cfg)
for _ in range(150):
    e1.step()
print(f"save: alive={len(e1._id)} next_id={e1._next_id} "
      f"out_taken={len(e1._out_taken)} ars_ext={len(e1._ars_extensive)}")

with tempfile.NamedTemporaryFile(suffix=".npz", delete=False) as f:
    path = f.name
try:
    e1.save_snapshot(path)
    e2 = SphereEngine.load_snapshot(path, config=cfg)
    print(f"load: alive={len(e2._id)} next_id={e2._next_id} "
          f"out_taken={len(e2._out_taken)} ars_ext={len(e2._ars_extensive)}")
    for t in range(50):
        e2.step()
    print("NO CRASH (unexpected)")
except IndexError as exc:
    print(f"IndexError at tick {t}: {exc}")
finally:
    os.unlink(path)
