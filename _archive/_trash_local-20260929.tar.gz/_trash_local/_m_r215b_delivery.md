### [本地开发·性能线] · 2026-09-26 23:45

# R215 §七-1 交付：快照恢复账本长度缺陷已修（`97b7fc2`）+ 🔴 同族第二缺陷**待裁**（ARS 六数组未进快照）

**已合 main：`97b7fc2`（已 push，`ls-remote` 对账一致）。** 修法 = 你批的"补齐改到赋值之后"。

## 一、§七-1 本体：账本补齐挪到 `_next_id` 赋值之后

**被守护缺陷**：`load_snapshot` 把"`_id` 键控账本补齐/缺键兜底"放在**元数据（`_next_id`）赋值之前** ⇒
补齐长度按**构造期** `_next_id`（= `initial_count`，`__init__` 建的初始种群）计算：

| 快照形态 | 原行为 | 后果 |
|---|---|---|
| 无探针键（`measure_resp`/`oracle` 均关 = **默认档**） | `need = initial_count − initial_count = 0` | 12 个账本**停在 initial_count**，而 `_next_id` 已是快照值 ⇒ 续跑首次由"第二世代"个体繁衍时 `self._rs_children[self._id[ri]] += 1` **越界** |
| 开 measure/oracle | 同上（文件里的账本长度正确，但缺 delta 键时兜底按 stale 长度建） | `_rs_observed[alive_ids]` 越界 / 数组族不等长 |

**修法**（`simulation/sphere_engine.py::load_snapshot`）：把整段补齐/兜底**移到 §10 `_next_id` 赋值之后**。
🔴 数值语义未变 —— 账本内容仍**只**来自快照（缺键 ⇒ 全零 = 未观测/未发射），变的只是"补齐到哪个长度"
⇒ 全新运行不受影响、无探针档续跑轨迹逐位不变（既有 `test_continue_after_load_bitwise_equal` 等全绿）。

**`[实测]` 修前回放**（`git worktree` @ `94ca190`，跑本批新守卫测试）：

```
修前：assert 100 == 229            （_rs_children 长度 100 != _next_id 229）
      2 failed, 1 xfailed
同一复现的端到端：IndexError: index 133 is out of bounds for axis 0 with size 102
                  （= _rs_children[self._id[ri]]，续跑 tick 0）
修后：14 passed, 1 xfailed         （同一复现推进到 tick 3，见 §二）
```

**守卫** `tests/test_snapshot.py::TestSnapshotIdLedgerLengths`（3 例，照你批的 `load → len(账本) == _next_id`）：
① 无探针键快照的补齐长度必须用**快照** `next_id`（确定性，不依赖出生率）；
② 真路径（`maturity_fraction=1e-6` 跑出多世代）存/载后 12 账本 `len == _next_id` 且尾部可写（出生路径索引形态）；
③ 全量普查"恢复后所有按个体数组长度 == 存活数" —— **本批借此抓出 §二**。

## 二、🔴 新发现（待裁）：14.9 ARS 六数组**既未存、也未恢复** —— 同一流程的下一个拦路虎

修完 §七-1 后，同一复现**换了位置继续崩**（`[实测]`，两棵树同 seed 同配方）：

| 树 | 结果 |
|---|---|
| 修前 `94ca190` | 恢复后 **tick 0**：`IndexError: index 133 is out of bounds ... size 102`（**账本族**） |
| 修后（本批） | 恢复后 **tick 3**：`IndexError: boolean index did not match ... size of axis is 109 but ... 135`（**ARS 族**） |

**根因**：`_out_taken` / `_feed_fast` / `_feed_slow` / `_ars_extensive` / `_heading` / `_giveup_ct`
（14.9 ARS 的六个按个体数组）**没有进 `save_snapshot` 的任何键**，`load_snapshot` 也不恢复/补齐
⇒ 恢复后长度停在构造期 `initial_count`，而 `_id`/`_flat` 等已按存活数载入
⇒ **首次死亡压缩**（`self._out_taken[:P][keep]`）即越界。
即便某次侥幸等长（存活数恰 == initial_count），也**丢 ARS 状态**（heading/giveup/咬到量/赶路模式）
⇒ 恢复后轨迹不逐位 —— 与"快照续跑必须逐位一致"的既有契约冲突。

**修法两选（请裁一句）**：

| 方案 | 内容 | 影响 |
|---|---|---|
| **A（推荐）保存 + 恢复** | `save_snapshot` 增 6 键（`[:P]`，同其它按个体数组）；`load_snapshot` 恢复 + 旧快照缺键 ⇒ 按"出生即赶路、heading=-1、giveup=0、咬到量=0"初始化（= 现有 `__init__` 语义） | 续跑**轨迹逐位**；旧快照仍可读；约 15 行；snapshot 版本不变（只加键） |
| B 载入重置 | load 侧把这 6 数组**重置为 `len(_id)`**（不存） | 最小改动（约 6 行）、修掉崩溃；但续跑**丢 ARS 状态** ⇒ 不逐位 |

我倾向 **A**（既然要修，就让"快照续跑逐位"这条契约真正成立；B 只能算止血）。
现在有一个 `xfail(strict=True)` 测试把这 6 个数组钉着（修好后必须删 xfail），你裁哪条我照办。

## 三、取证（`[实测]`，全部本机）

| 检验 | 结果 |
|---|---|
| 修前回放（worktree @ `94ca190` + 新守卫） | **2 failed**（`100 != 229`）⇒ 缺陷确在 |
| 修后同守卫 | **14 passed / 1 xfailed**（`tests/test_snapshot.py` 全文件） |
| C7 三件套（`test_135/137/138`） | **49 passed**（digest 未变 ⇒ 新运行不受影响） |
| 快照消费方 9 个测试文件 | **124 passed / 1 skipped** |
| 全量（`--ignore=tests/test_broker.py`） | **42 failed / 887 passed / 8 skipped / 1 xfailed**（337.9 s）—— 失败名与上一批（42/885/8）**逐项一致**（diff 空）⇒ 42 例全为环境性；新增 3 例按预期（2 passed + 1 xfail） |

## 四、下一步

- **P2② 移动决策循环向量化**（R213 §六 ③、R215 §六"决定成败的一刀"）—— 等 §二 裁定期间即开工。
- 已按 R215 §八（㉒）：本批用 `git worktree` 做修前回放（不动主工作区，用毕已移除）；此后 merge/rebase 前先上板报一句。
- 旧项：42 例环境失败按 R215 §七-2 **不修**（备案）。`max_count` 30 000 保留。
