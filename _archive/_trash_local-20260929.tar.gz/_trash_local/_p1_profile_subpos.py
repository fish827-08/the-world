"""P1 profile：T4 热路径（480×960 + subpos @ k=2.5）的耗时归因（scratch，不入库）。

回答派工单 §三 的问题：**`~55 μs/体` 到底花在哪几段？**

设计要点（为什么这么测）
----------------------
1. **代码快照 = 独立 worktree @ 固定 commit**（`--root`）⇒ 数字可归因到已提交代码；
   不测脏工作树（此刻 `simulation/sphere_engine.py` 正被另一条线改）。
2. **配置复用 `experiments/steady_k_probe.make_cfg`**（同一函数、同一参数序列）
   ⇒ 与 T4 批次逐位同配置，不另写一份"看着一样"的构造（漂移源）。
3. **归因用 tottime（自耗时）做文件级汇总**：tottime 可加、不重复计数；
   cumtime 相加会把调用链算两遍 ⇒ 只用于列 Top-N 看形态。
   分母取 `pstats` 自己的 `total_tt`（整段 profile 的真实总时长）。
4. **BLAS 线程在 import numpy 前钉成 1** ⇒ 与多路并行跑批的实际条件一致。
5. 先 `--warmup` 把 N 养到接近平台期再采样（成本 ∝ N，幼体期 μs/体 会虚高）。
6. profiler 自身有开销 ⇒ 另测一段**无 profiler** 的 ms/tick 作真值，两个数都报。

用法：
    .venv\\Scripts\\python.exe _trash_local/_p1_profile_subpos.py \\
        --root "C:\\Users\\圣羽\\AppData\\Local\\Temp\\_wt_p1_profile" \\
        --warmup 5000 --profile-ticks 200 --out _trash_local/_p1_top.txt
"""
from __future__ import annotations

import argparse
import cProfile
import io
import os
import pstats
import subprocess
import sys
import threading
import time
from pathlib import Path

# --- R98：Windows GBK 控制台兜底 ---
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# BLAS 线程必须在 import numpy 之前钉
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ.setdefault(_v, "1")

import numpy as np  # noqa: E402  （必须在上面那批 env 变量之后导入）

# 文件级归因的桶（按出现频次排；命中即止）
_BUCKETS = (
    "simulation/sphere_engine.py",
    "world/subpos.py",
    "world/resource_dynamics.py",
    "world/resource_field.py",
    "world/light_and_temperature.py",
    "world/signal_field.py",
    "world/sphere_world.py",
    "simulation/genes.py",
    "simulation/oracle.py",
    "observatory/",
    "numpy/_core", "numpy/lib", "numpy/", "<__array_function__ internals>",
    "{built-in", "{method", "{numpy",
)


def _bar(cur: int, tot: int, extra: str = "", width: int = 26) -> str:
    frac = cur / max(tot, 1)
    done = int(frac * width)
    return f"[{'#' * done}{'.' * (width - done)}] {frac * 100:5.1f}% {extra}"


def _norm(fname: str) -> str:
    """pstats 在 Windows 下给**反斜杠绝对路径** ⇒ 统一成正斜杠 + 去根前缀再匹配桶。"""
    f = fname.replace("\\", "/")
    f = f.split("/the-world/")[-1] if "/the-world/" in f else f
    f = f.split("/_wt_p1_profile/")[-1] if "/_wt_p1_profile/" in f else f
    f = f.split("/site-packages/")[-1] if "/site-packages/" in f else f
    return f


def _bucket(fname: str) -> str:
    f = _norm(fname)
    for b in _BUCKETS:
        if b in f:
            return b
    return f.split(":")[0] if ":" in f else f


def _parse_rows(raw: str) -> list[tuple[float, str]]:
    """从 pstats 文本表里取 (tottime, 函数位置)。返回按 tottime 降序。

    只认形如 `<abs path>:<line>(<func>)` 的尾列 ⇒ 滤掉 "… primitive calls) in 0.5 s"
    这类表头行（它们首 token 也是数字，会被误当数据）。
    """
    out: list[tuple[float, str]] = []
    for line in raw.splitlines():
        parts = line.split()
        if len(parts) < 6 or not parts[0][0].isdigit():
            continue                       # 跳表头/说明行/空行
        fname = parts[-1]
        if ":" not in fname or "(" not in fname or not fname.endswith(")"):
            continue
        try:
            tot = float(parts[1])
        except ValueError:
            continue
        out.append((tot, fname))
    return sorted(out, key=lambda x: -x[0])


# ---------------------------------------------------------------------------
# 行级采样器（为什么必须有）
# ---------------------------------------------------------------------------
# cProfile 的分辨率止于**函数**。而本项目最热的是 `_step_population`
# （sphere_engine.py 2322→4023，**1 701 行的单体函数**）⇒ 函数级归因到此失效：
# 知道"它占 44%"回答不了派工单 §三 的"哪几段花掉的"，也就定不了 P2 的攻击面。
#
# 做法：后台线程每 `sample_ms` 毫秒抓一次主线程栈（`sys._current_frames()`），
# 统计**最深的项目内帧**的行号。
#   · 零改被测代码（只在观测侧加线程）⇒ 不碰 RNG、不改轨迹；
#   · 采样式 ⇒ 开销 ~1%（不像 settrace 会把解释器拖慢一个数量级）；
#   · 计数是**样本数**不是秒 ⇒ 报告里同时给总样本数，占比按样本算。
class LineSampler:
    def __init__(self, roots: tuple[str, ...], interval_s: float = 0.001) -> None:
        self.roots = roots                 # 只统计这些目录下的帧（= 被测快照根）
        self.interval = interval_s
        self.hits: dict[tuple[str, int], int] = {}
        self.func_hits: dict[str, int] = {}
        self.stack_hits: dict[str, int] = {}
        self.n = 0
        self._stop = threading.Event()
        self._th = threading.Thread(target=self._run, daemon=True)

    def _in_project(self, fname: str) -> bool:
        return any(fname.startswith(r) for r in self.roots)

    def _run(self) -> None:
        main_id = threading.main_thread().ident
        while not self._stop.is_set():
            time.sleep(self.interval)
            frame = sys._current_frames().get(main_id)
            if frame is None:
                continue
            deepest = None
            chain: list[str] = []
            f = frame
            while f is not None:
                code = f.f_code
                if self._in_project(code.co_filename):
                    if deepest is None:
                        deepest = (code.co_filename, f.f_lineno, code.co_name)
                    chain.append(f"{code.co_name}@{Path(code.co_filename).name}")
                f = f.f_back
            self.n += 1
            if deepest is None:
                self.func_hits["<numpy/C 内部>"] = self.func_hits.get("<numpy/C 内部>", 0) + 1
                continue
            fn, ln, name = deepest
            key = (fn, ln)
            self.hits[key] = self.hits.get(key, 0) + 1
            fk = f"{Path(fn).name}::{name}"
            self.func_hits[fk] = self.func_hits.get(fk, 0) + 1
            top = " ← ".join(chain[:4])
            self.stack_hits[top] = self.stack_hits.get(top, 0) + 1

    def start(self) -> "LineSampler":
        self._th.start()
        return self

    def stop(self) -> None:
        self._stop.set()
        self._th.join(timeout=2.0)

    def report(self, top: int, source_root: Path) -> None:
        if self.n == 0:
            print("  （无样本，跳过）")
            return
        print(f"\n== 五、行级采样（最深项目帧；共 {self.n} 个样本，间隔 {self.interval * 1e3:.1f} ms）==")
        print(f"  【按函数】")
        for k, v in sorted(self.func_hits.items(), key=lambda kv: -kv[1])[:10]:
            print(f"    {v / self.n * 100:5.1f}%  {k}")
        print(f"\n  【最热行 Top-{top}】（含源码，直接看是哪一段）")
        cache: dict[str, list[str]] = {}
        for (fn, ln), v in sorted(self.hits.items(), key=lambda kv: -kv[1])[:top]:
            if fn not in cache:
                try:
                    cache[fn] = Path(fn).read_text(encoding="utf-8").splitlines()
                except Exception:
                    cache[fn] = []
            src = cache[fn][ln - 1].strip() if 0 < ln <= len(cache[fn]) else "?"
            rel = fn
            for tag in ("/_wt_p1_profile/", "/the-world/"):
                if tag in rel:
                    rel = rel.split(tag)[-1]
                    break
            print(f"    {v / self.n * 100:5.1f}%  {rel}:{ln}  {src[:96]}")


def main() -> None:
    ap = argparse.ArgumentParser(description="P1 profile：T4 热路径耗时归因")
    ap.add_argument("--root", required=True, help="代码快照根（worktree 路径）")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--pop", type=int, default=5000,
                    help="初始个体数。**T4 用的是 5000（板 09-26 20:34 运行计划帖 §一"
                         "'初始 5000（同上轮）'），探针 CLI 默认却是 2000，"
                         "且 summary.json 的 switches 不记 pop** ⇒ 必须显式传")
    ap.add_argument("--warmup", type=int, default=5000,
                    help="采样前先跑的 tick 数（把 N 养到接近平台期）")
    ap.add_argument("--profile-ticks", type=int, default=200)
    ap.add_argument("--baseline-ticks", type=int, default=60,
                    help="无 profiler 复测的 tick 数（真值 ms/tick）")
    ap.add_argument("--top", type=int, default=20)
    ap.add_argument("--sample-ms", type=float, default=1.0, help="行级采样间隔（毫秒）")
    ap.add_argument("--line-ticks", type=int, default=250, help="行级采样窗口的 tick 数")
    ap.add_argument("--line-top", type=int, default=12, help="最热行打印条数")
    ap.add_argument("--out", default="", help="落 pstats 原文的路径（可选）")
    a = ap.parse_args()

    root = Path(a.root).resolve()
    if not (root / "simulation" / "sphere_engine.py").is_file():
        sys.exit(f"根不对：{root} 下没有 simulation/sphere_engine.py")
    commit = subprocess.run(["git", "-C", str(root), "rev-parse", "--short", "HEAD"],
                            capture_output=True, text=True).stdout.strip()
    dirty = subprocess.run(["git", "-C", str(root), "status", "--porcelain"],
                           capture_output=True, text=True).stdout.strip()
    sys.path.insert(0, str(root))

    from simulation.sphere_engine import SphereEngine             # noqa: E402
    from experiments.steady_k_probe import (                      # noqa: E402
        apply_post_build, make_cfg,
    )

    # T4 口径（读回自 results/t4_steady_k_k25/s42_full.summary.json 的 switches）
    cfg, notes = make_cfg(a.seed, 480, 960, a.pop, 480, True,
                          0.125, 0.125, 80, 2.5, 30000)
    print("== P1 profile ==")
    print(f"  代码快照 : {root} @ {commit}" + ("  ⚠️ 树脏" if dirty else "  （干净）"))
    print("  配置     : 480x960 patches=480 k=2.5 subpos=on speed_max=0.125 "
          "gain=0.125 subdiv=80 max_count=30000 seed=%d pop=%d" % (a.seed, a.pop))
    print(f"  重标项   : {len(notes)} 个（走项目统一四类面额表）")

    t0 = time.time()
    eng = SphereEngine(cfg)
    apply_post_build(eng, notes)
    print(f"  构造     : {time.time() - t0:.1f} s")

    # ---------- 预热：把 N 养到接近平台期（ETA 只用实测样本推，R189）----------
    #   同时把每个采样窗口的 (N, ms/tick) 记下来 ⇒ 末尾回归 `ms/tick = a + b·N`：
    #   a = **世界项**（∝ 格数，与个体无关，降不下来除非改网格遍历）
    #   b = **个体项**（P2 向量化的可攻击面）
    #   ⇒ 派工单 §三 用"μs/体"单值描述热路径，会把这两项混在一起；这里拆开。
    step = eng.step
    slice_t = time.perf_counter()
    last = 0
    samples: list[tuple[int, float]] = []
    for t in range(1, a.warmup + 1):
        step()
        if t % 500 == 0 or t == a.warmup:
            dt = (time.perf_counter() - slice_t) / max(t - last, 1) * 1e3
            last = t
            slice_t = time.perf_counter()
            N = int(len(eng._flat))
            samples.append((N, dt))
            eta = (a.warmup - t) * dt / 1e3 / 60.0
            print("  " + _bar(t, a.warmup,
                              f"t={t:<6} N={N:<6} {dt:6.1f} ms/tick  ETA {eta:4.1f} min"),
                  flush=True)

    N = int(len(eng._flat))
    if N == 0:
        sys.exit("预热后已灭绝，无法 profile")

    # ---------- 真值：无 profiler ----------
    t0 = time.perf_counter()
    for _ in range(a.baseline_ticks):
        step()
    ms_plain = (time.perf_counter() - t0) / a.baseline_ticks * 1e3

    # ---------- 窗口 B：cProfile（函数/文件级）----------
    pr = cProfile.Profile()
    t0 = time.perf_counter()
    pr.enable()
    for _ in range(a.profile_ticks):
        step()
    pr.disable()
    ms_prof = (time.perf_counter() - t0) / a.profile_ticks * 1e3
    N_prof = int(len(eng._flat))

    # ---------- 窗口 C：行级采样（**不叠 cProfile** ⇒ 无 1.3× 开销污染）----------
    sampler = LineSampler((str(root),), a.sample_ms / 1e3).start()
    t0 = time.perf_counter()
    for _ in range(a.line_ticks):
        step()
    ms_line = (time.perf_counter() - t0) / a.line_ticks * 1e3
    sampler.stop()
    N_line = int(len(eng._flat))

    buf = io.StringIO()
    ps = pstats.Stats(pr, stream=buf)
    ps.sort_stats("tottime").print_stats(a.top)
    raw = buf.getvalue()
    if a.out:
        Path(a.out).write_text(raw, encoding="utf-8")
    rows = _parse_rows(raw)
    total_tt = ps.total_tt if ps.total_tt > 0 else sum(t for t, _ in rows)

    print("\n== 一、绝对耗时 ==")
    print(f"  预热末 N = {N:>6}｜**无 profiler** {ms_plain:6.1f} ms/tick = "
          f"{ms_plain * 1e3 / N:5.1f} μs/体   ← T4 交付表的 130.1 ms/tick 同量级即口径对上了")
    print(f"  采样末 N = {N_prof:>6}｜带 profiler   {ms_prof:6.1f} ms/tick"
          f"（放大 {ms_prof / ms_plain:4.2f}× ⇒ 只用于**占比**，不当绝对值用）")

    print(f"\n== 二、函数 Top-{a.top}（按 tottime）==")
    print(f"  profile 总时长 = {total_tt:.2f} s")
    for tot, fname in rows[:a.top]:
        print(f"  {tot:7.2f} s  {tot / total_tt * 100:5.1f}%   {_norm(fname)}")

    print("\n== 三、按文件汇总 tottime（可加，分母 = profile 总时长）==")
    buckets: dict[str, float] = {}
    for tot, fname in rows:
        buckets[_bucket(fname)] = buckets.get(_bucket(fname), 0.0) + tot
    listed = 0.0
    for k, v in sorted(buckets.items(), key=lambda kv: -kv[1]):
        listed += v
        print(f"  {v:7.2f} s  {v / total_tt * 100:5.1f}%   {k}")
    print(f"  ------ 上表已覆盖 {listed / total_tt * 100:.1f}%"
          f"（余下是 Top-{a.top} 之外的长尾）")

    # ---------- 四、世界项 vs 个体项分解（对 (N, ms/tick) 线性回归）----------
    if len(samples) >= 4:
        xs = np.array([s[0] for s in samples], dtype=float)
        ys = np.array([s[1] for s in samples], dtype=float)
        b, aa = np.polyfit(xs, ys, 1)
        pred = aa + b * xs
        r2 = 1.0 - ((ys - pred) ** 2).sum() / max(((ys - ys.mean()) ** 2).sum(), 1e-12)
        print("\n== 四、耗时分解：`ms/tick = 世界项 + 个体项 × N`（对预热期实测样本回归）==")
        print("  样本（N, ms/tick）: " + "  ".join(f"{int(n)}→{m:.1f}" for n, m in samples))
        print(f"  世界项 a = {aa:6.1f} ms/tick（N=0 也跑不掉的地板，∝ 格数 460 800）")
        print(f"  个体项 b = {b * 1e3:6.1f} μs/体（**这才是 P2 向量化的可攻击面**）")
        print(f"  拟合 R² = {r2:.3f}｜在 N={N_prof} 处预测 {aa + b * N_prof:.1f} ms/tick"
              f"（实测无 profiler {ms_plain:.1f}）")
        print(f"  ⇒ 该 N 下世界项占 {aa / (aa + b * N_prof) * 100:.0f}%、个体项占 "
              f"{b * N_prof / (aa + b * N_prof) * 100:.0f}%"
              "（若世界项占大头 ⇒ 只优化逐体循环收益有限）")

    sampler.report(a.line_top, root)
    print(f"\n  行级采样窗口实测 {ms_line:.1f} ms/tick（N={N_line}，**未叠 cProfile**）")


if __name__ == "__main__":
    main()
