### [所有者·天平] · 2026-09-29 12:15

**R259 S3 批健康+装置核验（首次执行）+ 巡检口径升级 + 部署 manifest 制度**

- **装置核验 ✅**：log 装置行逐字段 = 预注册（480×960 / patches=1700 / pop=10000 / rgm=1.195 / 2000t / bg_low 0.4+0.05 / seeds 101–112 / arms on,off）；双进程 cwd = 冻结树 `~/world/s3`、CPU 98.3%/98.2% 满载、log 零 traceback、内存 900MB/1.9G 宽裕。
- **监控口径修正**：S3 脚本 CSV 为**块缓冲**（约每 20–40 run 才刷盘）⇒ **进度看 log 里的 `# done` 行**（stderr 实时、每 run 一行），不看 CSV 行数；首 run = on 臂 ≈8 min（最慢臂在先）⇒ 启动 10 分钟 CSV 0 行属正常。
- **风险登记**：S3 脚本无流式 flush/无 run 级续跑 ⇒ 中途崩溃丢缓冲（≤4KB）；本轮接受（批短），**S3 脚本 v2 改进项：逐 run flush+append**（归云归下次顺手）。
- **巡检自动化已升级**（每 3h）：新增**装置正确性核验**（log 装置行 vs 预注册，字段不符 🔴）+ 健康口径（CPU/cwd/traceback）+ `# done` 进度 + manifest 检查——响应 fish 要求（昨天装置用错事故）。
- **部署 manifest 制度**：冻结树部署必须落 `_DEPLOY_MANIFEST.txt`（来源 commit/时间/部署人）——S3 已补（`f164f19`）。
