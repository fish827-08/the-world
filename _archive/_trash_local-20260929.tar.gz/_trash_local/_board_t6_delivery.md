### [本地开发·性能线] · 2026-09-26 20:00

**T6 交付：A2b 覆盖扫描修复** —— commit `ca5bf3c`，已推 `gitee/main`（`ls-remote` = `ca5bf3c…551f` 两边一致）。
交付物：`tools/tick_denomination_audit.py`（改）+ `tests/test_a2b_tick_audit_coverage.py`（新，9 例，1.5 s 全绿）。

## 一、验收门 = 变异测试（先证"检得动"，再谈报告）

`[实测]` 现场转录（脚本 `_t6_mutation_transcript.py`）：

```
[0] 注入前 sha256[:12] = ce68f91b5a28
[1] 注入前：命中行 = （无）            ✅
[2] 注入 `_A2B_MUTANT_DURATION_TICKS = 137`（第 461 行）
[3] 注入后：命中行 = ['world/light_and_temperature.py:461  DURATION  137 ｜ _A2B_MUTANT_DURATION_TICKS = 137  # duration']
[4] 还原后 sha256[:12] = ce68f91b5a28 ｜ 一致 = True
[5] 还原后：命中行 = （无）            ✅
```

关键点：变异打在 **`world/light_and_temperature.py`** —— 该文件**旧版根本不在清单里**（验收件 §3.2 记录：同一注入旧版**完全扫不出**）。
⇒ 这不是"工具没坏"的自证，是**新增覆盖真的生效**的证明。该变异已固化为自动化测试 S3（不再依赖手工转录）。

## 二、覆盖修复：4 条路径（含幽灵）→ glob 派生 11 文件

`[实测]` 旧清单原文（`ca5bf3c~1`）：

```python
_SCAN_FILES = ["simulation/sphere_engine.py", "simulation/config.py",
               "world/resources.py", "world/signal_field.py"]
```

* `world/resources.py` 是**幽灵路径**（真名 `resource_field.py`）⇒ 静默 no-op；
* 实扫 3 个文件，其中 `config.py` 的数值面额本由 §3.1 枚举覆盖（重复）；
* **`world/` 6 个业务文件只扫到 1 个**，`simulation/genes.py` 也漏。

⇒ 新：`_SCAN_DIRS=("simulation","world")` **glob 派生**（排除 `__init__.py`/`config.py`），`[实测]` **11 个文件**（simulation 5 + world 6），新增文件自动纳入。
**fail-loud 四则**（缺一则重新引入静默漏扫，退出码 2）：目录不存在／单目录 0 文件／低于数量下限（单目录 4、总 8）／派生文件不存在 ⇒ `CoverageError`。
覆盖自检 **§3.0 恒跑**（与 `--no-literals` 解耦、fail-fast）——堵死"目录被移走但 rc=0"。

## 三、噪声过滤（只降噪不删）

`[实测]` **1186 条字面量 ⇒ 🔇 过滤 958（80.8%）｜净剩 228｜关键词 17**（DURATION 7 + PROB 1 + RATE 9）。
规则：`round(x,n)` 精度位／`+=` 计数操作数／负整数哨兵／下标·切片索引／`max·min·range·enumerate` 守卫参数／十六进制掩码／字面 0·1·2 且整行无 tick 关键词。被过滤项**仍落 JSON**。
旧版 108 条"命中"抽前 15 条**几乎全误报**（`round(x,9)` 的 9、字面 `1.0`、`self._tick += 1` 的 1）⇒ 现在真信号不再被淹没。

## 四、新覆盖才看得到的**待裁项**（我只报事实，语义归所有者/老工）

* 🔴 `world/resource_dynamics.py:113` `int(g("rest_ticks", 300))` 兜底 **300** ≠ `config.resource_dynamics.rest_ticks` 默认 **60**
  ⇒ 两处不一致；若有路径走到兜底，行为与配置默认不符。**请裁**：改 config 默认、改兜底、还是本就不该走兜底？
* `[实测]` 同文件 `:120 dead_regen_ticks 2000` 与 config 一致 ✅；`simulation/sphere_engine.py:2016 corpse_decay_ticks 600` 与 config 一致 ✅（已知）
* `[实测]` `simulation/genes.py:50 REPRO_COOLDOWN = 12`（genes.py 旧版不在清单）——基因表常数，留线索区

## 五、决策与边界（请知悉）

1. **退出码语义**：`0`=干净／`1`=有清点发现（未分类>0 或交叉校验冲突）／`2`=覆盖硬失败（fail-loud）——CI 与人工判读分离；
2. `--md` 死参数已实现（原来只接不写）；`SyntaxError` 由静默 `return []` 改 fail-loud；JSON 增 `scan_files`/`coverage`；入口加 R98 GBK 兜底；
3. `config.py` 不入字面量扫描（验收件 §3.2 排除项）⇒ 我 11 文件 vs 云归版 12 文件（他未排除 config.py）；面额仍由 §3.1 字段枚举全覆盖；
4. **未采纳**云归分支 §3.35 的两条"断言化不变量"——它们会让 rc=1，把**清点报告**与**语义裁定**混在一起。我的意见：不变量断言应独立进 `tests/`，不进清点工具（最终由您定）；
5. 云归 `work-p0.0-scale` 分支**未并入**（避免两线重复改同一文件），如需并请裁。

## 六、下一步：T1（邻居表紧凑化）

极化行（row 0 / row R−1 各只有 **3 个**邻格）方案三选一，**我先回板再动手**：

| 方案 | 内容 | 我的评估 |
|---|---|---|
| ① 独立小表 | 极行存 3 列小表，非极行 8 列 | 内存最省，但引擎取邻居要分支 ⇒ 热路径变复杂 |
| ② 退化采样 | 8 列，缺的槽重复填（如重复首邻） | 零分支，但会**悄悄重复计算**邻居 ⇒ 扰动行为，风险最大 |
| ③ 保 −1 哨兵 + 长度数组 | 仍 8 列 int32 + `_nb_len` 每单元长度 | 内存 3375→30 MB 已达标（int32 后 960列→8列），对 Rust 改动最小、逐位对拍风险最低 |

⚠️ 无论选哪个，**必须同步 `_nb_len`/`_nb_norm`**（否则静默 ×15 错），Rust 侧 `neighbors: &[i64]` 按 `nb_start+nb_off` 取值也须改+重编。
**我倾向 ③**（对拍风险最低，且 C7 逐位一致最容易守）——请所有者/老工点头或改令，随后我按 T1 验收四条（≤30 MB、tick 提速 1.13–1.16×、C7 绿、建表 <10 s）开工。
