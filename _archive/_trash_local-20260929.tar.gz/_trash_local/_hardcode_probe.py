"""探针：AST 扫 `simulation/` 里对 `_sim_core.*`（Rust 边界）的调用，列出裸数字字面量实参。"""
from __future__ import annotations

import ast
import io
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(r"C:\Users\圣羽\Desktop\temp\tempCode\the-world")


def walk_calls(path: Path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        f = node.func
        if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Attribute):
            if isinstance(f.value.value, ast.Name) and f.value.value.id == "self" \
               and f.value.attr == "_sim_core":
                yield node


def literal_args(call: ast.Call):
    out = []
    for i, a in enumerate(call.args):
        if isinstance(a, ast.Constant) and isinstance(a.value, (int, float)) \
           and not isinstance(a.value, bool):
            out.append((i, a.value))
        elif isinstance(a, ast.UnaryOp) and isinstance(a.op, ast.USub) \
                and isinstance(a.operand, ast.Constant):
            out.append((i, -a.operand.value))
    for kw in call.keywords:
        if isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, (int, float)):
            out.append((kw.arg, kw.value.value))
    return out


total = 0
for p in sorted((ROOT / "simulation").glob("*.py")):
    for c in walk_calls(p):
        lits = literal_args(c)
        if lits:
            total += 1
            print(f"{p.name}:{c.lineno}  {c.func.attr}  literals={lits}")
print(f"\n调用点含裸数字字面量：{total}")
