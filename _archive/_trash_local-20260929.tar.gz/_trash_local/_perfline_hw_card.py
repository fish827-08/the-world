"""本机硬件规格卡采集（[本地开发·性能线] 开工；scratch，不入库）。

用法：
    .venv\\Scripts\\python.exe _trash_local/_perfline_hw_card.py
"""
from __future__ import annotations

import ctypes
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

# 单核基准：必须在 import numpy 之前钉住线程数
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[_v] = "1"

import numpy as np  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parents[1]
CARGO = Path(os.path.expanduser("~")) / ".cargo" / "bin" / "cargo.exe"


class _MEMSTATUS(ctypes.Structure):
    _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]


def mem_gb() -> tuple[float, float]:
    st = _MEMSTATUS()
    st.dwLength = ctypes.sizeof(st)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st))
    return st.ullTotalPhys / 1e9, st.ullAvailPhys / 1e9


def cpu_name() -> str:
    import winreg
    try:
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                           r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
        return str(winreg.QueryValueEx(k, "ProcessorNameString")[0]).strip()
    except OSError:
        return platform.processor() or "unknown"


def cores_physical_logical() -> tuple[str, int]:
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "$p=Get-CimInstance Win32_Processor; "
             "'{0}|{1}' -f $p.NumberOfCores,$p.NumberOfLogicalProcessors"],
            capture_output=True, text=True, timeout=60)
        phys, logi = out.stdout.strip().split("|")
        return phys, int(logi)
    except Exception:
        return "?", os.cpu_count() or 0


def gemm_gflops(n: int = 1500, reps: int = 3) -> float:
    a = np.random.rand(n, n)
    b = np.random.rand(n, n)
    a @ b                                        # 预热
    t0 = time.perf_counter()
    for _ in range(reps):
        a @ b
    dt = (time.perf_counter() - t0) / reps
    return 2.0 * n ** 3 / dt / 1e9


def mem_bw_gbps(mb: int = 512, reps: int = 5) -> float:
    m = mb * 1024 * 1024 // 8
    a = np.ones(m, dtype=np.float64)
    b = np.empty_like(a)
    b[:] = a                                     # 读 a + 写 b
    t0 = time.perf_counter()
    for _ in range(reps):
        b[:] = a
    dt = (time.perf_counter() - t0) / reps
    return 2.0 * a.nbytes / dt / 1e9


def rust_ver(exe: Path) -> str:
    if not exe.is_file():
        return "（未找到）"
    try:
        out = subprocess.run([str(exe), "--version"], capture_output=True,
                             text=True, timeout=60, encoding="utf-8", errors="replace")
        return out.stdout.strip() or out.stderr.strip()
    except Exception as exc:                     # pragma: no cover
        return f"（{type(exc).__name__}）"


def main() -> None:
    total, avail = mem_gb()
    phys, logi = cores_physical_logical()
    du = shutil.disk_usage(str(ROOT.anchor) + os.sep)
    print("== 本机硬件规格卡 ==")
    print(f"主机名      : {platform.node()}")
    print(f"OS          : {platform.platform()}（{platform.machine()}）")
    print(f"CPU         : {cpu_name()}")
    print(f"核数        : 物理 {phys} / 逻辑 {logi}（python os.cpu_count={os.cpu_count()}）")
    print(f"内存        : 总 {total:.1f} GB / 可用 {avail:.1f} GB")
    print(f"磁盘 {ROOT.anchor}   : 总 {du.total/1e9:.0f} GB / 可用 {du.free/1e9:.0f} GB")
    print(f"Python      : {platform.python_version()}（{sys.executable}）")
    print(f"numpy       : {np.__version__}")
    print(f"BLAS 线程   : OMP/OPENBLAS/MKL = 1（基准钉单核）")
    print(f"Rust        : {rust_ver(CARGO)} ｜ {rust_ver(CARGO.parent / 'rustc.exe')}")
    print(f"GEMM 单核   : {gemm_gflops():.1f} GFLOP/s（f64 1500^3，{1} 线程）")
    print(f"内存带宽    : {mem_bw_gbps():.1f} GB/s（copy 512 MB）")


if __name__ == "__main__":
    main()
