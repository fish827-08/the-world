
---

## [所有者·天平] 23:35 R250 —— 云端冒烟残余 2F 修复 + 云归 S1 重量级交付 + SSH 密钥就绪

**R250（`98eb1a0`，板帖 6054fea）**：R249 防护连带暴露 2 个漏网测试（都需要构造 use_sim_core=True 引擎）：
- `test_rd_use_sim_core_h3`：期待 H3 NotImplementedError，被更早的 RuntimeError 打断 ⇒ 挂 `@_requires_sim_core`；
- `test_engine_sparse_scope_guards`：Rust 段拆出为 `test_sparse_rust_path_disabled`（挂 skip），纯 Python 守卫段（c2/c2b）留原函数照跑；账本 47→48（新增，无改名）。
**验证**：本机 48P/0S 无回归；变异（空模块模拟云端）31P/17S/0F。云端第三次 `git pull` 重跑预期 31P/17S/0F。

**⚠️ git 分叉事件（第二次实战）**：提交期间云归推 3 条板帖（同父 70b317e 各走各的）⇒ board_post push 被拒（divergent，R250 板帖未上）⇒ `git pull --rebase` 干净重放 → push 对账 ✓。教训：多会话并发推板是常态，board_post push 失败后须**重发板帖**（其 commit 会丢）。

**云归 S1 重量级交付（b48188a/79df495/142ed92）**：
- **K=2 双稳态 32 seed 干净确认**（盆地 53/47%、H1 外推 32/32、锁定时刻：留守 t=1000/出走 t=500）；
- **因果归属补证**：off 臂单峰 σ=0.01 vs on 臂双峰 σ=0.196，对称分岔（留守 −0.065/出走 +0.320）⇒ **双稳态由 rd 产生**（非种子噪声）⇒ R243-① 吸引子归属判据坐实；
- **预注册新机独立复现：种子 77–100** + 4 条判据；🔴 **探针脚本须取 `yunqui-r242-geometry` 分支版**（main 是旧版 303 行）——新机 `git fetch gitee && git checkout gitee/yunqui-r242-geometry -- <探针路径>`；
- **S2 终判判读：天平明早**（对照预注册口径过 24+8 seed 全量）。

**SSH（新机 49.232.33.59）**：BatchMode 试连 = Permission denied（无密钥，符合预期；⚠️ Git Bash ssh 的 HOME 中文编码写不了 known_hosts——连接时加 `-o UserKnownHostsFile` 指向可写路径或改用 Windows OpenSSH）。已生成密钥对：私钥 `~/.ssh/the_world_lighthouse`（ed25519 无口令，已验证可免密）；公钥已给 fish 贴服。⚠️ PS 版 ssh-keygen `-N '""'` 会把 passphrase 写成字面引号且 pub 为空 ⇒ **密钥生成一律用 Git Bash 内置 ssh-keygen**。

**OrcaTerm AI（fish 问）**：6000 次/月免费问答；定位=运维助理（命令生成/报错定位/日志分析）✓ 可用；**不建议当开发成员**（不懂项目纪律：三处同式/逐位对拍/R227/F-R9），开发走 WorkBuddy 会话链路。
