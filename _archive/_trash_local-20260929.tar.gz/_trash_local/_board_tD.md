**T-D 设计短贴（只设计，未实施）：`sparse_fields` × `resource_dynamics` 能否共存**

**结论：可行**，但范围应锁在 `bg_production_zero=True` 档（= S2/S3/T4 主线）。
rd 的 dead/rest 动态**不破坏**"惰性再生可闭式求值"前提；唯一理论破坏面（轮作改容量）在该档**惰性化**
（R226 修复① ⇒ 掩码/容量恒定；本机实测恒真）。一般世界（会搬斑块的档）v1 保持全场回退。

**一、答派工之问：dead/rest 是否破坏前提？——不破坏**

惰性再生位等价前提（`world/resource_field.py:404-460`）逐条对照：

| 前提 | rd 触及面 | 判定 |
|---|---|---|
| ① 增长非负（净格跳过靠 `min(cap,cap+g)==cap`） | dead/rest 只经 `growth_multiplier`（`world/resource_dynamics.py:219`）乘 `dead_regen_mult`/`rest_regen_mult`（值域 {0, 0.5, 1}；bgzero 档默认 0.5） | ✅ 乘子恒 ≥0，非负保持 |
| ② 脏集打脏点覆盖"减 `_grid`"写入（`resource_field.py:302` 注） | rd 不写 `_grid`；`note_tick` 只写 `_damage/_dead/_rest_until` 等 rd 内部数组 | ✅ 不触及 |
| ③ "净格恒净" = 容量值恒定 | **唯一风险**：`rotate` 搬掩码 ⇒ `capacity_from_base()`（`:247`）变值 ⇒ 净格变欠容（漏再生）/超容（漏夹取） | ⚠️→✅ bgzero 档不存在 |

**一句机理**：bgzero 档里 R226 修复①（`resource_dynamics.py:325` 起：死斑块格保身份、不搬移）⇒ `_mask` 自构造恒定
⇒ 每 tick 回写的 `_capacity` **数值**不变；轮作只剩"再生闸"（乘子），恒 ≥0 ⇒ 前提①保持。
**dead/rest 只缩放非负再生、从不改容量** ⇒ 闭式前提完好。
（第四面：快照恢复 —— `rebuild_lazy` 已在 load 路径调用（`simulation/sphere_engine.py:5251`），rd 下同样成立。）

**二、需要的改动（3 处，~1 人日）**

1. **rd 再生段子集化**（`sphere_engine.py:2238-2241`）：`_regrowth_amount(tick)` 全场 → 只算脏格；
   `_rd_growth_sum` 从"逐 tick 重绑整场数组"改为"预分配 + 子集回填 + 逐 tick 清零"。
2. **note_tick 分母补算**（`sphere_engine.py:2882` 前）：`kill_denom="regrowth"`（默认）时分母 = 本 tick 名义再生量；
   **净格被吃**的格 regrow 时被跳过 ⇒ 分母缺值，须 `_regrowth_amount(tick, need)` 补算（`need = intake>0 & ~regrow脏集`）。
   ⚠️ 漏填的失效形态 = 该格 `denom_k=0` ⇒ 被 `valid &= denom_k>0`（`resource_dynamics.py:256` 起）滤出
   ⇒ **极端密度通道静默漏杀**（不炸、只是结果不同）。
3. **范围锁改写**（`sphere_engine.py:842-846`）：锁③"rd 关" → 放行 `rd.enabled ∧ bgzero`；一般档保持全场。
   并加构造期 fail-loud 断言（`rd ∧ sparse ⇒ bgzero`），防未来开搬移时前提静默破裂。
   （可选扩展：一般档 + 回写后 `rebuild_lazy()` + 一次性 `min(grid,cap)`，留后续。）

**三、证据（本机实测 2026-09-27，T4 同构臂 480×960，灭绝后 N=0，150 tick；脚本 `_trash_local/_td_rd_floor.py`）**

| 项 | rd=off | rd=on（现状，sparse 均关） |
|---|---|---|
| N=0 地板（墙钟/CPU） | 13.42 / 24.27 ms/tick | **19.87 / 38.65 ms/tick** |
| 掩码 / 容量恒定实测 | — | **True / True**（bgzero 档全程含灭绝后长测） |

cProfile 分解（ms/tick，rd=on）：
- **可跳过**：`_regrowth_amount` cum **10.58**（self 7.02，内含温度链 cum 2.12）= 全场再生链整块；网格夹取 ~1.24（T-A 微基准）
- **跳不掉（rd 固定账务）**：`rotate` 1.87 + `capacity_from_base`（含回写拷贝）1.74 + `_rd_intake_sum[:]=0` 等
  `_advance_one_tick` self 3.55，合计 ≈ 5-6 ms/tick

⇒ **预估收益**（预估类，实施后以 A/B 实测为准）：N=0 地板 ≈ 19.87 − 12.5 ≈ **7.5-8.5 ms/tick（−57% 量级）**；
主线 N≈2.5k（T4 稳态 K 中位 ~3k）脏格占比 ≲1% 场量级 ⇒ 再生链几乎全省 —— 即 R219 sparse B "−29.9% @N≈2.5k"
的同一块收益，rd 开档同样拿得到。

**四、风险（按严重度）**

1. **逐位对拍负担（主）**：3 处小改要对 `(rd on × sparse on) ≡ (rd on × sparse off)` 逐位。
   测试面 = 函数级（regrow 子集 vs 全场，rd 乘子参与）+ 引擎级 digest（T4 臂逐 tick 对拍 + 中途快照续跑对拍）；
   R217 sparse B 测试骨架可直接复用。估 0.5 人日。
2. **分母补算遗漏**（见改动 2）：靶向单测 = "满格（净）被吃 ⇒ full/lazy 杀死集逐位一致"。
3. **范围假设脆弱**：v1 依赖"bgzero ⇒ 掩码恒定"；将来若开搬移（`not bgzero` 分支可达）⇒ 前提破裂。
   缓解 = 构造期断言 + 搬移分支加 lazy 守卫。
4. **旁路全身合算**：`_step_corpse_decay`（`sphere_engine.py:1366-1377`）在 `corpse_boost>0` 时每 tick
   全场调 `_regrowth_amount`（`:1370`）—— corpse 开的臂（S2 本体）即使 regrow 子集化，这里仍全场算
   ⇒ 需一并子集化到 `bo` 掩码，否则收益被吃。先出 profile 再动。

**五、若裁定限缩 —— 替代项（按性价比）**

- **信号稀疏解耦**（~1-2h，建议先做）：`signals.enable_sparse()` 与 `resources.enable_lazy()` 现同闸（`sphere_engine.py:847-849`）；
  信号侧与 rd 完全正交（活跃集 = `age>0`，自包含）⇒ 只放开信号侧，rd 开档也吃 `signals.tick` −2.34 ms/tick（T-A 消融数）。
- **rd 固定账务逐机制向量化**（~0.5 人日，profile 已给）：`_rd_intake_sum` 清零 → `bincount` 直写；
  `rotate`/`validate_writeback` 事件驱动化（无事件 ⇒ 全 no-op）；`_capacity` 回写仅在掩码变更时做。

**请裁**：是否按 v1（仅 bgzero 档，~1 人日）实施？还是先做替代①（信号解耦，1-2h、无对拍负担）？
