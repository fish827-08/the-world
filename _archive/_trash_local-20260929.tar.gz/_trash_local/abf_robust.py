#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""稳健判定：现行捕食公式下 W(g) 是否存在**内部极小（谷）**。

与 `experiments/analyze_bimodal_fitness.py` 的区别：
  · 原脚本用 `slope_l < -TOL and slope_r > TOL`，**TOL=1e-6 是绝对阈**，
    且差分跨 20 个网格点（Δg=1e-4）⇒ 光滑极小处的差值只有 O(曲率·Δg²)≈1e-8 ≪ TOL
    ⇒ **光滑谷会被静默丢成"未分类"**（实测：cost×200 的谷在 g=0.5 被漏掉）。
  · 本脚本改用**相对判据**：局部最小 ⇔ W(g*) < W(g*±0.05) − 1e-12，并报出解析驻点。

W(g) = (1-g)^k·F + 1[g>gate]·( p(g)·σ(g)·E_prey·r − p(g)·c )
  p(g)   = g·COEF·hunger
  σ(g)   = clip( ratio·(0.5 + g·GAIN), floor, ceil ),  ratio = E_self/(E_self+E_prey)
"""
import sys

import numpy as np

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

COEF, GATE, GAIN = 0.2, 0.3, 0.5
FLOOR, CEIL, R, C = 0.1, 0.9, 0.4, 0.1


def W(g, k, F, e_self, e_prey, hunger, cs):
    g = np.asarray(g, dtype=float)
    ratio = e_self / max(e_self + e_prey, 1e-9)
    sig = np.clip(ratio * (0.5 + g * GAIN), FLOOR, CEIL)
    p = g * COEF * hunger
    return (1.0 - g) ** k * F + (g > GATE) * (p * sig * e_prey * R - p * C * cs)


def robust_probe(k, e_self=150.0, e_prey=150.0, hunger=0.5, cs=1.0, F=1.0, n=400001):
    """返回 (是否有内部极小, 最小点g, W(min), W(0), W(1))"""
    g = np.linspace(0.0, 1.0, n)
    w = W(g, k, F, e_self, e_prey, hunger, cs)
    i = int(np.argmin(w))
    gm, wm, w0, w1 = float(g[i]), float(w[i]), float(w[0]), float(w[-1])
    # 只把**严格内部**（离 gate 与两端都留 0.02 余量）的极小算作"内部谷"
    interior = (GATE + 0.02) < gm < 0.98
    # 局部性检验（相对判据，避开绝对阈值）
    lo = W(gm - 0.05, k, F, e_self, e_prey, hunger, cs)
    hi = W(gm + 0.05, k, F, e_self, e_prey, hunger, cs)
    local_min = wm < min(float(lo), float(hi)) - 1e-12
    # 两端都要更高（破坏性选择的形态要求）
    two_sided = wm < min(w0, w1) - 1e-12
    return (interior and local_min and two_sided), gm, wm, w0, w1


def main():
    print("=" * 100)
    print("稳健判定：k（素食权衡曲率）× cost×（攻击成本倍率）→ W 是否存在内部极小（谷）")
    print("  参数：E_self=E_prey=150（= 报告 C 组）、hunger=0.5、F=1、gate=0.3")
    print("=" * 100)
    print(f"{'k\\cost×':>7} | " + " | ".join(f"{cs:>5}" for cs in (1, 20, 50, 90, 100, 120, 150, 200, 300, 500, 1000)))
    print("-" * 100)
    win = {}
    for k in (0.0, 1.0, 2.0, 3.0, 5.0):
        cells, good = [], []
        for cs in (1, 20, 50, 90, 100, 120, 150, 200, 300, 500, 1000):
            ok, gm, wm, w0, w1 = robust_probe(k, cs=cs)
            cells.append("  谷  " if ok else "  —  ")
            if ok:
                good.append(cs)
        win[k] = good
        print(f"{k:>7} | " + " | ".join(cells))

    print("\n" + "=" * 100)
    print("逐例详解（有谷的窗口）")
    print("=" * 100)
    for k in (1.0, 2.0, 3.0, 5.0):
        if not win[k]:
            print(f"  k={k}: 在扫描的 cost× 上**未发现**内部谷")
            continue
        lo, hi = min(win[k]), max(win[k])
        ok, gm, wm, w0, w1 = robust_probe(k, cs=200)
        print(f"  k={k}: cost× ∈ [{lo}, {hi}] 存在内部谷"
              + (f"   ｜ 例 cost×200：极小 g={gm:.4f} W={wm:.4f}，"
                 f"W(0)={w0:.4f} > W(min) < W(1)={w1:.4f}"
                 f" ⇒ {'两端高、中间低 = 破坏性选择形态 ✅' if wm < min(w0, w1) - 1e-12 else '两端不都更高'}") if ok else "")

    print("\n" + "=" * 100)
    print("解析校验：k=2, F=1, E=150/150, hunger=0.5 时")
    print("  N'(g) = (1.5 - 0.01·cs) + 3.0·g      （捕食净收益的导数，恒增）")
    print("  W'(g) = -2(1-g) + N'(g) = 5g - 0.5 - 0.01·cs")
    print("  ⇒ 驻点 g* = 0.1 + 0.002·cs")
    print("  ⇒ g* > gate(0.3) ⇔ cs > 100 ⇒ 内部谷")
    for cs in (50, 100, 200, 500, 600):
        gs = 0.1 + 0.002 * cs
        inside = GATE < gs < 1.0
        print(f"     cs={cs:<5} g*={gs:.3f}  {'∈ (gate,1) ⇒ 内部谷 ✅' if inside else '∉ (gate,1) ⇒ 无内部驻点'}")


if __name__ == "__main__":
    main()
