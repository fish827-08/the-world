"""只读：定位数据仓里的**重复/冗余**快照（不修改任何文件）。"""
import os
import time
from collections import defaultdict
from pathlib import Path

ROOT = Path(r"C:\Users\圣羽\Desktop\temp\tempCode\the-world\the-world-data")


def human(n: int) -> str:
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f}{u}"
        n /= 1024
    return f"{n:.1f}TB"


# ① 按"路径里含 rolling / keypoints"分类
cat: dict[str, list[int]] = defaultdict(lambda: [0, 0])
for dirpath, dirnames, filenames in os.walk(ROOT):
    if ".git" in dirnames:
        dirnames.remove(".git")
    rel = os.path.relpath(dirpath, ROOT).replace("\\", "/")
    if "/rolling" in rel or rel.startswith("rolling"):
        key = "rolling（滚动时间戳副本）"
    elif "/keypoints" in rel or rel.startswith("keypoints"):
        key = "keypoints（tick 关键点副本）"
    else:
        key = "主快照（非副本目录）"
    for fn in filenames:
        try:
            cat[key][0] += (Path(dirpath) / fn).stat().st_size
            cat[key][1] += 1
        except OSError:
            pass

print("### ① 按目录性质分类")
print(f"{'类别':<34}{'体积':>10}{'文件数':>9}")
for k in ("主快照（非副本目录）", "rolling（滚动时间戳副本）", "keypoints（tick 关键点副本）"):
    if k in cat:
        print(f"{k:<34}{human(cat[k][0]):>10}{cat[k][1]:>9}")

# ② 同名同大小的重复组（= 真冗余候选）
groups: dict[tuple[str, int], list[tuple[str, float]]] = defaultdict(list)
for dirpath, dirnames, filenames in os.walk(ROOT):
    if ".git" in dirnames:
        dirnames.remove(".git")
    for fn in filenames:
        p = Path(dirpath) / fn
        try:
            st = p.stat()
        except OSError:
            continue
        if p.suffix.lower() != ".npz":
            continue
        groups[(fn, st.st_size)].append(
            (str(p.relative_to(ROOT)).replace("\\", "/"), st.st_mtime))

dups = {k: v for k, v in groups.items() if len(v) > 1}
waste = sum(k[1] * (len(v) - 1) for k, v in dups.items())
print(f"\n### ② 同名同大小的重复组：{len(dups)} 组；"
      f"若每组只留**最新 1 份**，可省 **{human(waste)}**")

rows = sorted(dups.items(), key=lambda kv: -kv[0][1] * (len(kv[1]) - 1))[:12]
for (fn, sz), items in rows:
    items_sorted = sorted(items, key=lambda x: -x[1])
    keep = items_sorted[0]
    print(f"\n  【{fn}】{human(sz)} × {len(items)} 份 ⇒ 可省 {human(sz*(len(items)-1))}")
    print(f"    保留(最新): {time.strftime('%Y-%m-%d %H:%M', time.localtime(keep[1]))}  {keep[0]}")
    for name, mt in items_sorted[1:6]:
        print(f"    可清      : {time.strftime('%Y-%m-%d %H:%M', time.localtime(mt))}  {name}")
    if len(items) > 7:
        print(f"    …（另有 {len(items)-7} 份）")
