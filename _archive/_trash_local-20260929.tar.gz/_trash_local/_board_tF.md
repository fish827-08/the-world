**T-F 交付：rd 开 + 60k 档快照续跑端到端冒烟 —— 首跑抓到真缺陷，修复后「可」**

派工：R233 §七 T-F（`884a76b`）。提交：`d82bb21`（已 push；`ls-remote` 对账一致）。
文件：`simulation/config.py`（修复）＋ `tests/test_snapshot.py`（守卫测试，+1 例）
＋ `experiments/steady_k_probe.py`（新增 `--rd {on,off}`）＋ `experiments/rd_resume_smoke.py`（**新增：云端可一条命令重跑**）。
（附注：本批 4 文件曾于 22:17 被并发提交 `66fe76f` 连带扫入（`git add` 路径面过宽），
所有者随即 reset 并以 `4d79f97` 重提（不含本批）⇒ 最终记录为本独立署名提交 `d82bb21`。）

## 〇、结论先报（R233 T-F③：若发现不兼容 ⇒ 立刻上报）

**修复前：不可。修复后：可。**

🔴 影响面：**60k 旗舰（subpos 档）若做 save-every→resume，修复前会静默换掉运动模型**
—— 不是崩溃、不报错，是"续跑出来的数据与连续跑不是同一口径"。**云端今晚通宵前务必带上本修复。**

## 一、首跑即发现缺陷（冒烟的价值立现）

**症状**：rd 开（S2 同款：480×960 / patches=480 / subpos on / v_max=gain=0.125 / subdiv=80 / k=2.5
/ max_count=30000 / rgm=1.195）⇒ 续跑段**从恢复后第 1 tick（t=1001）就与连续跑分叉**；
而**恢复瞬间的状态是逐位一致的**（rd 六数组 + 五计数器 + 信号活跃集全对）
⇒ 指向"恢复后引擎的**配置/行为**与连续跑不同"，而非"状态没存全"。

**根因（实证，非推断）**：`SimConfig.from_dict`（`config.py:1171`）**整段漏传 `subpos`**
⇒ `load_snapshot(config=None)`（续跑的默认路径，`sphere_engine.py:5086`）重建配置时 subpos 落回默认。

**证据**：CLI 对拍中两份快照的 `config_dict` **字段级 diff = 恰 4 个字段，全在 subpos**：

| 字段 | A（连续跑） | C（续跑） |
|---|---|---|
| `subpos.enabled` | **True** | **False** |
| `subpos.speed_gain` | 0.125 | 4.0 |
| `subpos.speed_max` | 0.125 | 2.0 |
| `subpos.subdiv` | 80 | 4 |

**为何此前没暴露**（三层巧合，缺一不可）：① 云端的 save/resume 验证跑在 rd 关的 s1 档
（`steady_k_probe` 的 `--subpos` **默认关**）；② 既有往返测试要么显式 `config=cfg` 传入（**跳过 from_dict**）、
要么用 subpos 默认档（两边同为默认 ⇒ 差异被吞）。**⇒ 与 rd 无关**，是「subpos 开档 × `config=None` 路径」的组合
—— 而 R234 刚拍板 subpos 是"相对视野 ×8"的第一刀，正是旗舰要用的档。

## 二、修复（3 处生产代码 + 1 条守卫测试）

1. `simulation/config.py`：`from_dict` 补 `subpos=`（沿用文件既有白名单写法，新增 `_SUBPOS_FIELDS`）；
2. `tests/test_snapshot.py`：新增 `test_subpos_config_roundtrip_and_resume_bitwise`
   —— 刻意走 **config=None + subpos 开档**：断言 ①`from_dict(to_dict()) == cfg` ②恢复后 subpos 真值 + 配置指纹
   ③恢复瞬间 `_sub_r/_sub_c` 逐位 ④再跑 60 tick 后 `_flat/_energy/_sub_r/_sub_c/_id` 逐位；
   含**非平凡前提**（亚格坐标须非常数）。**变异检查已做**：模拟修前行为必被这条测试抓红。
3. `experiments/steady_k_probe.py`：新增 `--rd {on,off}`（默认 `None` = 不碰配置）；rd 进
   **run_tag**（`_rd` 后缀 ⇒ 开关两臂快照/CSV 不互顶）、CSV 列、行键、meta、summary；
   续跑时 `rd / subpos / speed_max / gain / subdiv` 一律**以快照配置为准**（CLI 不一致仅告警，不静默）。
4. `experiments/rd_resume_smoke.py`（新）：把本次冒烟固化成**一条命令可重跑**的产物 —— 云端可直接照抄。

## 三、修复后证据（两条线）

### ① 引擎级冒烟 `experiments/rd_resume_smoke.py`（rd 开 + subpos 开 + 信号稀疏）
- A 参考臂连续跑 1500 tick；B 臂 t=500/1000 存三件套（模拟 `--save-every 500`）；从 t=1000 快照**续跑 500 tick**
- **500/500 逐 tick digest 全等**（t=1001..1500；digest = tick + 种群 + Σflat + Σ能量 + grid/marks/age 三哈希）
- 恢复瞬间 & 终态：**rd 全字段逐位一致**（含 `_n_mask_0` / `_cap_total_0` / `capacity_from_base()` 哈希）；
  信号活跃集重建 == `age>0` 派生（137 格）；**死因账本一致**（starvation 2088 / predation 531）
- 终态 N=231、Σgrid=893 447（两臂同值）；墙钟 133 s（`experiments/rd_resume_smoke.py` 一条命令，可重跑）

### ② CLI 级 e2e（真实命令行 + CSV/摘要/合并路径）
A 连续 0→80；B 0→60 `--save-every 20` 存档后"中断"；C 从 B 快照续到 80（`--out` 同一文件 ⇒ 合并）
⇒ **9/9 断言绿**：t=80 **全态快照 85/85 数组逐位**；rng 侧车一致（F-D2 全局 np.random）；
CSV 13 列 × 4 行全等（含 t=80 那条**续跑行**）；summary 全等；`switches.rd=true`；
合并后行网格 = 20/40/60/80；快照 meta 记 `rd=true` / tag 带 `_rd` / `save_every=20`。

### ③ 测试账本
- 定向：`tests/test_snapshot.py` **18 passed**（含新增 1 例）；config 相关 6 文件 **81 passed**
- 全量：**46F / 934P / 8S**（368.93 s）。口径：本次命令**含** `tests/test_broker.py`（6 例全过）
  ⇒ 934 = T-E 账本 927（`--ignore` broker 口径）+ 6 broker + 本次新增 1 例守卫测试；
  **46 条失败逐名**与 T-E 账本一致（0 增 / 0 减 / 0 改名）

## 四、结论与建议

**结论：可**（rd 开 + 60k 同款档，save-every→中断→resume 逐位一致）。
前提：**云端拉到的树必须含本修复**。旧快照无需重跑（`config_dict` 里**有** subpos 键，修复后加载即正确恢复）。

两条边界（供排期）：
- ⚠️ `_rd._rng`（rd 自有 RNG）**不在快照里**：bgzero 档经核**不可达**（`_promote_same_row` 不触发）
  ⇒ S2/旗舰档无影响；**非 bgzero ∧ `rotate_moves_patch=True`** 的世界续跑仍有边界风险（v1 排期时补，1 行）。
- 建议（未做，等裁）：`load_snapshot(config=None)` 加"重建配置指纹 == 快照指纹"的 **fail-loud** 校验
  —— 本次没加：老快照（缺新键）重建后指纹字符串天然不等，会破"旧快照可读"承诺，需"规范化比较"版；
  属独立小项（≤30 行 + 1 测试）。本缺陷正是这类校验能当场抓住的。

**T-G**（`_step_corpse_decay` 全场调用 profile，v1 前置）：本轮**未做** —— 主项（发现 + 修复 + 双线复验）
吃掉全部工时；若 23:00 前有余量再补，否则顺延。
