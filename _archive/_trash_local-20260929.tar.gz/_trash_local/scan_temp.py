#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""只读扫描：C:\\Users\\圣羽\\Desktop\\temp 各顶层项的规模（不做任何删除/移动）。"""
import os
import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

ROOT = Path(r"C:\Users\圣羽\Desktop\temp")
REPO = ROOT / "tempCode" / "the-world"


def size_of(p: Path, budget_files=400000):
    """返回 (字节, 文件数, 子目录数)；遇错不中断。"""
    total = 0
    nf = nd = 0
    stack = [p]
    while stack:
        cur = stack.pop()
        try:
            with os.scandir(cur) as it:
                for e in it:
                    try:
                        if e.is_dir(follow_symlinks=False):
                            nd += 1
                            stack.append(Path(e.path))
                        else:
                            fi = e.stat(follow_symlinks=False)
                            total += fi.st_size
                            nf += 1
                    except OSError:
                        pass
        except OSError:
            pass
        if nf > budget_files:
            break
    return total, nf, nd


def human(n):
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.0f}{u}" if u == "B" else f"{n:.1f}{u}"
        n /= 1024
    return f"{n:.1f}PB"


def mtime(p: Path):
    try:
        return time.strftime("%Y-%m-%d %H:%M", time.localtime(p.stat().st_mtime))
    except OSError:
        return "?"


def show(title, base: Path, top=40):
    print(f"\n### {title}  ——  {base}")
    if not base.is_dir():
        print("（不存在）")
        return []
    rows = []
    with os.scandir(base) as it:
        for e in it:
            p = Path(e.path)
            try:
                isdir = e.is_dir(follow_symlinks=False)
            except OSError:
                isdir = False
            if isdir:
                b, nf, nd = size_of(p)
                rows.append((b, p.name, nf, nd, mtime(p), "DIR"))
            else:
                try:
                    b = e.stat(follow_symlinks=False).st_size
                except OSError:
                    b = 0
                rows.append((b, p.name, 1, 0, mtime(p), "FILE"))
    rows.sort(reverse=True)
    tot = sum(r[0] for r in rows)
    print(f"合计 {human(tot)} / {len(rows)} 个顶层项\n")
    print("| 大小 | 名称 | 文件数 | 子目录 | 最后修改 | 类型 |")
    print("|---|---|---|---|---|---|")
    for b, name, nf, nd, mt, kind in rows[:top]:
        print(f"| {human(b)} | `{name}` | {nf} | {nd} | {mt} | {kind} |")
    return rows


if __name__ == "__main__":
    print(f"# Desktop\\temp 只读扫描报告（{time.strftime('%Y-%m-%d %H:%M:%S')}）")
    show("一、`Desktop\\temp` 顶层", ROOT)
    show("二、`Desktop\\temp\\tempCode` 顶层", ROOT / "tempCode")
    show("三、仓库本体 `tempCode\\the-world` 顶层（未跟踪/被忽略的疑大项）", REPO)
