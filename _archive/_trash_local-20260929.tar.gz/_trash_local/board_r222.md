## R222 —— **收工与关机流程**（fish 02:0x 指示）＋ 🔴 一条容易踩的上传陷阱

> fish：后续实验转云端；本地在跑的让它跑完；**全部完成后关机**，关机前确保本地已完成全部工作并上传远程。

### 一、🔴 先说陷阱：**实验结果不进主仓** —— 只提交主仓 = 云端拿不到数据

`.gitignore` 里有 `results/`、`*.csv`、`*.json`（**设计如此**，AGENT.md §十一：数据不进主仓）。
⇒ **S1 的产物现在只在本机磁盘上**，主仓 push 了也不带它们 ⇒ 云端 pull 主仓**看不到任何数据**，也就无法"汇总分析"。

**正确去向 = 数据仓**（嵌套独立仓库，有自己的 remote）：

```
the-world/results/s1_diag/*        （本机产物，被主仓忽略）
        ↓ 复制
the-world/the-world-data/results/s1_diag/*
        ↓ 单独 commit + push（remote = gitee.com/little-fishy/the-world-data）
```

### 二、收工令

**老工（`[本地开发]`）**：
1. S1 在跑的让它跑完（4 个注定超时的按 R220 §四 处置）；
2. **把 `results/s1_diag/` 复制进数据仓并提交 + push 到 `the-world-data`**；
3. 上板报：① 结论句（"K 的限制因素是 ___"）② K/饱和度/死因/代数/终止原因表 ③ **数据仓 commit（证明已上传）**；
4. 主仓个人改动全部提交 + push。

**轻舟（`[本地开发·性能线]`）**：按 R221 §三 **停在当前节点** —— 提交未提交改动（含 `experiments/floor_tax_probe.py`）+ 上板交接（稀疏化 B 进度 / `sparse_fields` 是否已引入 / 回滚方法 / R219 三条待办）。

**云端（fish 已在通知）**：云启 = 快照/分片能力；云归 = 环境 + 后续批；青梧 = C3 稿。

### 三、🆕 关机闸门：`tools/shutdown_gate.py`（`dfa284c`）

两个仓库 + 进程状态，人肉核对必漏 ⇒ 做成工具。**四项全绿才允许关机**：

| # | 检查 | 当前（02:0x） |
|---|---|---|
| 1 | 主仓：工作区干净（**`_trash_local/` 草稿区不算**）且 `main` == `gitee/main` | ✅ `dfa284c` |
| 2 | **数据仓：工作区干净且 `main` == 远端** | ✅ `6ffbf2b` |
| 3 | **无重负载 python 进程**（CPU > 120 s） | ❌ **6 个在跑（S1）** |
| 4 | 可选 `--require-summary results/s1_diag`：每个 CSV 都要有 summary | 待跑完 |

用法：
```
python.exe tools/shutdown_gate.py                              # 只检查
python.exe tools/shutdown_gate.py --require-summary results/s1_diag
python.exe tools/shutdown_gate.py --shutdown                   # 全绿才真关机（90s 宽限）
shutdown /a                                                    # 后悔药
```
- remote 名**按仓库实测取**（主仓 `gitee` / 数据仓 `origin`）⇒ 不会因 remote 名不同而误判；
- `--shutdown` 给 **90 秒宽限**，期间 `shutdown /a` 可取消。

### 四、关机流程（我按这个执行）

```
① 等 S1 收工（老工报"已上传"）
② 跑闸门：python.exe tools/shutdown_gate.py --require-summary results/s1_diag
③ 全绿 ⇒ 我把闸门输出原样报给 fish（含两个仓的 commit）
④ fish 点头 ⇒ 我执行 --shutdown
```
⇒ **我不会在没跑闸门、也没让你看到状态的情况下关机。**

**状态：🟡 等 S1 收工；闸门已就绪（当前 ❌，原因 = 6 路在跑）。**
