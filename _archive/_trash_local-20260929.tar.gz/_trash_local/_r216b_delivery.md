### [本地开发·性能线] · 2026-09-27 00:50

# R216 两条裁定交付：R98 守卫自指盲区已闭（判据改 AST）＋ ARS 六数组进快照（裁定 A：存 + 恢复）

**已合 main：`6069216`（已 push，`ls-remote` 对账一致）。** 本批只动 save/load 段 + 扫描器/测试，
**step 数值路径一行未动** ⇒ C7 钉死 digest 不变；未做 merge/rebase/cherry-pick。

## 一、裁定一：R98 守卫自指盲区 —— ✅ 已闭

| 检验 | 修前 | 修后 |
|---|---|---|
| 扫描器本体在 GBK 控制台（`PYTHONIOENCODING=gbk`） | **rc=1**（`UnicodeEncodeError` U+21D2） | **rc=0** ✅ |
| 保护判据 | 源码**含标记串** `reconfigure(encoding="utf-8"` | **AST 检调用点** `.reconfigure(..., encoding=…)` |
| 守卫抓自己 | ❌ 只因**定义**了 `PROTECT_MARK` 常量就自判受保护 | ✅ 真调用（入口 reconfigure，回归测试钉死） |
| "把标记串写进注释/文案" | 可洗白成受保护 | 不算（只有调用点算） |

传播面（**消掉弱判据副本 = 治"守卫覆盖不派生"的根**）：
- `tests/test_r98_nonascii_print.py`：改用同一 AST 判据 + 2 条回归（"仅提及 ≠ 受保护"、"本体必须真调用"）；
- `tests/test_callsite_hardcode_scan.py` / `tests/test_config_fallback_audit.py` 的 S6/S7：
  断言改为**派生**自 `source_is_protected`（不再各自复制"含标记串"式判据）。

全域扫描（181 个 .py）：**0 未保护 / 40 已 reconfigure** ⇒ 判据收紧后**无新增违纪**
（此前点名的 3 个"仅提及未调用"文件都不打印非 ASCII，仍绿）。

## 二、裁定二 A：ARS 六数组进快照 —— ✅ 存 + 恢复

六键 `_out_taken / _feed_fast / _feed_slow / _ars_extensive / _heading / _giveup_ct`：
- **存**：按个体 `[:P]`（与 `_health` 等同一契约）；
- **恢复**：长度按**恢复后存活数**建（不是构造期 initial_count）⇒ 不静默错位；
- **旧快照缺键**：回退构造期初值（出生即赶路 / heading 未知 / 期待零）⇒ 旧档仍可读、可续跑。

## 三、证据（全部 `[实测]`；含**修复前对照**）

| 检验 | 修前（只读 worktree @`9ce07a8` 跑同版本测试） | 修后 |
|---|---|---|
| `test_all_slot_arrays_have_alive_length_after_load`（原 `xfail(strict=True)`） | **red**：六数组长度 **100 ≠ 存活 128** | ✅ 真测试通过 |
| `test_ars_state_roundtrip_and_resume_bitwise`（新） | red | ✅ 往返逐位 + 续跑 60 tick 逐位 |
| `test_ars_missing_keys_fall_back_to_init_lengths`（新） | red | ✅ 旧档回退长度/初值/续跑不炸 |
| C7 钉死 digest `(574887, 11266.746993)` | — | ✅ 不变（`test_a_continuous.py` 6 passed） |
| 全量 | — | **42 failed / 903 passed / 8 skipped（15:03）**，失败集与 R215-b 批 **DIFF-EMPTY**（42 例 = 存量环境失败，R215 §七-2 不修） |

收集数 949 → 953 = 本批 +4 例 + 1 例 xfail→真测试（已逐条核对，无其它增量）。

**与并发线的关系**：老工线已声明"用冻结树跑 ⇒ F-R9 免疫"（00:29 板贴）；本批引擎改动只在
save/load 段，**不触碰 step 路径** ⇒ 即便共享工作区也不影响在跑的 S1 批量。

## 四、下一步

转 **R216 §五 #1 稀疏化 B**（消 16.7 ms 地板税）。开工前我会先把"地板税在哪一段、怎么惰性
结算、逐位等价怎么保"写成简短设计贴（含回滚点），再动代码。

**状态：🟢 上板。**
