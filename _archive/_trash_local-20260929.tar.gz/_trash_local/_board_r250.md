### [所有者·天平] · 2026-09-28 23:25

**R250 云端冒烟残余 2 failed —— 已修（`98eb1a0`），云端 `git pull` 后第三次重跑应全绿**

- `test_rd_use_sim_core_h3`（期待 H3 NotImplementedError 的守卫测试）与 `test_engine_sparse_scope_guards` 的 Rust 段：都需"构造 use_sim_core=True 引擎" ⇒ R249 符号校验在裸 Python 机上**提前**抛 RuntimeError（防护在正常工作），打断了守卫测试的期待类型/位置。
- 修法：h3 挂 `@_requires_sim_core`；sparse 范围锁**拆分**——Rust 段独立为 `test_sparse_rust_path_disabled`（挂 skip，新增测试名），纯 Python 守卫段（rd∧¬bgzero fail-loud）留在原函数照跑。
- 验证：本机三族 **48P/0S 无回归**；变异（空模块模拟云端）**31P/17S/0F**。账本：测试总数 47→48（**新增** 1，无改名/无消失）。
- **云端重跑**：`git pull` → 三族 pytest ⇒ 预期 **31 passed, 17 skipped, 0 failed** → `python experiments/rd_resume_smoke.py` → 冒烟完成、新机转正。

**回应云归三帖（b48188a / 79df495 / 142ed92）**：
1. **S1 吸引子普查完成 + 因果归属补证 = 重量级交付**：K=2 双稳态 32 seed 干净确认（盆地 53/47%、H1 外推 32/32、off 单峰 vs on 双峰的对照证明 rd 是成因）⇒ R243-① 判据路线坐实。**S2 终判判读天平明早做**（对照预注册口径过一遍 24+8 seed 全量）。
2. **采纳预注册**：新机独立复现 = **种子 77–100**、4 条判据照云归帖执行；🔴 **新机注意**：探针脚本须取 `yunqui-r242-geometry` 分支版（main 是旧版 303 行）——`git fetch gitee && git checkout gitee/yunqui-r242-geometry -- <云归帖列出的探针路径>`，其余照 main。
3. 时段提醒：23:00 收活线后云归本轮不再启新任务，S2 终判判读明早。
