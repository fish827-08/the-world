"""MEMORY.md 09-23 第二轮更新：F1 构造事实 + 波 2 阶段划分；同步压缩以留余量。"""
from pathlib import Path

P = Path(".workbuddy/memory/MEMORY.md")
s = P.read_text(encoding="utf-8")
before = len(s.encode("utf-8"))
REPS = [
 # A. 代码事实：新增 F1（社交项被弱化 15 倍）
 ("- 生态区制二分（SAT：N≥0.9×max_count／PRED：pred_frac≥0.9）⇒ 比较**必分层**，配对先做区制匹配",
  "- 🔴 **社交项被静默弱化 15×**（09-23 实测，`tools/wave2_perception_probe.py`）：`nb_max = _nb_table.shape[1]` = **stride 120**\n"
  "  （极点格要整行 120 邻），而普通格实际只有 **8** 邻 ⇒ `densities = occ/nb_max*smw` 除以 120 ⇒\n"
  "  **社交/感知 ≈ 0.068**（按 8 归一化应 ≈1.0）——注释却写「归一化 0~8」⇒ **C9 型**。\n"
  "  ⇒ **span=2 会把 stride 推到 240 ⇒ 再静默压 2×**（故波 2 先把归一化冻成 `society_norm=120.0`）；是否修回 8 另案（+15× = 构造级）\n"
  "- 生态区制二分（SAT：N≥0.9×max_count／PRED：pred_frac≥0.9）⇒ 比较**必分层**，配对先做区制匹配"),
 # B. 在办：波 2 阶段划分
 ("3. **P2 四季（两脉冲）+ 庇护所**：`[本地开发]` **设计稿**（先稿后码，**同样分阶段、全程 Python**）",
  "3. **波 2 设计稿已交**（`90fece2`｜板帖 `4632044a`）：`docs/设计文档/设计-13.4波2视野与静止策略-实现侧-20260923.md`（含 F1–F3 先决发现、五项落点、臂表、6 条待裁）\n"
  "   - 阶段：**2-α 静止组**（`eat/regrow 0.6/0.4` + `cell_occupancy_cap=3` **必须同批** + 7 处 digest 基线更新）→\n"
  "     **2-β 视野组**（`perception_span=2` + 可见性门 + 去盲选 + `society_norm`）→ **2-γ 能量标定**（体能600/胃90/阈值/双阈值/吸收率）→ 臂实验 4 臂×4seed×40k\n"
  "   - 臂：A 对照｜B 视野(span2)｜C 静止组(cap3+0.6/0.4)｜D 全开；判据含 `still_frac ≤60%` 失控闸（Cobbold&Stana 2020：部分静止是正当生态位）\n"
  "4. **P2 四季（两脉冲）+ 庇护所**：设计稿（先稿后码，**同样分阶段、全程 Python**）"),
 # C. 压缩：沈降两处细节
 ("  - **E-030**（凸 trade-off）**未分化反单向扫荡**：g16 0.222→**0.088**、std 剩 **21%**，三项 **6/6 p=0.031**；机制=**捕食生态位数值上不盈利** ⇒ 凸度给足但\"另一头不存在\"\n",
  "  - **E-030**（凸 trade-off）**未分化反单向扫荡**：g16 0.222→**0.088**、std 剩 **21%**，三项 **6/6 p=0.031**；机制=**捕食生态位数值上不盈利**\n"),
]
for old, new in REPS:
    n = s.count(old)
    assert n == 1, f"命中 {n} 次（应 1）: {old[:60]!r}"
    s = s.replace(old, new)
P.write_text(s, encoding="utf-8")
after = len(s.encode("utf-8"))
print(f"MEMORY.md {before} -> {after} bytes ({after - before:+d})")
