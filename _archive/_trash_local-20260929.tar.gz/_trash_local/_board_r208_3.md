### [本地开发·性能线] · 2026-09-26 22:29

**交付两件（已推 gitee：`f6a40c2`、`311f742`）：R208 §三 兜底纪律 + R211 `util` 改名**

## 一、R208 §三：兜底纪律落地 —— 全仓 **9 处 / 8 字段**不一致 → **0**

§三点名 1 处；按"顺带立一条纪律"扫全仓 ⇒ 又抓出 8 处。全部**只在「cfg 缺字段」路径触发**
（当前配置 / 已有批次永不走到 ⇒ C7 无涉）：

| 位置 | 字段 | 兜底 旧 → 新 | config 默认（出处） |
|---|---|---|---|
| `world/resource_dynamics.py:113` | `rest_ticks` | 300 → **60** | config.py:1044（§三点名） |
| `world/resource_dynamics.py:118` | `kill_frac` | 0.7 → **10.0** | config.py:1062（"比例"→"再生倍数"口径遗留） |
| `simulation/sphere_engine.py:2026` | `corpse_cap_per_cell` | 3 → **200** | config.py:715 |
| `simulation/sphere_engine.py:2070` | `holder_adv` | 0.3 → **1.2** | config.py:738 |
| `simulation/sphere_engine.py:2430` | `assim_return_frac` | 0.0 → **1.0** | config.py:201 |
| `simulation/sphere_engine.py:2554` | `eat_threshold_frac` | 1.0 → **0.0** | config.py:183（`or 1.0` 保语义） |
| `simulation/sphere_engine.py:2962` / `:3106` | `w_fear_health` ×2 | 0.0 → **0.5** | config.py:743 |
| `simulation/sphere_engine.py:3402` | `need_aggression_k` | 0.0 → **0.5** | config.py:747 |

**工具**（`tools/config_fallback_audit.py`）：AST 清点 `simulation/` + `world/`；
**别名形态跟随**（`g = lambda k, d: getattr(cfg, k, d)`）—— 只扫 `getattr` 直呼**恰好漏掉
`rest_ticks` 本尊**，这是本工具存在的理由；覆盖 fail-loud（目录/文件数/命中数下限 ⇒ rc=2）；
歧义与"不在 config"**只报告不进 rc**（照 R208 §五 口径）。
**守卫**（`tests/test_config_fallback_audit.py`，7 例）：变异测试（注入别名兜底 ⇒ 必报）、
真仓"不一致必须为 0"、覆盖 fail-loud、CLI rc/json、R98 入口兜底。

**证据**
- `[实测]` **修前回放**（审计器指向 `git show HEAD:` 版两文件）⇒ 报 9 处（上表左列全部）；
  修后 rc=0、不一致 0（覆盖 11 文件 / 106 字面量兜底 / 20 个 None 存在性检查）。
- `[实测]` 全量 pytest：**42 failed / 868 passed / 8 skipped**（349.8 s）；与基线
  （42/852/8，486.7 s）**失败集逐项一致**（`f_r21_presets`×36 + `share_lock`×5 + `f_r10`×1，
  全为本机环境性）；新增 16 例全过。
- `[实测]` **C7 逐位三件套**显式复核：`test_135::e1b` / `test_137::s1b` / `test_138::s1b`
  **3 passed**（digest 仍 `(574887, 11266.746993)`）。

## 二、R211 `util` → `saturation` 改名（已办，`311f742`）

- `steady_k_probe.py`：CSV 列 `util`→`saturation`、summary 键 `util_tail`→`saturation_tail`、
  打印/读法文案同步；docstring 加一行 **"🔴 1 − 此值 ≠ 被吃掉的比例（见 `food_util_frac`，R190/E-035，~2%）"**。
- `t4_aggregate.py`：读列名同步，**旧产物列名 `util` 仍可读**（R211 要求旧产物留档不改，
  而交付帖数字正出自它们）；同批补推此前未推的汇总器增强（末 10000 tick 漂移 / `K/格` / 跨 seed 曲线）。
- `[实测]` 改名后重跑汇总器（读旧列）：**K 2591/2724/3001/3223/3047/3008**、
  饱和度 0.8547/0.8469/0.8581/0.8367/0.8546/0.8453 —— 与交付帖及你的复算逐个一致。
- `[实测]` 探针 60×120 冒烟：CSV 表头含 `saturation`、summary 键 `saturation_tail` ⇒ 端到端生效。
- ⚠️ **同类命名残留（只报告，未动）**：`experiments/time_compress_check.py:130` 与
  `time_compress_multiseed.py` 的 `util` 也是**同款"存量/容量"语义**（我核过算式）。是否一起改请裁。

## 三、🔴 四处"闸门型"兜底，请你裁一句（我可回退）

旧兜底在语义上是**关（gate）**，改后会**开启**机制（仅旧存档缺字段时）：

| 字段 | 旧 ⇒ 新 | 行为变化 |
|---|---|---|
| `w_fear_health` ×2 | 0.0 ⇒ 0.5 | `_fearh_on` 判 `>0` ⇒ 旧存档"血条恐惧项"由关变开 |
| `need_aggression_k` | 0.0 ⇒ 0.5 | 旧存档"饥饿更激进"由关变开 |
| `eat_threshold_frac` | 1.0 ⇒ 0.0 | 反向：旧=吃满胃容才算进食（更严）⇒ 新=零阈值（更松） |
| `assim_return_frac` | 0.0 ⇒ 1.0 | 旧=未吸收**不回灌** ⇒ 新=**全额回灌** |

**按 §三 字面（兜底 == 当前默认）现状即正确**，我按字面执行。若你要"缺字段的旧存档宁可少机制"，
我把前三项改成**显式 `enabled` 闸门**再报 —— 一句话即可。

## 四、其余

- `max_count` 30 000 的去留**仍待你裁**（T4 已跑完，改回不影响已有数据）。
- 全量失败 42 项与本机基线**逐项同一批**（GBK/环境性）⇒ 要不要我顺手修掉（约 10 分钟）。
- **下一步：P1 profile**（按 R210 §三；T4 已收工、F-R9 解除）—— 现在开工，产出按任务书
  = 累计时间前 10 表 + "可向量化占比"一句结论，做完另帖报。
