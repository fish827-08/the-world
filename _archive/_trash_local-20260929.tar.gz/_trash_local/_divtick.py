"""t=165 分歧取证：py 臂 vs rust 臂首个分歧 tick 的段级定位（纯观测）。

已知：pop=3000 / seed=42 / subpos off / k=2.5 时，两臂在 t<=164 全状态逐位一致，
t=165 出现 N 差 1。本脚本：
  1) 跑到 t=164 并复核逐位一致；
  2) 报 t=165 的 born/died 增量（判定分歧段是繁殖还是死亡）；
  3) 逐段对比 tick 165 之后的数组（能量/基因/位置/年龄/冷却），
     看新个体是否"整体多一个/少一个"（= 繁殖判定差），还是"某个体数值不同"（= 数值差）。
用法：.venv\\Scripts\\python.exe _trash_local/_divtick.py [--pop 3000] [--target 165]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from experiments.p1_profile import make_cfg          # noqa: E402
from simulation.sphere_engine import SphereEngine    # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def build(use_sim_core: bool, pop: int) -> SphereEngine:
    c, _ = make_cfg(seed=42, rows=480, cols=960, pop=pop, patches=480,
                    use_sim_core=use_sim_core, subpos=False,
                    speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000)
    return SphereEngine(c)


def cmp(name: str, a: np.ndarray, b: np.ndarray) -> None:
    if a.shape != b.shape:
        print(f"    {name:<16} shape {a.shape} vs {b.shape}")
        return
    d = float(np.max(np.abs(a.astype(np.float64) - b.astype(np.float64)))) if a.size else 0.0
    n = int(np.count_nonzero(a != b))
    print(f"    {name:<16} maxdiff={d:.3e}  n_diff={n}  shape={a.shape}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pop", type=int, default=3000)
    ap.add_argument("--target", type=int, default=165)
    a = ap.parse_args()

    py = build(False, a.pop)
    rs = build(True, a.pop)
    for _ in range(a.target - 1):
        py.step()
        rs.step()
    print(f"== 跑到 t={a.target - 1}：逐位复核 ==")
    print(f"  N py={len(py._id)} rust={len(rs._id)}；"
          f"born 累计 py={py._run_born} rust={rs._run_born}；"
          f"died 累计 py={py._run_died} rust={rs._run_died}")
    print(f"  RNG state（tick 前）：py={py.rng.bit_generator.state['state']['state']}")
    print(f"                       rust={rs.rng.bit_generator.state['state']['state']}")
    print(f"  同 RNG？{py.rng.bit_generator.state['state']['state'] == rs.rng.bit_generator.state['state']['state']}")
    cmp("age(t-1)", py._age, rs._age)
    cmp("cooldown(t-1)", py._repro_cooldown, rs._repro_cooldown)

    p0, r0 = py._run_born, rs._run_born
    d0, e0 = py._run_died, rs._run_died
    py.step()
    rs.step()
    print(f"\n== tick {a.target} 增量 ==")
    print(f"  born：py +{py._run_born - p0}   rust +{rs._run_born - r0}")
    print(f"  died：py +{py._run_died - d0}   rust +{rs._run_died - e0}")
    print(f"  N：   py {len(py._id)}   rust {len(rs._id)}")
    print(f"  RNG state：py={py.rng.bit_generator.state['state']['state']}")
    print(f"             rust={rs.rng.bit_generator.state['state']['state']}")

    n = min(len(py._id), len(rs._id))
    print(f"\n== tick {a.target} 末 段级对拍（公共前缀 {n} 体）==")
    for nm, x, y in (("age", py._age, rs._age), ("cooldown", py._repro_cooldown, rs._repro_cooldown),
                     ("stomach", py._stomach, rs._stomach), ("energy", py._energy, rs._energy)):
        bad = np.flatnonzero(x[:n] != y[:n])
        print(f"    {nm:<10} n_diff(前{n})={bad.size}"
              f"{'  下标 ' + str(bad[:6].tolist()) if bad.size else ''}")
    if len(py._id) > n:
        i = n
        print(f"  新个体（py 末位 idx={i}）：flat={int(py._flat[i])}  "
              f"energy={py._energy[i]:.4f}  age={py._age[i]:.4f}  "
              f"cooldown={py._repro_cooldown[i]:.4f}")
        print(f"  母体候选 idx=79：flat={int(py._flat[79])}  "
              f"energy py={py._energy[79]:.4f} rust={rs._energy[79]:.4f}  "
              f"age py={py._age[79]:.4f} rust={rs._age[79]:.4f}  "
              f"cooldown py={py._repro_cooldown[79]:.4f} rust={rs._repro_cooldown[79]:.4f}")
        print(f"  母体是否被扣繁殖代价：Δenergy={py._energy[79] - rs._energy[79]:.4f}")

    print(f"  前 {n} 个体（按序）是否逐位一致：", end="")
    same = (
        np.array_equal(py._flat[:n], rs._flat[:n])
        and np.array_equal(py._energy[:n], rs._energy[:n])
        and np.array_equal(py._genes[:n], rs._genes[:n])
    )
    print("是" if same else "否")
    if not same:
        m = min(len(py._flat), len(rs._flat))
        bad = np.flatnonzero(py._flat[:m] != rs._flat[:m])
        print(f"  首个位置分歧下标：{bad[:5].tolist() if bad.size else '无'}")
        bade = np.flatnonzero(py._energy[:m] != rs._energy[:m])
        print(f"  首个能量分歧下标：{bade[:5].tolist() if bade.size else '无'}")

    print("\n  ⇒ 判读：若 born 增量不同 = 繁殖段判定差；若 born 相同而前 n 个体不一致 = 数值/段差")


if __name__ == "__main__":
    main()
