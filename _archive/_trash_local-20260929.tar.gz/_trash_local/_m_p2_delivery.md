### [本地开发·性能线] · 2026-09-26 23:15

# P2 向量化① 交付：文化学习段 10.5× 且**逐位不变**（T4 档 4.08→0.39 ms/tick）

**已合入 main：`8aa0f2e`（已 push，`ls-remote` 对账一致）。** 按 R212 §五「性能重点 = 让 Python 路径本身变快」，先动 **P1 行级第一热段**：文化学习（旧行号 3605–3622，行级合计 14.9%）。**结论：该段提速 10.5×，整 tick −3.9 ms（1.093×），且新旧实现在同状态上逐位一致（含端到端 2500 tick）。**

## 一、改了什么（`simulation/sphere_engine.py`）

把"逐未成年跑 Python 循环"换成批式向量化，整段抽成 `_culture_learn_python`：

1. **同格归组**：同格未成年的邻域恒相同 ⇒ 先 `np.unique(所在格)`，一组只算一次（旧版逐个体重复算）；
2. **邻居格矩阵**：普通格取 `_nb_table` 的 (U,8) 行；极点格取 `_pole_nb` 整带（分支与 `world.neighbors()` 一致）；
3. **成年个体 CSR**：`argsort(所在格, stable)` + `searchsorted` 双侧定界 ⇒ 格内保持个体索引升序；
4. **对级去重 + 升序**：`lexsort((成年索引, 组))` + 相邻比较去重（极点带邻居表有重复格 ⇒ 必须去重）；
5. **分段求均值**：`np.add.at`（无缓冲、按索引出现顺序累加）以每组首行做初值；
6. 一次性写回未成年行（均值只读成年行、更新只写未成年行 ⇒ 两集合不相交）。

🔴 **两条踩坑记录（写进代码注释，供后续向量化复用）**：
* `np.mean(axis=0)` 对 C 连续 (K,16) 是**顺序累加**（与手写逐行相加逐位一致，实测），但 **`np.add.reduceat` 不是**——分段和与顺序和实测有位差 ⇒ 不能用 reduceat，必须用 `np.add.at`。
* 首行做初值还顺手覆盖 K=1 段（`0.0 + x` 在 x=−0.0 时不是恒等，首行初值可绕开该边角）。

* 不引入新的最坏情形：仍是 O(邻域个体数)（与旧版同阶），只把 Python 层开销换成 numpy 批量操作。

## 二、取证（`[实测]`，全部本机）

| 检验 | 口径 | 结果 |
|---|---|---|
| **函数级对拍** | 新批式 vs 旧逐个体循环（同一随机状态，`int64` 位模式比较，含 ±0.0） | **9/9 例通过**（新文件 `tests/test_p2_culture_vec.py`） |
| C7 红线 | `test_135::e1b` / `test_137::s1b` / `test_138::s1b` | **3 passed**（digest 未变） |
| **端到端轨迹** | T4 档（480×960/k=2.5/seed42/py+subpos）跑 2500 tick，9 个采样点 N 与 **P1 基线（旧码产出）** 逐点比对 | **0 漂移** |
| **端到端同状态对拍** | 两枚**全新**引擎（同种子同配置）分别跑旧/新实现各 2500 tick，末态 N/flat/energy/genes/interpret/age/stomach/cooldown/id/parent 摘要逐位比对 | **逐位一致 ✅** |
| **块级 A/B** | 同一状态背靠背，25 次中位数（N=1112，成年 389 / 未成年 723） | 旧 **4.075** → 新 **0.389 ms/tick** = **10.5×** |
| **整 tick 交替 A/B** | 同进程 10 tick × 3 轮交替 | 旧 **45.91** → 新 **41.99 ms/tick** = **1.093×**（省 3.91 ms/tick） |
| 回归 | `test_l4_l5` / `test_d2_info_structure` / `test_d18_response` / `test_reproduce_batch` | 37 passed, 1 skipped |

对拍覆盖：极点带未成年、极点邻带（重复格）、同格密集、孤立未成年（不动）、K=1、1e-6~1e6 混合量级。

**天花板提示**：这一刀只吃掉整 tick 的 ~8%。P1 已算出同 N 上限 2.0×（73.6→36.1）⇒ 剩下的大头在**移动决策循环**（行级 ≥36%），那是 P2② 的活（条件分支多、含 RNG 消费点，需按段拆 + 每段对拍，见下节）。

## 三、顺带抓到一个**快照恢复缺陷**（与本次改动无关，未修，请裁）

* **现象**：长跑快照恢复后，首个出生即 `IndexError: index 5469 is out of bounds for axis 0 with size 3003`（`_step_population` 繁殖段 `self._rs_children[self._id[ri]] += 1`）。
* **根因（`[代码]`）**：`load_snapshot` 里 `_id` 键控账本的补齐用的是 **`engine._next_id`**，而该字段在**之后**才被赋值：
  * `simulation/sphere_engine.py:5135`：`need = int(engine._next_id) - len(engine._rs_children)`（此时还是新建引擎的初值 = `initial_count`）
  * `simulation/sphere_engine.py:5144`：`engine._next_id = int(data["next_id"])`（太晚）
  ⇒ 默认档（无 `_measure_resp`/`_oracle_on`，即 `rs_*` 不入快照）恢复后，9 个按 `_id` 键控的账本长度全都停在 `initial_count`。
* **最小复现**（`_trash_local/_snap_invariant.py`，只读+临时 npz）：构造 `initial_count=5` 的引擎，令 `_next_id=40`、现存个体 id=30..34 ⇒ 存/读后 `len(_rs_children)=5` 而 `_next_id=40`，**不变量 `len(账本)==_next_id` 违反**（9 个账本全中）。
* **影响面**：**默认档的快照续跑**（= 目标档 14.10 长跑复活流程）；测试没覆盖"恢复后仍有出生且 id > initial_count"。
* **修法（3 行，待批准）**：把「恢复元数据」整块（`_tick`/`_next_id`/`_max_generation`…）**移到补齐账本之前**，或把补齐改到 `_next_id` 赋值之后 + 加一条守卫测试（`load → len(账本)==_next_id`）。**要不要我修？**（改的是快照路径、不动模拟数值 ⇒ 不触 C7 红线，但属共享引擎面，我不擅自动手。）

## 四、下一步（已按 R213 §六 重排）

R213 的排序我照单接收——**本贴的 P2① 是收到 R213 前就在飞的**（已单独成刀、已验证、故先落），其后按序：

1. **合并 `gitee/dev/yunqi-t2t3`**（T2/T3，解 `SUBDIV_STD` 冲突取 **80**，合并即得 cooldown 修复）→ 全量 + C7 → 回板。⚠️ 合并前会先确认云启那条线已停手（R213 §四 的提醒）。
2. **修 `:3838` + 两个扫描守卫**：`60.0` → `self.config.organisms.repro_cooldown_gene_scale`，**先跑 C7 三件套取证**（默认 k=1 ⇒ 60.0 ⇒ digest 应不变，实测证明）；同批做"调用点硬编码绕开 config"扫描测试 + R208 §三 4 处闸型兜底对齐（R213 §三/§六 合批）。
3. **P2② 移动决策循环**（R213 前的行号 3088–3350）：按"分段批次化 + 每段函数级对拍"推进（先默认档快路径，D2/L1/S3/A′ 分支保留原路径并加对拍），**每段交付即回板**；预计比文化段大得多，不敢一次动完。
   * 若 ① 的合并把行号推移，以合并后为准。

* 裁定已闭环的旧项：`:3808` cooldown（批准，见上）、`max_count` 30 000（保留）、`util`→`saturation`（已做）。
* **仍等裁定**：① 快照恢复缺陷要不要我修（§三，3 行改法，待批）；② 42 例环境失败测试要不要顺手修（低优先，不影响主线）。

* 产物：`tests/test_p2_culture_vec.py`（已入库 `8aa0f2e`）；探针 `_trash_local/_p2_bench.py` / `_p2_ab.py` / `_p2_lockstep.py` / `_snap_invariant.py`（不入库）。
