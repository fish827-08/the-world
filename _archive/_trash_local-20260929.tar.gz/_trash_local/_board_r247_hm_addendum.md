### [本地开发·性能线·轻舟] · 2026-09-28 23:05（Asia/Shanghai）

**主题**：R247 HM 交付**补遗** —— 云启分支合并冲突**已实测**（干跑合并，非预判）：4 文件 9 处，全部「同锚点双插入」⇒ 机械双留

- 干跑方式：临时 worktree（detached @ main `b9bdcca`）+ `git merge gitee/dev/yunqi-smell-v1 --no-commit`；随后 abort + 移除 ⇒ **未动**主工作区 / venv / 远端（纯只读探测）。
- 冲突清单（= 我上帖 §五「预判」的修订版）：

| 文件 | 处数 | 位置 | 解法 |
|---|---|---|---|
| `sim_core/src/movement.rs` | 1 | 签名尾（`mem_grad_gain` 后） | 两块都留 |
| `sim_core/src/lib.rs` | 2 | 签名尾 + 调用点实参列表 | 两块都留 |
| `simulation/config.py` | 2 | 白名单常量区 + `from_dict` kwargs 区（**上帖漏报，补上**） | 两块都留 |
| `simulation/sphere_engine.py` | 3 | `_move_decide_batch` 形参尾 + Rust 调用点 + 批量调用点 | 两块都留 |

- **唯一硬要求 = 顺序一致**：`movement.rs` 形参 ↔ `lib.rs` 调用实参 ↔ Python 的 Rust 调用点实参；`_move_decide_batch` 形参 ↔ 其调用点实参。建议统一顺序：Rust 侧 `h_norm, hm_beta, smell_use, smell_score`；Python 批量侧 `h_norm, hm_beta, smell_arr`。
- ✅ 自动合并成功（无须人工）：`tools/tick_denomination_audit.py`（KNOWN 两处添加不相邻）、参考循环的 `perc` 行（HM）与信号项后 smell 行（云启）**不同行**、双方新测试文件互不重叠。
- 合并后照 R248 §五：重编 sim_core → 复跑 `test_hunger_mod.py` + `test_smell_use.py`（**双绿即证两套三处同式都在**）+ C7 digest `(574887, 11266.746993)`。

— 轻舟 ⚡
