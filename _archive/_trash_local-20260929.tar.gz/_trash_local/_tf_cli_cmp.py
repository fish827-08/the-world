"""T-F CLI 端到端对拍：连续跑（A） vs 「存快照 → 续跑」（B→C），rd 开。

断言：
  1) t=80 全态快照逐位（A 连续 vs C 续跑；含 rng 侧车）
  2) CSV 确定性列全等（含 t=80 的**续跑行**）
  3) summary.result 全等 + switches.rd 真值 + 合并行网格 20/40/60/80
"""
from __future__ import annotations

import csv
import io
import json
import pickle
import sys
from pathlib import Path

import numpy as np

try:  # R98：GBK 控制台兜底（非 ASCII print 会让脚本 rc=1 假失败）
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
TAG = "w480x960_p480_s42_k2.5_rgm1.195_rd"
CHECKS: list[tuple[str, bool, str]] = []


def chk(name: str, ok: bool, detail: str = "") -> None:
    CHECKS.append((name, bool(ok), detail))
    print(f"{'✓' if ok else '✗'} {name}{('  —— ' + detail) if detail else ''}", flush=True)


def load_rows(p: Path) -> list[dict]:
    with io.open(p, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def load_npz_sorted(p: Path) -> dict[str, np.ndarray]:
    z = np.load(p, allow_pickle=True)
    return {k: z[k] for k in z.files}


# 1) 全态快照逐位
sA, sC = HERE / "_tf_cli_snap_a" / f"{TAG}.snapshot.npz", HERE / "_tf_cli_snap_c" / f"{TAG}.snapshot.npz"
a, c = load_npz_sorted(sA), load_npz_sorted(sC)
chk("快照键集一致", set(a) == set(c), f"A|keys|={len(a)} C|keys|={len(c)}")
bad = []
for k in sorted(set(a) & set(c)):
    x, y = a[k], c[k]
    if x.shape != y.shape:
        bad.append(f"{k}(shape {x.shape}!={y.shape})")
        continue
    kw = {"equal_nan": True} if x.dtype.kind == "f" else {}
    if not np.array_equal(x, y, **kw):
        bad.append(k)
chk("t=80 全态逐位（连续 vs 续跑）", not bad,
    ("差异: " + ", ".join(bad[:8])) if bad else f"{len(a)} 数组全等")

rA = pickle.load(open(HERE / "_tf_cli_snap_a" / f"{TAG}.snapshot.rngstate.pkl", "rb"))
rC = pickle.load(open(HERE / "_tf_cli_snap_c" / f"{TAG}.snapshot.rngstate.pkl", "rb"))
rng_ok = (rA[0] == rC[0] and np.array_equal(rA[1], rC[1]) and rA[2] == rC[2]
          and rA[3] == rC[3] and rA[4] == rC[4])
chk("rng 侧车一致（F-D2 全局 np.random）", rng_ok,
    f"name={rA[0]} pos {rA[2]} vs {rC[2]}")

# 2) CSV 确定性列
COLS = ("seed", "patches", "k", "rgm", "rd", "tick", "pop", "d_starv", "d_old",
        "d_pred", "saturation", "mean_energy", "mean_gen")
rA_csv, rB_csv = load_rows(HERE / "_tf_cli_a.csv"), load_rows(HERE / "_tf_cli_b.csv")
chk("CSV 行数一致（A vs B/C）", len(rA_csv) == len(rB_csv), f"{len(rA_csv)} vs {len(rB_csv)}")
diff = []
for ra, rb in zip(rA_csv, rB_csv):
    for col in COLS:
        if str(ra[col]) != str(rb[col]):
            diff.append(f"t={ra['tick']}.{col}: {ra[col]} != {rb[col]}")
chk("CSV 确定性列全等（含 t=80 续跑行）", not diff,
    "; ".join(diff[:6]) if diff else f"{len(rA_csv)} 行 × {len(COLS)} 列")

# 3) summary / meta
jA = json.loads((HERE / "_tf_cli_a.summary.json").read_text(encoding="utf-8"))
jB = json.loads((HERE / "_tf_cli_b.summary.json").read_text(encoding="utf-8"))
keys = ("final_N", "final_tick", "platform_reached", "K_measured", "tail3_pops", "max_gen",
        "saturation_tail")
d2 = [f"{k}: {jA['result'][k]} vs {jB['result'][k]}" for k in keys
      if jA["result"][k] != jB["result"][k]]
chk("summary.result 全等", not d2, "; ".join(d2))
chk("switches.rd=true 且 runs[0].rd=true",
    jB["switches"].get("rd") is True and jB["runs"][0].get("rd") is True,
    f"B.switches.rd={jB['switches'].get('rd')} B.runs[0].rd={jB['runs'][0].get('rd')}")
chk("B 合并后行网格 = 20/40/60/80", [int(r["tick"]) for r in rB_csv] == [20, 40, 60, 80],
    str([r["tick"] for r in rB_csv]))
metaB = json.loads((HERE / "_tf_cli_snap" / f"{TAG}.snapshot.meta.json").read_text(encoding="utf-8"))
chk("快照 meta：rd=true / tag 带 _rd / save_every=20",
    metaB.get("rd") is True and "_rd" in str(metaB.get("tag")) and metaB.get("save_every") == 20,
    f"rd={metaB.get('rd')} tag={metaB.get('tag')} save_every={metaB.get('save_every')}")

ok = all(o for _, o, _ in CHECKS)
print("\n== T-F CLI e2e 结论：" + ("**可**" if ok else "**不可**")
      + f"（{sum(o for _, o, _ in CHECKS)}/{len(CHECKS)} 断言绿） ==")
sys.exit(0 if ok else 1)
