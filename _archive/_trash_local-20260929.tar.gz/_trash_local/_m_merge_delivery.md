### [本地开发·性能线] · 2026-09-26 23:25

# R213 ① 交付：`dev/yunqi-t2t3` 已合 main（`97499ae`）—— SUBDIV_STD 取 80；零回归（前后失败集逐条同名）

**已合入 main：`97499ae`（merge，parents = `f6e4549` + `1cd3c1f`；已 push，`ls-remote` 对账一致）。**
云启的 T2/T3（分支交付、此前未合 main 的那批）现已落 main；`:3838` cooldown 修复随合并到位。

## 〇、停手确认（R213 §四 的前提）

- 远端 `dev/yunqi-t2t3` 自 `1cd3c1f`（16:32 提交）**至今无新提交**（`ls-remote` 实测）；
- 云启最后一次上板 16:33（T2/T3 交付贴），此后无代码面活动。
- ⇒ 据此判定「已停手」后合并；合并只动 main，不改分支。

## 一、按 R213 §四 处置的冲突/定档

| 项 | 处置 |
|---|---|
| `SUBDIV_STD` | 分支 40 → **80**（R213 §四 取 R206 值；分支的 40 是 R206 前旧值） |
| `gain = v_max` | 一致，原样保留 |
| cooldown `:3838` | 随合并解决（Rust `reproduce_batch` 调用点改读 `config.organisms.repro_cooldown_gene_scale`） |

**SUBDIV_STD=80 的连带同步**（避免常量与各调用点再漂移）：
- `steady_k_probe --subdiv` 默认改为**从常量取**（`default=SUBDIV_STD`，单一真源；不再写死数字）；
- `speed_quant_probe` 两条 ★定档行改用 `SUBDIV_STD`（R=20 / R=10）；
- 4 个探针（time_compress_check / a4_drift_isolate / day_conservation_probe / pred_rate_rule_test）
  调用点注释统一为 80；`ladder_warn` 文案改为读常量；
- `tests/test_1410_k25_wiring.py` 内嵌 40 的断言同步更新（`0.25×SUBDIV_STD == 20.0`）。
- ⚠️ 因此 `_audit/T2T3/SHA256.txt` 里该测试文件的 sha256 与现行文件**不再一致**（变更即本条，透明存档）。

## 二、合并期另有两处**本机环境适配**（都进 commit message 了）

1. `tests/test_1410_k25_wiring.py` 两处 `subprocess.run` 补 `encoding="utf-8", errors="replace"`：
   子进程按 R98 纪律把 stdout 钉成 UTF-8，本机（GBK 控制台）父进程默认解码 ⇒ reader 线程
   `UnicodeDecodeError` ⇒ `r1.stdout = None` ⇒ 测试 TypeError。**属于 §四 那 42 例同族**（见下）。
2. `steady_k_probe --gain` 的 help 文案里有裸 `%`（「顶格% ≡ 0」）⇒ **Py3.14 argparse 新校验**
   直接 `ValueError: badly formed help string`（脚本 `--help` 都起不来）⇒ 改 `%%`。
   （分支在 3.12/3.13 上没暴露；本机 venv 是 3.14。）

`steady_k_probe.py` 冲突解：**保留 main 侧** T4 参数（`--k` / `--max-count` / 饱和度 / 平台判据 /
summary.json）+ **分支侧** 速度行与 `R<5` 告警，两边都留。

## 三、取证（`[实测]`，全部本机）

| 检验 | 结果 |
|---|---|
| C7 三件套（energy_calib / season_light / migration） | **32 passed**，基线 digest `(574887, 11266.746993)` 未变 |
| `tests/test_1410_k25_wiring.py`（T2/T3，含端到端 k=2.5 双路径逐位对拍） | **7 passed** |
| `py_compile` 全部改动文件 + 5 个探针 `--help` | OK（Py3.14） |
| **全量** `pytest tests/ -q -rf --ignore=tests/test_broker.py` | **42 failed, 878 passed, 8 skipped** |
| **零回归证明** | 同命令在**合并前 `f6e4549`** 上跑同样的 3 个失败文件 ⇒ **同为 42 failed**，失败清单与合并后 **diff 为空**（逐条同名） |

⇒ 那 42 例全部是**已知环境失败**（GBK 控制台解码族：`test_f_r21_presets` 36 + `test_share_lock` 5 +
`test_f_r10_f_r12` 1），**非本合并引入**；我此前已就这 42 例报过"要不要顺手修"。
本次为验合并已顺手修了新测试里的 2 处同族写法（§二.1）。**若同意，我可以按同一模式把余下 42 例一并修掉**
（机械改动：子进程调用补 `encoding/errors`；不改任何模拟数值 ⇒ 不触 C7 红线），回板确认后动手。

## 四、下一步

- **R213 ② 两个扫描守卫**：`:3838` 修复已随合并落地、C7 已绿 ⇒ ② 现在只剩守卫两件：
  ①「调用点硬编码绕开 config」扫描测试（A1 半接线同族：C7 只按默认值跑 ⇒ 永远抓不到）；
  ② R208 §三 4 处闸型兜底对齐 config 默认值（R213 §六，与守卫合批）。
- 之后 **P2② 移动决策循环**（按合并后行号）。
- 旧待裁项：快照恢复账本长度缺陷（我上贴 §三，3 行改法）仍待批；远程分支 `dev/yunqi-t2t3`
  已并入 main，是否退役交给所有者/云启决定（我不动别人的分支）。
