"""诊断：subpos 开启后个体为什么几乎不换格？+ 死亡/饥饿 tick 为何倒挂？"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.stdout.reconfigure(encoding="utf-8")

from simulation.config import SimConfig  # noqa: E402
from simulation.sphere_engine import SphereEngine  # noqa: E402

grid_seen = {}


def build(seed, speed_max):
    c = SimConfig(seed=seed)
    c.simulation.use_sim_core = False
    c.simulation.l2_dash = False
    c.population.max_count = 600
    c.predation.enabled = False
    c.resources.distribution = "patchy"
    c.resources.bg_production_zero = True
    c.resources.patch_count = 30
    c.resources.patch_radius = 2
    c.resources.patch_regrowth_mult = 1.195
    o = c.organisms
    o.max_energy = 600.0
    o.initial_energy = 600.0
    o.starve_frac = 0.30
    o.exhaust_frac = 0.17
    o.eat_efficiency = 7.5
    o.assim_herb = 0.4
    o.assim_carn = 0.8
    o.stomach_cap_mass = 25.0
    o.eat_threshold_frac = 0.6
    o.photo_max = 0.0
    o.maturity_fraction = 1.01
    if speed_max > 0:
        c.subpos.enabled = True
        c.subpos.speed_max = speed_max
    return SphereEngine(c)


for sm in (0.0, 0.25):
    e = build(42, sm)
    print(f"\n=== speed_max={sm}｜subpos.enabled={bool(sm)} ===")
    print("  初始：len(_flat)=", len(e._flat))
    prev = e._flat[: len(e._flat)].copy()
    for t in range(1, 61):
        e.step()
        e.resources._grid[:] = 0.0
        cur = e._flat[: len(e._flat)]
        changed = int((cur[: len(prev)] != prev[: len(cur)]).sum())
        if t <= 6 or t % 20 == 0:
            print(f"  t={t:>3} N={len(cur)} 换格人数={changed} "
                  f"flat前5={cur[:5].tolist()} energy前3={np.round(e._energy[:3], 1).tolist()}")
        prev = cur[: len(e._flat)].copy()
    st = e.probe() if hasattr(e, "probe") else None
    if isinstance(st, dict):
        for k in list(st)[:40]:
            if "move" in k or "flat" in k or "step" in k or "mob" in k or "dash" in k:
                print(f"    probe.{k} = {st[k]}")
