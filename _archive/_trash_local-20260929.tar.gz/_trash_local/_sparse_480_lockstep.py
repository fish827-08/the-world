"""临时证据脚本（不提交）：480×960 T4 档 sparse on/off 引擎级逐位对拍 + 计时。

用途：R217 §五 #1 稀疏化 B 的**实尺寸**证据（单元测试在 60×120）。
  A = 默认档（sparse_fields=False），B = 稀疏档（True），同 cfg/seed/构造路径；
  逐 tick 比 digest（tick/存活数/flat/energy/stomach/genes/grid/marks/age），
  并同报 CPU 计时（本机有并发批跑 ⇒ 墙钟失真，CPU 可靠）。
"""
from __future__ import annotations

import hashlib
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from simulation.sphere_engine import SphereEngine            # noqa: E402
from experiments.scaling_rescale import apply_post_build     # noqa: E402
from experiments.steady_k_probe import make_cfg              # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def sha(a: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()[:16]


def digest(e: SphereEngine) -> tuple:
    return (
        e._tick, len(e._id), sha(e._flat), sha(e._genes),
        sha(e.resources._grid), sha(e.signals._marks), sha(e.signals._age),
        round(float(e._energy.sum()), 6),
        round(float(e._stomach.sum()), 6),
        tuple(sorted((str(k), int(v)) for k, v in e._run_deaths.items())),
    )


def build(sparse: bool, ticks: int) -> tuple[SphereEngine, dict]:
    cfg, notes = make_cfg(seed=42, rows=480, cols=960, pop=300, patches=480,
                          subpos=True, speed_max=0.125, gain=0.125, subdiv=80,
                          k=2.5, max_count=30000, rgm=1.195)
    cfg.simulation.sparse_fields = bool(sparse)
    t0 = time.perf_counter()
    e = SphereEngine(cfg)
    apply_post_build(e, notes)
    print(f"   [构造] sparse={sparse}  引擎闸={e._sparse_fields}  "
          f"资源惰性={e.resources._lazy}  信号稀疏={e.signals._sparse}  "
          f"耗时 {time.perf_counter() - t0:.1f}s")
    return e, {"saw_dirty": 0, "saw_active": 0, "ticks": ticks}


def main() -> int:
    ticks = 80
    print("== 480×960 T4 档 sparse on/off 逐位对拍 ==")
    ea, _ = build(False, ticks)
    eb, _ = build(True, ticks)
    db0 = digest(ea)
    assert db0 == digest(eb), "构造态即不一致（不该发生）"
    print(f"   [构造态] digest 一致 ✓ tick={db0[0]} N={db0[1]}")

    ta = tb = 0.0
    saw_dirty = saw_active = 0
    for t in range(ticks):
        c0 = time.process_time()
        ea.step()
        ta += time.process_time() - c0
        c0 = time.process_time()
        eb.step()
        tb += time.process_time() - c0
        da, db = digest(ea), digest(eb)
        if da != db:
            print(f"   🔴 tick {t + 1} digest 分裂：\n     A={da}\n     B={db}")
            return 1
        if getattr(eb.resources, "_lazy", False):
            saw_dirty += int(eb.resources._dirty_mask.any())
        if getattr(eb.signals, "_sparse", False):
            saw_active += int(eb.signals._active_idx.size > 0)
        if (t + 1) % 20 == 0:
            print(f"   [t={t + 1:3d}] N={len(ea._id):4d}  digest 一致 ✓  "
                  f"脏格={int(eb.resources._dirty_mask.sum()):6d}  "
                  f"活跃信号格={int(eb.signals._active_idx.size):4d}")
    print(f"\n   [逐位] {ticks} tick 全程 digest 一致 ✓ "
          f"（脏格非空 {saw_dirty}/{ticks} tick，活跃非空 {saw_active}/{ticks} tick ⇒ 非空转）")
    print(f"   [计时] CPU 总: 默认 {ta:.2f}s / 稀疏 {tb:.2f}s ⇒ "
          f"稀疏为默认的 {tb / ta * 100:.1f}%（省 {100 - tb / ta * 100:.1f}%）"
          f"  CPU ms/tick: {ta / ticks * 1e3:.1f} vs {tb / ticks * 1e3:.1f}")
    print(f"   [末态] N={len(ea._id)}  tick={ea._tick}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
