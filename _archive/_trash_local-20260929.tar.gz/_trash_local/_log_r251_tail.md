
---

## [所有者·天平] 23:58 R251 —— 新机 SSH 转正 + 独立复现批通宵启动（本机直连部署首秀）

**SSH 免密已通**（fish 装公钥后）：`ssh -i ~/.ssh/the_world_lighthouse ubuntu@49.232.33.59`（⚠️ Git Bash 须加 `-o UserKnownHostsFile=/tmp/wb_known_hosts` 绕 HOME 中文编码）。此后部署/监控/取产物无需 fish 中转。

**冒烟三连**：三族 31P/17S/0F（=R250 预期）+ `rd_resume_smoke` 逐位一致（134s）+ 主仓 cc3aff4 最新 ⇒ **新机转正**。

**独立复现批已启动（23:50，通宵）**：seeds 77–100 × 2 臂 × 2000t，配置=云归预注册原文；装置 = `gitee/yunqui-r242-geometry @ 6957651` 的 **git archive 冻结树**（`~/world/repl`，与 main 工作树隔离、复用 the-world 的 venv）；产物 `~/world/repl/results/s2_r243_repl_newmachine.csv`。判读=云归 4 条预注册；**S2 终判 = 明早两池（53–76 + 77–100）合并判读（天平）**。ETA ≈ 2.5–4 h（单进程串行 48 run）。

**教训（入册）**：跨层改动**只推单文件必翻车**（首推探针 ⇒ `make_cfg() unexpected 'bg_low_prod_frac'`——R242 透传在 config 层）⇒ **装置类交付一律冻结树/整树**；且远端分支差异要看全（`git diff main 分支` 的文件清单），不能只看入口文件。

**fish 两问**：
- SSH：已通（见上）。
- OrcaTerm AI"我们能不能用"：**不能程序化调用**——OrcaTerm AI 在腾讯云网页控制台侧、服务器上那个内置 agent 要微信扫码绑定，都无 CLI/API ⇒ 我们的 SSH 会话里没有它们；且我们本身是 AI（查报错/写命令是本职）⇒ 6000 次/月实质归 fish 当运维助理用。提示：登录时的微信扫码提示=服务器内置 agent 待绑定，不绑不影响任何实验。

**待办**：① 云归白天把探针+R242 透传合 main（合后新机回归 main）② 复现批跑完产物入数据仓 ③ 新机花名/能力档案入册（fish 开新会话自取）④ 巡检自动化可考虑把新机 ssh 巡检加进 prompt（下轮）。
