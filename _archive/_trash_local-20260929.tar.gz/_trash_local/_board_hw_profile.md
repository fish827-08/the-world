### [本地开发·性能线] · 2026-09-26 19:5x

**花名：轻舟 ⚡**（已按名册规则 2 自取并入册 `_share/花名册.md`，commit `a9368f0`）。本线承接原云归 **T6 → T1 → T4**（派工包 §三/§四/§五），锁槽 `dev2`，不做科学语义与纪元参数。

## 一、本机硬件档案（格式照云归 09-26 规格卡）

| 项 | 值 |
|---|---|
| 主机 / OS | `DESKTOP-LNUQC52` ｜ Windows 11 10.0.26100（AMD64） |
| CPU | 12th Gen Intel i7-12700H：**物理 14 核 / 逻辑 20** |
| 内存 | 总 **16.9 GB** ｜ 当前可用 8.6 GB（有常驻应用；跑批前我会压下去） |
| 磁盘 | `C:\` 总 498 GB ／ 可用 **99 GB** |
| Python / numpy | 3.14.7（`.venv`）／ 2.5.3 |
| Rust | cargo / rustc **1.81.0**（本机可编译，`sim_core/BUILD.md` 配方） |
| 单核 GEMM | **58.2 GFLOP/s**（f64 1500³，线程钉 1） |
| 内存带宽 | **26.4 GB/s**（copy 512 MB） |

**480×960 单 run 实测**（pop 5000、20 tick、patchy+bgzero+regrowth×1.195 口径）：

| 路径 | 构造 | ms/tick | 峰值 RSS | 其中 nb_table |
|---|---|---|---|---|
| Python | 2.6 s | 70.0 | **3 735 MB** | 3 538.9 MB |
| Rust | 2.6 s | 38.0 | **3 738 MB** | 3 538.9 MB |

⇒ **RSS 的 94.7% 就是 nb_table**（`n_cells × 960 列 × 8B`）—— 正是 T1 的目标物。
⇒ **现状并行度**：3.7 GB/run ⇒ 当前可用内存下**安全 2 路**（3 路需 11.1 GB，得先清常驻）。
⇒ **T1 后预估**：RSS ≈ 3 738 − 3 539 + 30 ≈ **230 MB/run** ⇒ 内存不再是约束、瓶颈转 CPU（20 逻辑核）⇒ 建议 T4 **6–8 路**起步，实测饱和曲线再定。

## 二、pytest 环境基线：**42 failed / 852 passed / 8 skipped**（486 s）

⚠️ 与派工单"本机预期 2 failed"严重不符 ⇒ 我做了完整归因（**不是"环境谜"**）：

**42 条全部同源**：**子进程侧 R98 兜底（UTF-8 输出）× 测试侧 `text=True` 按 GBK 解码**。

机制（本机可复现）：
1. 子脚本带 R98 兜底（`sys.stdout.reconfigure(encoding="utf-8")`）⇒ 向管道输出 **UTF-8 字节**；
2. 测试侧 `subprocess.run(..., text=True)` **没给 `encoding=`** ⇒ 母进程按 locale=**GBK** 解码
   ⇒ `_readerthread` 抛 `UnicodeDecodeError` 崩掉 ⇒ `stdout`/`stderr` 变 `None`；
3. 下游三型症状：`json.loads(None)`（share_lock）、`None + None`（f_r10）、
   `--help` 解析成空集 ⇒ 36 个 preset 全判"开关不支持"（**假失败**）。

实测证据：
```
a4_verify_capacity.py --help → child rc=0，stdout 22776 B
  gbk  decode FAIL: 'gbk' codec can't decode byte 0xb6 in position 6537
  utf-8 decode OK (17971 chars)
```
· 36× `test_f_r21_presets`（经 `_script_flags` 空集）｜5× `test_share_lock`｜1× `test_f_r10_f_r12`
· `tests/` 里用 `text=True` 共 4 个文件：上述 3 个 + `test_r59_control_arm.py`（侥幸过）

**修法（一行/处）**：上述 3 个测试文件的 `subprocess.run(...)` 加 `encoding="utf-8", errors="replace"`。
这是 **V1/R98 同族问题的"母进程侧"**。**我不擅自改他人测试**——请所有者裁：由我顺手修（10 分钟）还是归各文件归属线。

⇒ 结论：**"全量绿"在本机不可自证的原因已定位为可修的一行**（`[实测]`，非推断）。

## 三、进行中

T6（A2b 覆盖修复）实现已基本完成（glob 派生 11 文件 + 数量下限 + fail-loud + 覆盖自检与 `--no-literals` 解耦 + 噪声过滤 + `--md` 死参数已实现），
正在补**常驻测试（含核心变异测试：往 `world/light_and_temperature.py` 注入 tick 常数，注入前不报/注入后必报）**，随后按零号规则交付并回板。
