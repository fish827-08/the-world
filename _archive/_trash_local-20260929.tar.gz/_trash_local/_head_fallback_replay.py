"""R208 §三 修前回放：把审计器指到「HEAD 版引擎文件」上，数出修前的不一致处数。

用法：.venv\\Scripts\\python.exe _trash_local/_head_fallback_replay.py
"""
from __future__ import annotations

import importlib.util
import subprocess
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parents[1]
HEAD_SHOW = {"simulation/sphere_engine.py": "HEAD",
             "world/resource_dynamics.py": "HEAD",
             "simulation/config.py": "HEAD"}

spec = importlib.util.spec_from_file_location(
    "config_fallback_audit", ROOT / "tools" / "config_fallback_audit.py")
cfa = importlib.util.module_from_spec(spec)
sys.modules["config_fallback_audit"] = cfa
spec.loader.exec_module(cfa)


def main() -> None:
    tmp = ROOT / "_trash_local" / "_head_replay_tree"
    for rel in HEAD_SHOW:
        dst = tmp / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        blob = subprocess.run(["git", "show", f"HEAD:{rel}"], cwd=ROOT,
                              capture_output=True, check=True).stdout
        dst.write_bytes(blob)
    rep = cfa.scan(root=tmp, dirs=("simulation", "world"),
                   min_files_per_dir=1, min_files_total=2, min_hits=10)
    cov = rep["coverage"]
    print(f"== HEAD 版回放：文件 {cov['n_files']}｜字面量兜底 {cov['n_hits']}"
          f"｜别名文件 {cov['n_alias_files']} ==")
    print(f"❗ 不一致 {len(rep['mismatches'])} 处：")
    for m in rep["mismatches"]:
        print(f"   {m['where']}  {m['field']}: 兜底 {m['fallback']}"
              f" vs config 默认 {m['config_default']}（{m['config_class']}）")
    print(f"（歧义 {len(rep['ambiguous'])}｜不在 config {len(rep['unknown'])}）")


if __name__ == "__main__":
    main()
