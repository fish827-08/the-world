**T-C 交付：F-D2 全局 RNG 污染修复（B′ 方案：每引擎独立 legacy RandomState）**

commit `d243c78`（已 push `gitee/main`，ls-remote 对账一致）；改动 = `simulation/sphere_engine.py` + 新 `tests/test_rng_isolation.py`。

**一、修了什么——派工记"2 处"，实测 3 处 4 行**

| 行 | 调用 | 触发条件 |
|---|---|---|
| `:3243-3244` | 感知噪声 `np.random.normal` ×2（D2-3） | `info_structure.enabled ∧ perception_noise>0` |
| `:3687` | Steels 配对洗牌（Rust 路径侧补做） | `steels_alignment`（D2 纪律下不可达，一并改） |
| `:3814` | Steels 配对洗牌（Python 路径 = 生产路径） | 同上 |

**修法（B′）**：`self._d2_rng = np.random.RandomState(int(config.seed) & 0xFFFFFFFF)`
—— 种子/算法与旧 `np.random.seed(...)` **完全同源**（有测试钉死）⇒ ① 单引擎轨迹逐位不变；② 每引擎一份 ⇒ 互不污染。
`__slots__` 追加 `_d2_rng`；快照存/取 `d2_rng_state`（可选键）；`rng_draws` 口径**不变**（噪声/洗牌本就不计入主 rng）⇒ provenance 校验语义不动。

**二、为什么不照字面"改绑 `self.rng`"（方案 A，已实测否决）**

判据①（C7）与字面指令**互斥**：C7 `tests/test_a_continuous.py:159` 的配置是 **D2 开启**
（`InfoStructureConfig(enabled=True, learning_rate=0.05, memory_gradient="none")` ⇒ noise=0.05、steels 默认开），
其钉死值 `(574887, 11266.746993)` 本身就是"D2 噪声+对齐参与"的结果；同一族 digest 在 **17 个测试文件**里钉死
（`grep -rl 574887 tests/`）。方案 A 实测：`test_a_continuous` / `test_energy_cap` / `test_sparse_fields` **3/3 挂**
（例：`(575459, 11342.161941)` vs 钉死 `(574887, 11266.746993)`）⇒ 照字面改，判据①不可能同时成立。
B′ 让两条判据同时成立（原式复刻 + 隔离）。

**三、证据（全部本机实测，静默机前段窗口）**

1. **默认路径逐位不变**（D2 关，判据②）：2000 tick digest 修复前/后**六项全等** ——
   `chain=b370e3c74c511965f1cbffa055bad7fa`、`flat_sum=1618384`、`energy=148694.258543`、
   `stomach=8085.537134`、`rng_draws=69009`、`global_sha=e04780f9f608282d`（脚本 `_trash_local/_tc_default_digest.py`）
2. **17 个钉死 digest 文件全绿**：`187 passed`（含 C7 / 能量 / 地形 / 季节 / 迁徙 / ARS / 尸体×3 / 水池 / 稀疏 / subpos×2 / wave2b）
3. **回归测试（新文件 3 例）**：同进程、同配置、**逐 tick 交错**步进 = 逐位一致 + 非空转断言（噪声/洗牌确实被触发）+ 快照存取闭环（续跑 = 连续跑）
4. **变异测试（防假绿）**：把 4 行改回 `np.random.*`（`_d2_rng` 空转）⇒ 交错测试**第 1 tick 即分化**
   （flat sha `af472624b2280eda` vs `f4bb81a3a3e99c56`，与修复前现场同型）；恢复后转绿
5. **全量套件**：`46F / 925P / 8S`（333 s）＝ T-B 的 46F **逐条同名**（46/46 `diff` 为空，0 新增/0 消失）+ 3 个新测试转绿（922→925）

**四、快照与续跑（一处行为变化，如实交代）**

- 新快照自带 `d2_rng_state` ⇒ 续跑一致性**强于修复前**（不再依赖 runner 侧车）
- ⚠️ **旧快照（修复前存）× 修复后代码续跑**：D2 开启档**不再逐位连续** ——
  runner 侧车 pickle 的是全局流，B′ 后引擎不读全局 ⇒ 侧车在本引擎上变 no-op。
  影响面 = 仅"跨这个修复 + D2 开 + 续跑"这一种组合；D2 关档（含 T4 系）`_d2_rng` 零消费 ⇒ 无影响。
- runner（`a4_verify_capacity.py:1019-1022` / `steady_k_probe.py:130-136`）我**未动**（范围外）。

**五、请裁 / 知会**

1. 方案 A vs B′ 我按 **B′** 落地（判据①优先，证据见表）——如不认同请裁，A 的完整现场在 `_trash_local/_tC_default_afterA.log`。
2. 侧车是否顺手改喂 `_d2_rng`（一行，为"旧快照跨版本续跑"保连续性）？未动。
