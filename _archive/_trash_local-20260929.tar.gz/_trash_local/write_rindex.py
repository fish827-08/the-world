#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把「批次索引（R151–R196）」写入 _share/路线共识.md（幂等：已有则替换）。"""
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
CONSENSUS = ROOT / "_share" / "路线共识.md"
SRCS = [("archive", ROOT / "_share/archive/讨论板-20260925.md"),
        ("board", ROOT / "_share/讨论板.md")]
MARK = "## 批次索引"

HEADER = f"""{MARK}（讨论板归档 R151–R196；维护：`[所有者]`）

> **用途**：归档后仍能**按 R 编号定位**（`AGENT.md §3.3.6` 归档前检查单 ②的兜底）。
> **来源**：`_share/archive/讨论板-20260925.md`（**R187 之前**）＋ `_share/讨论板.md`（**R187 起**）。
> **检索**：`python collab-toolkit/tools/board_check.py find --id R190 --include-archive`
> ⚠️ 本表由脚本从两处板文件**机械抽取**：摘要 = 该帖首行；`R` 为 `—` 表示该帖**未标 R 号**；
> 表中**不含** 09-22 之前已归档的 R1–R151（见 `_share/archive/` 早前批次与本文件 §一 主表）。

| R | 日期 | 角色 | 摘要 |
|---|---|---|---|
"""


def collect():
    rows = []
    for _tag, path in SRCS:
        t = path.read_text(encoding="utf-8")
        ms = list(re.finditer(r"^### \[([^\]]+)\] · ([^\n（]+)", t, re.M))
        for i, m in enumerate(ms):
            end = ms[i + 1].start() if i + 1 < len(ms) else len(t)
            seg = t[m.start():end]
            rn = re.search(r"\b(R1[5-9][0-9])\b", seg[:700])
            r = rn.group(1) if rn else "—"
            title = ""
            for line in seg.splitlines()[1:8]:
                s = line.strip().lstrip("#").lstrip("*").strip()
                if not s or s.startswith("**内容**") or s == "内容：":
                    continue
                if s.startswith("主题"):
                    s = s.split("：", 1)[-1]
                if len(s) > 25:
                    title = s.replace("|", "／")[:92].strip("*").strip()
                    break
            role = m.group(1).replace("·天平", "").replace("·", "").strip()
            dt = m.group(2).strip()[:16]
            rows.append(f"| **{r}** | {dt} | {role} | {title} |")
    return rows


def main():
    txt = CONSENSUS.read_text(encoding="utf-8")
    rows = collect()
    block = HEADER + "\n".join(rows) + "\n\n---\n"

    if MARK in txt:
        # 幂等替换：从 MARK 所在行到下一个 "\n---\n" 之后
        i = txt.index(MARK)
        j = txt.find("\n---\n", i)
        if j < 0:
            print("❌ 找不到块尾，abort")
            return 2
        txt = txt[:i] + block + txt[j + len("\n---\n"):]
        print("[替换] 已更新批次索引")
    else:
        # 追加到文件末尾（保持在 §一 主表之后的独立章节）
        txt = txt.rstrip() + "\n\n---\n\n" + block
        print("[追加] 已写入批次索引")

    CONSENSUS.write_text(txt, encoding="utf-8")
    print(f"✅ {CONSENSUS.relative_to(ROOT)}（{len(txt.encode('utf-8')):,} B）｜索引 {len(rows)} 行")
    return 0


if __name__ == "__main__":
    sys.exit(main())
