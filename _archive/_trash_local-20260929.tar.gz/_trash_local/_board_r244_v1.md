### [本地开发·性能线] · 2026-09-28 21:45（Asia/Shanghai）

**主题**：R244 v1「rd 再生子集化」——✅ **实施+全验收通过，交付**（逐位对拍 · 靶向单测 · fail-loud · 480×960 续跑冒烟全绿；收益实测见下）

---

#### 一、交付内容（4 文件，`sparse_fields` 默认值**未动**）

**① 三处改动（`simulation/sphere_engine.py`）**

| # | 位置 | 改动 |
|---|---|---|
| a | `_advance_one_tick` rd 分支 | 全场 `_regrowth_amount` → **脏格子集**（`np.flatnonzero(_dirty_mask)` ⇒ 子集结算 ⇒ 到顶格清脏；`_rd_growth_sum` 预分配 + 逐 tick 清零 + 子集回填，不再每 tick 重绑定） |
| b | `_step_population` 喂 `note_tick` 前 | **分母补算**（`kill_denom=="regrowth"` 时）：只对被吃格补（`intake>0 ∧ growth==0` ⇒ 重算名义再生）——净格被吃的极端密度通道不再被 `denom>0` 静默滤出 |
| c | `_step_corpse_decay` | `corpse_patch_boost` 全场 → `bo` 子集（T-G profile：`bo>0` 占 84% tick、\|bo\| 中位 69） |

**② 范围锁重写（同上文件构造期）**：锁③从「rd 关」→ **放行 `rd.enabled ∧ bgzero`**；`rd ∧ sparse ∧ ¬bgzero` ⇒ **构造期 `ValueError`**（验收③ fail-loud，防未来开搬移时"净格恒净"前提静默破裂）；负的 `dead_regen_mult/rest_regen_mult` ⇒ 资源侧静默退回全场（信号侧不受影响）。`simulation/config.py` 注释同步。

**③ 测试（`tests/test_sparse_fields.py`）**：旧"rd 开 ⇒ 资源侧退场"语义断言全部改写；新增 **④c 靶向单测**（验收②：满格被吃 ⇒ 补算前后杀死集/损伤账本逐位对比，含"不补算 ⇒ 不一致"的承重证据）。写入守卫 3/3 绿（新写入点带 `sparse:lazy` / `sparse:inc` 标签）。

---

#### 二、验收证据（四条前提逐条）

| 前提 | 结果 |
|---|---|
| ① 逐 tick digest 等价 + 快照续跑 | **绿**。单测层：`(rd on × sparse on) ≡ (rd on × sparse off)` 逐 tick 全状态 sha 相等 + 2×2 快照往返（含"恢复 ≡ 不中断"与"两臂互等"）。**480×960 实尺寸冒烟**（`experiments/rd_resume_smoke.py`）：save@1000 → resume → 500/500 tick digest 全等，rd 六数组+计数器逐位一致，死因账本一致，**结论「可」**（墙钟 136s） |
| ② 分母补算靶向单测 | **绿**（含变异证据：不补算 ⇒ `_dead` 必须不同） |
| ③ `rd ∧ sparse ⇒ bgzero` fail-loud | **绿**（`pytest.raises(ValueError, match="bg_production_zero")`） |
| ④ 不许动默认值 | **绿**。`sparse_fields=False` 默认未动（唯一回滚点）；关档路径代码原样保留 |

**收益实测**（480×960 / k=2.5 / subpos / 静默机 / 并发 1 / 交错配对计时；`_trash_local/_v1_bench.py`）：

| 段 | rd 全场（现状） | 子集（v1） | 节省 | 备注 |
|---|---|---|---|---|
| **地板 N=0**（灭绝后 300 tick） | **20.78** 均值 / 20.65 中位 ms/tick | **5.84** / 5.77 | **−14.95 ms（−72%）** | 优于派工估算（预估 7.5–8.5；实测 5.84）。残余 = rd 记账（rotate 1.9 / capacity_from_base 1.0 等，T-D 已知"消不掉"项） |
| **活体 N∈[53,771]**（200 tick；两臂逐位同轨） | 39.18 / 38.18 | 27.35 / 26.49 | **−11.83（−30%）** | 活体段分母更大（种群循环 7.4 + note_tick 4.5 恒定项），且脏集随吃随生 |

**微基**（`_regrowth_amount` 单调用，全场 10.35 ms）：|idx|=2k ⇒ 0.022 ms（0.2%）；20k ⇒ 0.205（2%）；100k ⇒ 2.19（21%）⇒ 即使 N 大增脏集到 10 万格，子集仍省 ~80% 再生链。

（口径说明：T-E 同款配对脚本 `_te_signal_bench.py` 跨日绝对数漂移大（同配置地板全臂 25.9@09-27 vs 20.8@09-28），故只报**同 run 内配对差**。）

---

#### 三、一处口径解释（请所有者核）

派工里「**一般档保持全场**」与「**加构造期 fail-loud（rd ∧ sparse ⇒ bgzero）**」字面冲突。我的落法：
- `rd ∧ sparse ∧ ¬bgzero` ⇒ **报错**（把验收③的蕴含式做成可达、可测的断言；该组合在仓内无使用者，S2/S3 主线 = bgzero 不受影响）；
- 「一般档保持全场」= **既有档位（sparse 关，或 rd 关）行为零变化**——不改默认值、不碰关档代码。
如所有者本意是"静默退回全场"而非报错，一行可改（构造期降级 + 注释），对拍不受影响。

---

#### 四、全量回归 + 交付

- **全量 pytest**（`--ignore=test_broker`）：**45 failed / 930 passed / 8 skipped**。
  对照 T-F 基线 46F/928P（同去 broker 口径）**逐名 diff：0 新增失败、0 改名**；
  −1 = 云归 R98 修复（`f5f8f9b`）已把 `test_r98_nonascii_print` 转绿；+2 = 本班新增 ④c + R98 转绿。
  剩余 45 条仍为 R215 §七-2 存量（GBK 环境类，不修）。
- **提交**：`04147b2`（4 文件，225+/55−）已推 `gitee/main`，`ls-remote` 已对账。
  `_trash_local/_v1_bench.py`（收益脚本）留在工作区未提交（同 T-E 先例）。
- **阻塞**：无。本班收活。
- **给云端的衔接**：批跑（R243-① 吸引子扫描 / 批 A）可直接用 `sparse_fields=True`（rd 开 + bgzero 档）
  ——**收益：60k 单 run 地板段每 tick 省 ~15 ms**；跑前仍按 R237 纪律先跑 `rd_resume_smoke.py`。
