"""T1 侦察：邻居表事实 + 现况建表成本（scratch，不入库）。"""
from __future__ import annotations

import ctypes
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

from simulation.config import SimConfig      # noqa: E402
from simulation.sphere_engine import SphereEngine  # noqa: E402
from world.sphere_world import SphereWorld   # noqa: E402


class _PMC(ctypes.Structure):
    _fields_ = [("cb", ctypes.c_ulong), ("PageFaultCount", ctypes.c_ulong),
                ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]


def rss_mb() -> tuple[float, float]:
    pmc = _PMC()
    pmc.cb = ctypes.sizeof(pmc)
    h = ctypes.windll.kernel32.GetCurrentProcess()
    ctypes.windll.psapi.GetProcessMemoryInfo.argtypes = [
        ctypes.c_void_p, ctypes.POINTER(_PMC), ctypes.c_ulong]
    ctypes.windll.psapi.GetProcessMemoryInfo.restype = ctypes.c_int
    ctypes.windll.psapi.GetProcessMemoryInfo(h, ctypes.byref(pmc), pmc.cb)
    return (pmc.WorkingSetSize / 1e6, pmc.PeakWorkingSetSize / 1e6)


rows, cols = 480, 960
w = SphereWorld(rows, cols)
n = w.n_cells
print(f"world {rows}x{cols} = {n} cells | pole_top={w._pole_top} pole_bottom={w._pole_bottom}")
print(f"world._nb_table     : {w._nb_table.shape} {w._nb_table.dtype} = {w._nb_table.nbytes/1e6:.2f} MB")
print(f"world._pole_nb      : {w._pole_nb.shape} {w._pole_nb.dtype} = {w._pole_nb.nbytes/1e6:.4f} MB")
print(f"  pole_nb[0] 前 6 个 : {w._pole_nb[0][:6]}")
print(f"  pole_nb[1] 前 6 个 : {w._pole_nb[1][:6]}")

# 每格邻居数直方图（按 world.neighbors 语义）
cnt = np.array([len(w.neighbors(c)) for c in range(0, n, max(1, n // 20000))])
u, c_ = np.unique(cnt, return_counts=True)
print(f"邻居数直方（抽样 {len(cnt)} 格）: {dict(zip(u.tolist(), c_.tolist()))}")
polar = np.flatnonzero(w.is_pole(np.arange(n)))
print(f"极点格数 = {len(polar)} = 2*cols = {2*cols} | 占比 {len(polar)/n:.4%}")

# 现况：引擎建表成本（复刻 sphere_engine.py:575-579 的两行）
stride = max(8, cols)
t0 = time.perf_counter()
tab = np.full((n, stride), -1, dtype=np.int64)
t_alloc = time.perf_counter() - t0
t0 = time.perf_counter()
for c in range(n):
    nbs = w.neighbors(c)
    tab[c, :len(nbs)] = nbs
t_loop = time.perf_counter() - t0
print(f"现况建表：alloc {t_alloc:.2f}s + 逐格循环 {t_loop:.2f}s = {t_alloc+t_loop:.2f}s"
      f" | 表 {tab.nbytes/1e6:.1f} MB")
del tab
cur, peak = rss_mb()
print(f"RSS：当前 {cur:.0f} MB ｜ 峰值 {peak:.0f} MB")

# 新方案预估
print(f"新方案：main (n_cells,8) int64 = {n*8*8/1e6:.1f} MB"
      f"（若与 world 表**同一块内存**则新增 0）｜pole (2,cols) 复用 = 0.0 MB")
