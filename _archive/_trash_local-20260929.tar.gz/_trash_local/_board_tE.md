**T-E 交付：信号稀疏与资源稀疏解耦（rd 开档信号侧可开）＋ 逐位对拍 ＋ 收益实测**

派工：R231（`c7809bd`）。目标档 = `rd 开 ∧ bg_production_zero`（S2/S3/T4 主线）。
**已合 main：`389bfc2`（已 push，`ls-remote` 对账一致）。**
文件：`simulation/sphere_engine.py`（闸解耦）＋ `simulation/config.py`（范围锁文档）＋
`tests/test_sparse_fields.py`（④b 新增 2 例）。**默认值未动**（`sparse_fields` 默认 False = 唯一回滚点）。

## 一、改动（闸解耦，3 行生产代码）

| 侧 | 旧闸 | 新闸 |
|---|---|---|
| 信号侧（`signals.enable_sparse`） | `sparse_fields ∧ ¬sim_core ∧ ¬rd` | `sparse_fields ∧ ¬sim_core`（**与 rd 解耦**） |
| 资源侧（`resources.enable_lazy`） | 同上（同一布尔） | **不变** —— `_sparse_fields` 现只表示资源侧闸 |

依据：信号活跃集（`age>0`）自包含、与 rd 正交（**rd 从不写 `_marks`**）⇒ 信号侧范围锁只剩
①配置开关 ②Python 路径。两侧真值分别以 `signals._sparse` / `resources._lazy` 为准。
**Rust 路径**（`use_sim_core=True`）⇒ 两侧都不开，**静默退回全场**（与旧语义一致，未动）。

## 二、逐位对拍（rd 开档；`tests/test_sparse_fields.py` ④b）

- `test_engine_rd_on_signal_sparse_matches_full_bitwise`：同 seed，`(rd on × 稀疏开)` vs `(rd on × 稀疏关)`，
  **逐 tick** digest（flat/energy/tick ＋ grid/`_marks`/`_age` 三个 sha）**150 tick 全等**。
  防空转断言：两臂 rd 真开、稀疏侧真稀疏（关侧真全场）、资源侧两臂均全场、活跃集非空、
  非早灭（`tick>10`）。
- `test_engine_rd_on_signal_sparse_snapshot_roundtrip`：60 tick → save → load
  （`signals._sparse is True` ∧ `resources._lazy is False`）→ 续跑 40 tick 与不中断同批**逐位一致**
  （活跃集重建正确）。
- 范围守卫（c2 更新）：rd 开 ⇒ `_sparse_fields=False`、`_lazy=False`，但 `signals._sparse=True`。
- 稀疏族 **16/16 绿**，含写入点扫描守卫（`test_sparse_write_guard.py`：无新增写入点，标签齐全）。

## 三、收益实测（rd 开档；静默机**并发 = 1**；480×960 T4 同构臂；脚本 `_trash_local/_te_signal_bench.py`）

方法：**交错配对逐 tick 计时**（两臂同 seed、同 rd、仅信号稀疏差 ⇒ 轨迹逐位同轨；每段跑完
复验 digest 相等才认账）。k=2.5 / subpos / rgm=1.195 / duration=20。

| 段 | 全场（墙钟 ms/tick） | 信号稀疏 | 省 |
|---|---|---|---|
| 地板 N=0（灭绝后 300 tick） | 25.94 均值 / 25.73 中位 | 25.09 / 24.98 | **0.86 均值 / 0.75 中位** |
| 活体 pop843 → N 53–771（200 tick） | 47.43 / 46.70 | 46.91 / 46.05 | **0.52 / 0.65** |

profile 归因（self ms/tick）：`SignalField.tick` 地板 **0.552 → 0.002**；活体 **0.483 → 0.028**；
稀疏侧维护增量：`_activate` +0.010、`write_many` +~0.02（活体）。

微基（热缓存，`signals.tick()` 单调用中位 50 样本）：|active| = 0 / 2k / 20k 时
全场 0.164 / 0.388 / 1.014 → 稀疏 0.000 / 0.023 / 0.136 ms。

**口径更正（对 T-D 帖的预估）**：T-D 帖引"信号解耦 ≈ −2.34 ms/tick（T-A 消融数）"作预估；
本批配对实测净收益 **≈0.5–0.9 ms/tick**（墙钟）。T-A 的 2.34 是 **CPU 消融差**且该表各项**不可加**
（三项主因之和 46.35 > 该档总 CPU 28.28 ⇒ 消融互相重叠）⇒ 属不同口径。**以本批配对实测为准**；
T-A 表该行（`signals.tick 2.34`）后续引用建议标注"消融口径、非配对"。

## 四、边界（本批未做，与派工一致）

- 资源侧仍锁 `rd 关`：v1 子集化（T-D 三改动 + 预注册验收）＝ 已裁的**下批**活。
- corpse 路径（T-D 风险 4）未动 ⇒ v1 一并处理。
- 默认值未改；无数据产品（脚本/日志留本机 `_trash_local/`）。

## 五、测试账本（全量）

**46F / 927P / 8S**（349 s）＝ T-C 账本（46F/925P/8S）＋ 本批新增 2 例通过；
**46 条失败逐名 diff 与 T-C 完全一致**（0 增 / 0 减 / 0 改名）。
定向：稀疏族 **16/16**（含写入点扫描守卫）；C7 + RNG 隔离 **22/22**。

**T-E 完毕**（21:5x 前上板，早于 23:00 收活线）。下一步：资源侧 v1（T-D 三改动 + 预注册验收）待所有者排期。
