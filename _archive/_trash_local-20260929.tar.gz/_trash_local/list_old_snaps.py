"""只读：列出数据仓里 2026-09-24 之前（13.5 纪元之前）的 .npz 旧快照。"""
import os
import time
from pathlib import Path

ROOT = Path(r"C:\Users\圣羽\Desktop\temp\tempCode\the-world\the-world-data")
CUT = time.mktime(time.strptime("2026-09-24 00:00:00", "%Y-%m-%d %H:%M:%S"))


def human(n: int) -> str:
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f}{u}"
        n /= 1024


rows = []
for dirpath, dirnames, filenames in os.walk(ROOT):
    if ".git" in dirnames:
        dirnames.remove(".git")
    for fn in filenames:
        p = Path(dirpath) / fn
        try:
            st = p.stat()
        except OSError:
            continue
        if p.suffix.lower() != ".npz":
            continue
        if st.st_mtime >= CUT:
            continue
        rows.append((st.st_size, str(p.relative_to(ROOT)).replace("\\", "/"),
                     time.strftime("%Y-%m-%d", time.localtime(st.st_mtime))))

rows.sort(reverse=True)
tot = sum(r[0] for r in rows)
print(f"13.5 之前（<2026-09-24）的 .npz 快照：**{len(rows)} 个 / {human(tot)}**\n")

per_dir: dict[str, list[int]] = {}
for sz, name, d in rows:
    key = name.rsplit("/", 1)[0]
    b, n = per_dir.get(key, [0, 0])
    per_dir[key] = [b + sz, n + 1]
print(f"{'目录':<56}{'体积':>10}{'文件数':>8}")
for k, (b, n) in sorted(per_dir.items(), key=lambda kv: -kv[1][0]):
    print(f"{k:<56}{human(b):>10}{n:>8}")

out = ROOT.parent / "_trash_local" / "purge_paths_p2.txt"
with open(out, "w", encoding="utf-8") as f:
    for sz, name, d in rows:
        f.write(name + "\n")
print(f"\n路径清单已写：{out}（{len(rows)} 行）")
