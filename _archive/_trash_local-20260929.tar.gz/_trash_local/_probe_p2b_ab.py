"""P2② 冒烟对拍：快路径（默认）vs 参考循环（`_batch_move_on=False`）逐位一致？

用法：.venv\\Scripts\\python.exe _trash_local/_probe_p2b_ab.py
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from simulation.config import SimConfig          # noqa: E402
from simulation.sphere_engine import SphereEngine  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def make_cfg(seed: int) -> SimConfig:
    c = SimConfig(seed=seed)
    c.world.rows, c.world.cols = 60, 120
    c.resources.distribution = "patchy"
    c.resources.bg_production_zero = True
    c.resources.patch_regrowth_mult = 1.195
    c.resources.patch_count = 60
    c.population.initial_count = 400
    c.simulation.use_sim_core = False
    c.subpos.enabled = True          # T4 同款：亚格位移（Python 路径）
    c.subpos.speed_max = 0.125
    c.subpos.speed_gain = 0.125
    c.subpos.subdiv = 80
    return c


ARRAYS = [
    "_flat", "_energy", "_stomach", "_stomach_scav", "_genes", "_age",
    "_generation", "_parent", "_id", "_trust", "_interpret", "_work_memory",
    "_valence", "_arousal", "_baseline", "_expectation",
    "_out_taken", "_feed_fast", "_feed_slow", "_heading", "_giveup_ct",
]


def snap(e: SphereEngine) -> dict:
    d = {}
    for name in ARRAYS:
        arr = getattr(e, name, None)
        if arr is None:
            continue
        d[name] = np.array(arr, copy=True)
    d["_next_id"] = np.int64(e._next_id)
    d["_tick"] = np.int64(e._tick)
    d["_mem_ptr"] = np.int64(e._mem_ptr)
    for name in ("_rs_children", "_rs_observed", "_rs_g15", "_rs_age", "_rs_energy",
                 "_rs_cc0", "_rs_cohort", "_emit_count"):
        arr = getattr(e, name, None)
        if arr is not None:
            d[name] = np.array(arr, copy=True)
    d["marks"] = np.array(e.signals._marks, copy=True)
    d["grid"] = np.array(e.resources._grid, copy=True)
    return d


def cmp(a: dict, b: dict, tick: int) -> bool:
    ok = True
    for k in a:
        va, vb = a[k], b[k]
        if isinstance(va, np.int64):
            if int(va) != int(vb):
                print(f"  t={tick} 差异标量 {k}: {int(va)} vs {int(vb)}")
                ok = False
            continue
        if va.shape != vb.shape:
            print(f"  t={tick} 形状差异 {k}: {va.shape} vs {vb.shape}")
            ok = False
            continue
        if va.dtype != vb.dtype:
            print(f"  t={tick} dtype 差异 {k}: {va.dtype} vs {vb.dtype}")
            ok = False
        if va.size == 0:
            continue
        eq = (va == vb)
        if not eq.all():
            n = int((~eq).sum())
            if va.dtype.kind == "f":
                md = float(np.nanmax(np.abs(va[~eq] - vb[~eq]))) if n else 0.0
                print(f"  t={tick} 数值差异 {k}: {n} 处，最大|Δ|={md:.3e}")
            else:
                print(f"  t={tick} 数值差异 {k}: {n} 处")
            ok = False
    return ok


def run(pin_poles: bool, ticks: int, seed: int) -> bool:
    c1, c2 = make_cfg(seed), make_cfg(seed)
    e1 = SphereEngine(c1)
    e2 = SphereEngine(c2)
    e2._batch_move_on = False                      # 参考循环
    if pin_poles:
        n_cells = e1.world.n_cells
        for e in (e1, e2):
            e._flat[0] = 0
            e._flat[1] = n_cells - 1
            e._flat[2] = 0
            e._energy[:] = np.maximum(e._energy, 200.0)
    ok = True
    for t in range(1, ticks + 1):
        e1.step()
        e2.step()
        if not cmp(snap(e1), snap(e2), t):
            ok = False
            break
    tag = "极点钉住" if pin_poles else "默认随机"
    print(f"[{tag}] seed={seed} ticks={ticks} → {'逐位一致 ✅' if ok else '有差异 ❌'}"
          f"（末 N={len(e1._id)} / {len(e2._id)}）")
    return ok


if __name__ == "__main__":
    r = True
    r &= run(False, 400, 42)
    r &= run(True, 200, 7)
    print("SMOKE", "PASS" if r else "FAIL")
    sys.exit(0 if r else 1)
