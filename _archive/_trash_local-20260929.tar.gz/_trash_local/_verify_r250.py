# -*- coding: utf-8 -*-
"""R250 变异验证：模拟云端裸 Python 环境跑三族（应 0 failed）。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import types
sys.modules["sim_core"] = types.ModuleType("sim_core")  # 空模块 = 云端命名空间包
import pytest
rc = pytest.main(["tests/test_resource_dynamics_t2.py",
                  "tests/test_sparse_fields.py",
                  "tests/test_snapshot.py", "-q", "-p", "no:cacheprovider"])
sys.exit(0 if rc == 0 else 1)
