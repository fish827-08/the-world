**主题**：R200 —— 数据仓瘦身预告（126MB 中间检查点已隔离，待提交删除）＋ 主仓 `_rerun_logs`（667MB）已挪出

**内容**：

## ① 做了什么（**可回滚**：全部先挪到隔离区，未直接删除）

| 对象 | 体积 | 处置 |
|---|---|---|
| **数据仓** `_rerun_logs/cstep_snap_ext/{rolling,keypoints}/` | **126 MB / 14 文件** | 已挪到 `Desktop\temp\_trash_purge_20260925\data_repo\`；数据仓里**提交删除**（本帖即预告） |
| **主仓** `_rerun_logs/`（未跟踪） | **667 MB** | 已挪到 `Desktop\temp\_trash_purge_20260925\main_rerun\`；**不涉及 git**（未被跟踪） |

**保留**：`_rerun_logs/cstep_snap_ext/oracle_m1.3_s46_ext.snapshot.npz`（**该批的最终快照 + rngstate**，19 MB）**未动**；
所有 CSV/JSON 结果、各实验目录的最终快照**一律未动**。

**已验证**：主仓 `git status` 干净；受影响测试（`test_cstep_presets` / `test_batch_runner` / `test_136_*` / `test_138_migration`）**61 passed** —— 这些测试只拼命令字符串、不读实际快照文件，`_rerun_logs` 缺失不影响。

## ② 🔴 必须交代的坏消息：**清工作树不会让远端配额下降**

数据仓 `.git` 历史 **834 MB**（63 个提交）≈ 工作树 778 MB。
**删除只影响最新提交** —— 被删文件在**前 62 个提交里仍被引用** ⇒ 远端仍是 **847 MB / 1024 MB（>80%）**。

⇒ 本次清理的效果是**目录变干净 + 本地盘释放 799 MB**，**不是配额下降**。
真要降配额只有两条路（**均未做，等 fish 示下**）：
- **重写历史**（`filter-repo`）⇒ 63 个提交 hash 全变 ⇒ **所有 clone 失效，需重新 clone + 重配**；
- **另起新数据仓**（只带当前需要的文件，旧仓留作归档）⇒ 不动历史、不打断任何人。

## ③ 给各线的提醒

1. 引用过 `_rerun_logs/cstep_snap_ext/rolling|keypoints` 下快照的，**改引最终快照** `oracle_m1.3_s46_ext.snapshot.npz`（同一批、19 MB）；
2. 主仓 `_rerun_logs/` 已不在工作树 ⇒ **批跑会自己重建该目录**，`batch_runner` 的 `snapshot-dir` 无需改；
3. 若需要回滚：隔离区 `Desktop\temp\_trash_purge_20260925\` 里的文件**原样保留**，拷回即可。

## ④ 附带发现（**未动**，供后续立案）

主仓顶层还有两个陈旧 git 残留：`.git-rewrite/` 与 `.git.corrupt-20260913/`。
按 F-R10（仓库内删除 fail-closed ⇒ 一律 rename 挪移）**本次未动**，建议后续单独立案确认后再处置。

—— `[所有者·天平]`
