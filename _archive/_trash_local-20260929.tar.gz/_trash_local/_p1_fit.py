"""P1 固定/边际成本分解（把 ms/tick = a + b×N 拟合出 a、b）。

数据源：results/p1_profile/<arm>.csv（未完成的臂退化为解析 _trash_local/_p1_<arm>.log 的采样行）。
注意：**低 N 样本会严重抬高"每体 μs"**（固定成本被少数个体摊）⇒ 本脚本用最小二乘的
斜率 b 作为「边际 μs/体」，截距 a 作为「与 N 无关的固定 ms/tick 地板」。

用法：.venv\\Scripts\\python.exe _trash_local/_p1_fit.py
"""
from __future__ import annotations

import argparse
import csv
import io
import re
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ARM_FILES = {
    "py+subpos": ROOT / "results/p1_profile/py_subpos.csv",
    "py": ROOT / "results/p1_profile/py.csv",
    "rust": ROOT / "results/p1_profile/rust.csv",
    "py+subpos(T4regime)": ROOT / "results/p1_line_t4regime/py_subpos.csv",
}
LOG_FILES = {
    "py+subpos": ROOT / "_trash_local/_p1_pysubpos.log",
    "py": ROOT / "_trash_local/_p1_py.log",
    "rust": ROOT / "_trash_local/_p1_rust.log",
}
SAMPLE_RE = re.compile(r"t=(\d+)\s+N=(\d+)\s+([\d.]+) ms/tick")


def load_csv(p: Path) -> list[tuple[int, int, float]]:
    rows = []
    with io.open(p, encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            rows.append((int(r["t"]), int(r["N"]), float(r["ms_per_tick"])))
    return rows


def load_log(p: Path) -> list[tuple[int, int, float]]:
    rows = []
    for m in SAMPLE_RE.finditer(p.read_text(encoding="utf-8", errors="replace")):
        rows.append((int(m.group(1)), int(m.group(2)), float(m.group(3))))
    return rows


def fit(rows: list[tuple[int, int, float]]) -> tuple[float, float, float, int, int]:
    n = np.array([r[1] for r in rows], dtype=np.float64)
    ms = np.array([r[2] for r in rows], dtype=np.float64)
    b, a = np.polyfit(n, ms, 1)
    pred = a + b * n
    ss_res = float(((ms - pred) ** 2).sum())
    ss_tot = float(((ms - ms.mean()) ** 2).sum())
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    return a, b * 1000.0, r2, int(n.min()), int(n.max())


FLOOR_MS = {                    # [实测] pop=1/0 跑到 N=0 时的每 tick 地板（results/p1_floor）
    "py+subpos": 16.7, "py": 16.7, "py+subpos(T4regime)": 16.7, "rust": 6.4,
}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--min-t", type=int, default=1000)
    a = ap.parse_args()

    print(f"{'臂':<22}{'样本':>5}{'N 范围':>14}{'固定 a':>10}{'边际 b':>10}{'R²':>7}"
          f"│{'成熟段 a':>10}{'成熟段 b':>10}{'R²':>7}{'中位边际':>10}")
    print("-" * 118)
    for arm, p in ARM_FILES.items():
        rows = None
        src = ""
        if p.exists():
            rows = load_csv(p)
            src = "csv"
        if (rows is None or len(rows) < 3) and arm in LOG_FILES:
            lg = load_log(LOG_FILES[arm])
            if rows is None or len(lg) > len(rows):
                rows, src = lg, "log"
        if not rows:
            print(f"{arm:<22}{'—':>5}  （还没数据）")
            continue
        a0, b0, r20, n0, n1 = fit(rows)
        mature = [r for r in rows if r[0] >= a.min_t]
        if len(mature) >= 3:
            a1, b1, r21, _, _ = fit(mature)
        else:
            a1, b1, r21 = float("nan"), float("nan"), float("nan")
        floor = FLOOR_MS.get(arm, 0.0)
        marg = [(ms - floor) * 1e3 / max(n, 1) for _, n, ms in mature if n > 0]
        med = float(np.median(marg)) if marg else float("nan")
        print(f"{arm:<22}{len(rows):>5}{f'{n0}–{n1}':>14}{a0:>10.2f}{b0:>10.2f}{r20:>7.3f}"
              f"│{a1:>10.2f}{b1:>10.2f}{r21:>7.3f}{med:>10.2f}  [{src}]")

    print("\n读法：a = 与个体数无关的每 tick 地板；b = 每多一个体的边际成本（μs）。")
    print(f"     「成熟段」= t≥{a.min_t}（生态已过崩溃期）；「中位边际」= median((ms/tick − 地板)/N)。")
    print("     b 才是「下沉/向量化」能拿掉的那部分；a 只能靠改资源/光照/信号段的算法拿掉。")


if __name__ == "__main__":
    main()
