import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import numpy as np
rng = np.random.default_rng(7)

def seq_sum(a):
    out = np.zeros(a.shape[1], dtype=np.float64)
    for r in range(a.shape[0]):
        out = out + a[r]
    return out

for K in (7, 16, 64):
    a = (rng.standard_normal((K, 16)) * 10.0 ** rng.integers(-25, 25, size=(K, 16)))
    s_seq = seq_sum(a)
    s_mean = a.mean(axis=0) * K          # 反推 mean 内部的 sum？不行，mean 先 sum 再除，乘回来是精确的（除以 K 再乘 K 可能不精确）
    m = a.mean(axis=0)
    m_seq = s_seq / K
    s_red = np.add.reduceat(a, np.array([0]), axis=0)[0]
    s_sum = a.sum(axis=0)
    print(f"K={K}")
    print("   mean == seq/K :", m.tobytes() == m_seq.tobytes())
    print("   reduceat == seq:", s_red.tobytes() == s_seq.tobytes())
    print("   sum(axis=0) == seq:", s_sum.tobytes() == s_seq.tobytes())
    # 逐列对比 mean 与 seq/K 的差异量级
    d = np.abs(m - m_seq)
    print("   |mean - seq/K| max =", d.max(), " 位模式不同的列数:", int((m.view(np.int64) != m_seq.view(np.int64)).sum()))

# 手动 pairwise（numpy 风格，块=8 递归）对比 reduceat
def pw_sum(a):
    n = a.shape[0]
    if n < 8:
        out = np.zeros(a.shape[1], dtype=np.float64)
        for r in range(n):
            out = out + a[r]
        return out
    half = n // 2
    return pw_sum(a[:half]) + pw_sum(a[half:])

for K in (16, 64, 500):
    a = (rng.standard_normal((K, 16)) * 10.0 ** rng.integers(-25, 25, size=(K, 16)))
    s_red = np.add.reduceat(a, np.array([0]), axis=0)[0]
    print(f"K={K} reduceat == 手动递归对半 pairwise:", s_red.tobytes() == pw_sum(a).tobytes())
