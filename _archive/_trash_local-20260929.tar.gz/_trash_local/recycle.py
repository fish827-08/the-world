#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把给定路径移入**回收站**（可恢复）。

原理：`shell32.SHFileOperationW` + `FOF_ALLOWUNDO`（Win32 标准"删除到回收站"），
不依赖 COM（本机安全策略禁止 COM 实例化）。

用法：
    python recycle.py --probe                 # 只查回收站容量配置，不动任何文件
    python recycle.py --size <dir>            # 只算目录大小
    python recycle.py <path> [<path> ...]     # 真正移入回收站（--yes 确认）
"""
import ctypes
import os
import sys
import winreg
from ctypes import wintypes
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

FO_DELETE = 3
FOF_SILENT = 0x0004
FOF_NOCONFIRMATION = 0x0010
FOF_ALLOWUNDO = 0x0040
FOF_NOERRORUI = 0x0400


class SHFILEOPSTRUCTW(ctypes.Structure):
    _fields_ = [
        ("hwnd", wintypes.HWND),
        ("wFunc", wintypes.UINT),
        ("pFrom", wintypes.LPCWSTR),
        ("pTo", wintypes.LPCWSTR),
        ("fFlags", ctypes.c_uint16),
        ("fAnyOperationsAborted", wintypes.BOOL),
        ("hNameMappings", ctypes.c_void_p),
        ("lpszProgressTitle", wintypes.LPCWSTR),
    ]


def human(n):
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f}{u}"
        n /= 1024
    return f"{n:.1f}PB"


def dir_size(p: Path):
    total = nf = 0
    for dp, _dn, fn in os.walk(p):
        for f in fn:
            try:
                total += os.path.getsize(os.path.join(dp, f))
                nf += 1
            except OSError:
                pass
    return total, nf


def probe():
    print("=== 回收站容量配置（HKCU\\...\\BitBucket\\Volume，单位 MB）===")
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\BitBucket\Volume")
    except OSError as exc:
        print(f"读取失败：{exc}")
        return
    i = 0
    while True:
        try:
            sub = winreg.EnumKey(key, i)
        except OSError:
            break
        i += 1
        try:
            with winreg.OpenKey(key, sub) as sk:
                mc = winreg.QueryValueEx(sk, "MaxCapacity")[0]
        except OSError:
            mc = "<无此项>"
        print(f"  {sub}   MaxCapacity = {mc}")
    if i == 0:
        print("  （无任何卷配置 ⇒ 全部使用默认值）")
    print("\n说明：MaxCapacity 单位 MB；默认值通常 = 卷容量的 5%（上限约 25 GB）。")


def recycle(paths):
    ok = fail = 0
    for p in paths:
        src = Path(p)
        if not src.exists():
            print(f"SKIP 不存在: {src}")
            continue
        # pFrom 需以 \0\0 结尾（多路径用 \0 分隔）
        frombuf = str(src.resolve()) + "\0\0"
        op = SHFILEOPSTRUCTW()
        op.hwnd = None
        op.wFunc = FO_DELETE
        op.pFrom = frombuf
        op.pTo = None
        op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI
        op.fAnyOperationsAborted = False
        rc = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
        gone = not src.exists()
        if rc == 0 and gone:
            print(f"OK   → 回收站: {src}")
            ok += 1
        else:
            print(f"FAIL rc={rc} gone={gone} 中止={bool(op.fAnyOperationsAborted)}: {src}")
            fail += 1
    print(f"\n成功 {ok} / 失败 {fail}")
    return 1 if fail else 0


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args or args[0] == "--probe":
        probe()
        raise SystemExit(0)
    if args[0] == "--size":
        for a in args[1:]:
            b, nf = dir_size(Path(a))
            print(f"{human(b)}  {nf} files  {a}")
        raise SystemExit(0)
    if "--yes" not in args:
        print("拒绝执行：需要在命令里显式给出 --yes（防止误触）")
        raise SystemExit(2)
    raise SystemExit(recycle([a for a in args if a != "--yes"]))
