### [本地开发·性能线] · 2026-09-26 20:22

**T1 交付：P0.1 邻居表紧凑化** —— 代码 commit `6bae84b`、附带 test 对齐 `7b307e5`，已推 `gitee/main`
（`ls-remote` = `7b307e5ec02e2ff06207699426e8c4485813a32e` = 本地 HEAD，两边一致）。
方案 = 开工前定案①（`ab7f8ec`）：复用 world 已有紧凑缓存 `(n_cells,8)` + 极点带 `(2,cols)`，消费端按行号分支。
**极点格 = 相邻纬度带整行 cols=960 格（全量，非采样）** ⇒ 邻居集合与顺序逐位不变 ⇒ 纯结构重构。

## 一、四条验收（全绿）

| # | 指标（480×960, pop 5000, 同 seed/配置） | 前 | 后 | 门 |
|---|---|---|---|---|
| ① | 邻居表内存 | **3 538.9 MB**（=3375 MiB，单 run RSS 94.7%） | **29.5 MB** | ≤30 MB ✅ |
| ① | 峰值 RSS | 3 738 MB | **198 MB** | — |
| ② | tick（Rust 臂） | 38.02 ms/tick | **32.92 ms/tick** | **1.155×**（门 1.13–1.16）✅ |
| ② | tick（Python 臂） | 69.99 ms/tick | 69.28 ms/tick | 1.01×（如实报，见下） |
| ③ | C7 digest | — | `(574887, 11266.746993)` 不变 | digest 门 173 passed ✅ |
| ④ | 建表 | 1.22 s | **0.16 s** | <10 s ✅ |

`[实测]` 探针 `_trash_local/_perfline_hw_probe.py` 原文（30 tick）：
```
[Py  ] 480x960 pop= 5000 | N= 5000 | 构造  0.16s |   69.28 ms/tick | nb_table    29.5 MB | RSS 35->153 峰值 196 MB
[Rust] 480x960 pop= 5000 | N= 5000 | 构造  0.17s |   32.92 ms/tick | nb_table    29.5 MB | RSS 35->153 峰值 198 MB
```
前值（同脚本同配置，`_perfline_hw2.txt`）：Py 69.99 / Rust 38.02 ms/tick，表 3538.9 MB，峰值 3735 / 3738 MB。

**② 的臂间差异说明**：提速来自 fat 表 stride（480×960 下行距 7680 B）造成的 cache/TLB 代价，只有 **Rust 臂**在热核里逐个体索引该表 ⇒ 1.155× 命中门；
Python 臂的取邻走 `world.neighbors`（本就不读该表），其 69 ms/tick 由别的 NumPy 开销主导 ⇒ 1.01× 属于预期，不是验收不达标。

## 二、改了什么（7 文件）

- **Rust**：新增 `sim_core/src/neighbors.rs::nb_slice`（`row==pole_top/pole_bottom` ⇒ 极点带，否则主表 `c*nb_stride`）；
  4 入口 `step_movement` / `predation_attack` / `predation_and_culture` / `culture_learn` 改用它并透传 `pole_nb/n_cols/pole_top/pole_bottom`；`lib.rs` 绑定同步 + `pole_len == 2*n_cols` 校验。
- **Python** `simulation/sphere_engine.py`：构造块直接引用 `world._nb_table`/`_pole_nb`（省掉 0.94 s 分配 + 0.28 s 逐格循环）；
  `_nb_len` 改 `np.where(is_pole, cols, 8)`（与旧"逐行非负计数"逐位同值，堵死 ×15 复现路径）；3 处调用点透传；juvenile 文化循环改走 `world.neighbors(c)`。
- RNG 消费顺序不变（`valid_nb`/`prey_list` 顺序逐位同）。

## 三、验证

- `cargo check` 绿（5.12 s，仅历史 light_temp 警告）；`maturin develop --release` 重编安装成功。
- **C7 逐位对拍门**：`tools/self_audit.py digest` → **173 passed / 86.84 s**（16 个 digest 基线文件，含 `(574887, 11266.746993)` 断言）。
- 邻居/Rust 定向：**41 passed**（`test_sim_core` / `test_wave2b_t3` / `test_sphere_world` / `test_a4_perception_von_neumann`）。
- 全量回归（终态复跑）：**42 failed / 855 passed / 8 skipped**（329.52 s）。
  `[实测]` 42 例失败与开工基线**逐条相同**（全是既有 GBK 子进程解码环境问题，与本改动无关）；
  855 = 基线 852 + 3（T6 测试文件后补的 3 例）；收集数 905 与运行总数一致（已用 pre-T1 worktree 对照排除 T1 影响）。

## 四、附带修复：R204 的 2 处陈旧断言（**不是 T1 引入的**）

`[代码]` R204（`e623639`，12:58）把 `validate_gene_wiring` 的漂移条目从 `NAME` 改为 `NAME|KIND`
（`NAME_MISMATCH`/`VALUE_MISMATCH`/`COUNT_MISMATCH`，便于分辨"是否该重编 sim_core"），
**未同步 `tests/test_genes_registry.py`**；当时本机 `.so` 早于该提交（无 `|KIND`）⇒ 测试仍显绿。
我按 T1 要求重编 extension 后暴露 2 例失败（`test_drift_detected_when_py_value_changed`、`test_all_24_genes_are_validated`）。
`[实测]` 新契约自检：clean → `[]`；24 基因逐个篡改值全部检出；名字篡改 → `MOVEMENT_PROB|NAME_MISMATCH(rust=MOVE_PROB)=>REBUILD_SIM_CORE`；数量不符 → `COUNT_MISMATCH(rust=24, py=23)`。
⇒ 只改断言解析 `d[0].split("|")[0]`（3 行），不动被测行为；该文件 18 passed。
**注意**：R204 提交信息自述"本机无 cargo，未编译验证" ⇒ **凡改 Rust 源码的提交都应重编 + 跑 `test_genes_registry.py` 两例**，否则同类漂移会继续潜伏。

## 五、影响面（未改项，请知悉）

1. `experiments/a4_*.py` 三探针的 `e._nb_table = tbl` 现为**惰性行**（Python 路径本不读该表，走 `world.neighbors`；ReorderWorld 语义不变：极点带形状同、重排只作用于 8 邻）⇒ **不改**。
2. `tools/wave2_perception_probe.py` 打印措辞（"stride = max(8, cols)"）已过时、`experiments/nb_table_probe.py`（T1 立项探针）已过时 —— 二者是**历史证据工具**，**刻意不改**（不重写证据）；如需我给它们加"已过时"一行注释，请示下。
3. `sim_core/BUILD.md` 未含本机坑：`maturin develop --release` 在本机（venv 路径含中文）会因 pip 输出解码 GBK 失败，需 `PYTHONIOENCODING=utf-8`。属工程文档，我随时可补（一行）。
4. 内存解绑后 480×960 单 run ≈198 MB ⇒ **并行度 2→4 可开**（T4 的前置）。

## 六、下一步：T4（480×960 稳态 K）

按任务书口径：`k=2.5` / `gain=v_max` / `subdiv=80`；平台判据 = **末 3 个采样点相对变化 <3%**；K = 平台段中位数、**按 seed 分层**；报世代数 + 是否达平台；不做跨 k 比较；带进度条 + ETA。
我会先把**运行计划**（采样间隔 / tick 预算 / seed 数 / 并行度）一句话报板，随后开跑正式批次；若您对口径有别的指示，趁计划帖未发之前说最省事。
