"""诊断：为什么"ARS 惯性锁向"没有形成直线？（跑 30 tick，逐步打印）"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.stdout.reconfigure(encoding="utf-8")

from simulation.config import SimConfig  # noqa: E402
from simulation.sphere_engine import SphereEngine  # noqa: E402
from simulation.genes import Gene  # noqa: E402

c = SimConfig(seed=42)
c.simulation.use_sim_core = False
c.simulation.l2_dash = False
c.predation.enabled = False
c.resources.distribution = "patchy"
c.resources.bg_production_zero = True
c.resources.regrowth_rate = 0.0
c.population.initial_count = 20
o = c.organisms
o.max_energy = 600.0
o.initial_energy = 600.0
o.stomach_cap_mass = 25.0
o.photo_max = 0.0
o.maturity_fraction = 1.01
c.ars.enabled = True
c.ars.gain = 200.0
c.ars.giveup = 10 ** 9

e = SphereEngine(c)
P = len(e._flat)
e._energy[:P] = 600.0
e._stomach[:P] = 25.0
e._genes[:P, Gene.MOVE_PROB] = 1.0
e._genes[:P, Gene.ROOTING] = 0.0
e._heading[:P] = 4

print("感知半径 =", c.info_structure.perception_radius,
      "｜nb 长度示例 =", len(e.world.neighbors(int(e._flat[0]))))
print("_ars_cos[4] =", np.round(e._ars_cos[4], 3).tolist())
print("VN 槽位索引 =", e.world._VON_NEUMANN_IDX)
print()
prev = e._flat[:P].copy()
for t in range(1, 31):
    e.resources._grid[:] = 0.0
    before_dec = e._ars_dec_n
    e.step()
    cur = e._flat[: len(e._flat)]
    n = min(len(cur), P)
    deltas = []
    for k in range(min(3, n)):
        r0, c0 = divmod(int(prev[k]), 120)
        r1, c1 = divmod(int(cur[k]), 120)
        deltas.append(f"({r1-r0:+d},{(c1-c0+120)%120 if (c1-c0+120)%120 <= 60 else (c1-c0+120)%120-120:+d})")
    print(f"t={t:>2} 换格={int((cur[:P] != prev[:P]).sum())}/{P} "
          f"dec+={e._ars_dec_n-before_dec} heading前3={e._heading[:3].tolist()} "
          f"ext前3={e._ars_extensive[:3].tolist()} Δ前3={deltas} "
          f"cap_block={e._cap_blocked_n} cap_stay={e._cap_stay_n}")
    prev = cur[:P].copy()
