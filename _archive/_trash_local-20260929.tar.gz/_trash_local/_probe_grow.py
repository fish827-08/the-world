"""探针：哪些按个体数组在出生时**没有**同步扩容（temp，不入库）。"""
from __future__ import annotations

import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

sys.path.insert(0, ".")
from simulation.config import SimConfig          # noqa: E402
from simulation.sphere_engine import SphereEngine  # noqa: E402

NAMES = [
    "_id", "_flat", "_energy", "_stomach", "_stomach_scav", "_age", "_genes",
    "_out_taken", "_feed_fast", "_feed_slow", "_ars_extensive", "_heading",
    "_giveup_ct", "_sub_r", "_sub_c", "_health", "_valence", "_trust",
    "_work_memory", "_interpret", "_codebook", "_learning_count",
    "_fruit_charge", "_seed_carried", "_rs_children", "_emit_count",
]

cfg = SimConfig(seed=42)
cfg.world.rows = 60
cfg.world.cols = 120
cfg.population.initial_count = 100
cfg.resources.distribution = "patchy"
cfg.simulation.use_sim_core = True
cfg.organisms.maturity_fraction = 1e-6
e = SphereEngine(cfg)

print("t=0 lens:", {n: len(getattr(e, n)) for n in NAMES})
prev = None
for t in range(1, 61):
    e.step()
    cur = {n: len(getattr(e, n)) for n in NAMES}
    if cur != prev:
        bad = {n: v for n, v in cur.items() if v != cur["_id"]}
        print(f"tick {t}: alive={cur['_id']} next_id={e._next_id} "
              f"out_taken={cur['_out_taken']} mismatch={bad}")
        prev = cur
print("done, alive =", len(e._id), "next_id =", e._next_id)
