#!/usr/bin/env bash
# 静默窗口守望（本地运维件，不 commit）：等 S1 批跑收工 ⇒ 按 R219 §二-1 跑
#   ① floor_tax_probe 默认档 / ② --sparse 档（前后对照，静默机绝对数）
#   ③ sparse_lockstep_ab 配对锁步（N 绑定）
#   ④ 全量 pytest 账本
# 全程落盘 _trash_local/_quiet_window.log；到 09:00 未命中则放弃退出。
cd "C:/Users/圣羽/Desktop/temp/tempCode/the-world" || exit 9
LOG=_trash_local/_quiet_window.log
PY=.venv/Scripts/python.exe
echo "=== 守望启动 $(date '+%F %T') ===" >> "$LOG"

count_py() {
  powershell -NoProfile -Command "(Get-Process python* -ErrorAction SilentlyContinue).Count" 2>/dev/null | tr -d '\r \n'
}

quiet=0
while true; do
  hm=$((10#$(date +%H%M)))
  if [ "$hm" -ge 900 ]; then
    echo "[$(date '+%H:%M')] 到 09:00 仍未静默 ⇒ 放弃守望（绝对值择机另测）" >> "$LOG"; exit 0
  fi
  n=$(count_py)
  if [ -n "$n" ] && [ "$n" -le 3 ]; then quiet=$((quiet + 1)); else quiet=0; fi
  echo "[$(date '+%H:%M')] python 进程=$n 连续静默=$quiet" >> "$LOG"
  [ "$quiet" -ge 2 ] && break
  sleep 180
done

echo "=== 🟢 静默窗口命中 $(date '+%F %T')（python 进程=$n） ⇒ 开始复测 ===" >> "$LOG"

run() {
  tag="$1"; shift
  echo "" >> "$LOG"; echo "=== [$tag] 起 $(date '+%T') ===" >> "$LOG"
  PYTHONIOENCODING=utf-8 "$@" >> "$LOG" 2>&1
  rc=$?
  echo "=== [$tag] rc=$rc 止 $(date '+%T') ===" >> "$LOG"
}

run "A-默认档 floor_tax_probe" $PY experiments/floor_tax_probe.py
run "B-稀疏档 floor_tax_probe --sparse" $PY experiments/floor_tax_probe.py --sparse
run "C-配对锁步 pop=2500" $PY experiments/sparse_lockstep_ab.py --pop 2500 --ticks 60 --n-min 2000
run "D-全量测试账本" $PY -m pytest tests/ -q --ignore=tests/test_broker.py
echo "=== 守望完成 $(date '+%F %T') ===" >> "$LOG"
