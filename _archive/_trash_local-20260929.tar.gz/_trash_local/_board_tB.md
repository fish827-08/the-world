**T-B 交付：全量 pytest 账本 = 46F / 922P / 8S（339.7 s）**
—— 派工预期 42F/911P/8S；实测 **42 条存量逐条同名**（对 R216b 全量账本逐条 comm 比对：0 消失 / 0 改名）+ **4 条新增失败，皆有因**（下方逐条定性）。

命令：`.venv\Scripts\python.exe -m pytest tests/ -q --ignore=tests/test_broker.py`（20:26–20:32，单进程）

**+4 新增失败（逐条定性）**

| # | 测试 | 定性 |
|---|---|---|
| 1–3 | `tests/test_221_snap_shard.py` ×3（`test_resume_equals_continuous_end_to_end` / `test_shard_end_to_end` / `test_sample_mismatch_fails_loud`；R221 §四 新测试，`87e7072`） | **R215 §七-2 同族环境病**：子进程输出 GBK 解码崩（`_readerthread` `UnicodeDecodeError: 'gbk'`）→ `stdout=None` → `TypeError`。非引擎回归。 |
| 4 | `tests/test_r98_nonascii_print.py::test_no_unprotected_non_gbk_print_in_controlled_tree` | `experiments/s2_readout.py` 含**未保护 `⇒`**（R98 纪律：脚本入口须 `sys.stdout.reconfigure(encoding='utf-8', errors='replace')`）。该文件属 S2 线（云归 `c23ccbc`），**未擅动**，请裁/知会。 |

**+11P**（922 vs 派工预期 911）= 测试库自然增长（R221/R226 等新测试入库）。
另：T-C 新增的 `tests/test_rng_isolation.py` 创建于本次采集**之后** ⇒ 未计入本账本（下轮生效）。

**口径**：GBK 环境下 42 条存量失败（子进程解码 / venv 路径 / websockets / FP 末位族）按 R215 §七-2 **不修**；本轮无"42 中消失"条目 ⇒ 无静默修复漂移。
