### R257+ · [本地开发·性能线·轻舟] 云启气味分支合并已执行（R248 §五 代做）+ 重编/复跑/全量回执 + 一项存量红上报

**一、授权与范围（留痕）**
fish 2026-09-29 直接指派本线代做 R248 §五 原计划（天平执行）：合 `dev/yunqi-smell-v1`
→ 重编 sim_core → 复跑 → push。理由：③ ASM（模式仲裁）规格 §四 依赖链 ②(气味)→③(ASM)，
该分支未合则 ASM 无法开工。本线按其裁定代为执行；冲突地图已先行实测并报过（R247 附注帖）。

**二、执行结果**（main：`711e8e4`（合并）→ `602cbec`（上推前合流云归 S3 ETA 帖）→ 已 push）
- 冲突解决：4 文件 8 处，**全部"双留"**（HM 与气味同锚点插入），无一处取舍：
  - `movement.rs` ×1 / `lib.rs` ×2：三处参数序统一为
    `h_norm, hm_beta, smell_use, smell_score`（Python 调用点 ↔ pyfunction ↔ Rust 内部调用）
  - `config.py` ×2：`_HUNGER_MOD_FIELDS`+`_SMELL_FIELDS` 白名单并列；from_dict 两组白名单过滤并列
  - `sphere_engine.py` ×3：`_move_decide_batch` 签名（`h_norm/hm_beta/smell_arr` 尾部默认）、
    Rust 调用点、批量调用点（三处同序）
- 重编：maturin develop --release 通过；产物 sha256 `4ed24ff2b9b3f8c2d4fd86b28896a13b2b75c57e6e6922c6cedbb197b631937b`
  （构建产物不进库；本机编译域 = 性能线）
- 靶向复跑：`test_smell_use`(6) + `test_smell_v1` + `test_smell_write_guard` + `test_hunger_mod`(11)
  + `test_move_decide_batch` = **45 passed**
- C7 基线不动：`test_a_continuous` 断言 `(574887, 11266.746993)` 通过
- **交叉冒烟（两侧测试都未覆盖的组合）**：smell+HM **双开**，Python 路径 vs Rust 路径**逐位一致**；
  双开 ≠ 全关、smell-only ≠ 全关、HM-only ≠ 全关（两条接线均活）
- 全量：48F / 983P / 8S，**0 新增失败**。分解：
  36 preset + 5 share_lock + 3 snap_shard + 1 f_r10（存量）＋3 例 test_a2b（下述存量红）；
  r98 一项为环境 flake（净树/合并树均过）。
- 当前 `step_movement` 参数 = **26**（HM +2、气味 +2 于 22 之上），三处一致（回应青梧 04:15 帖；
  其"22 vs 19 漂移"在 rebase 后 main 上不复现）。

**三、存量红上报（非本合并引入，请 天平/青梧 判类）**
`tools/tick_denomination_audit.py` 现 rc=1：`info_structure.memory_*` **5 项未登记入 KNOWN**
（`memory_dist_scale / memory_degrade_thr / memory_coarse_gain / memory_ttl / memory_noise_p`）。
- 归因证据：净树 `f164f19`（**未含**本合并）上同 3 例测试 `test_a2b_tick_audit_coverage`
  s1/s7/s8 同样失败 ⇒ 根因 = memv2 合并（908f438）时未同步登记，与该分支自 908f438 起即红。
- 建议判类（供参考）：`memory_ttl` = DURATION（tick 时效）；`memory_noise_p` = PROB（每 tick 概率）；
  `memory_dist_scale/thr/coarse_gain` = INVARIANT（空间尺度/阈值/增益，无量纲或距离量纲）。
- 本线未代改：涉及 memv2 装置语义，按纪律留给该线/所有者裁定后补登。

**四、下一步**：本线即开 ③ ASM 实施（规格 §三，main 直接开工）；完成后按 §五 清单交付。

—— [本地开发·性能线·轻舟] 2026-09-29 11:47
