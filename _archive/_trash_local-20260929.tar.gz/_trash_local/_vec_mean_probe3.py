import sys, time
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import numpy as np
rng = np.random.default_rng(11)

def seq_sum(a):
    out = np.zeros(a.shape[1], dtype=np.float64)
    for r in range(a.shape[0]):
        out = out + a[r]
    return out

# 候选 A：np.add.at（无缓冲，按索引出现顺序累加）
# 候选 B：按 rank 分块循环（每 rank 一步，掩码向量化）
def cand_A(interp, seg_id, adult, n_seg, first_pos, counts):
    acc = np.zeros((n_seg, 16))
    np.add.at(acc, seg_id, interp[adult])
    return acc / counts[:, None]

def cand_A2(interp, seg_id, adult, n_seg, first_pos, counts):
    acc = interp[adult[first_pos]].copy()
    rest = np.ones(len(adult), bool); rest[first_pos] = False
    np.add.at(acc, seg_id[rest], interp[adult[rest]])
    return acc / counts[:, None]

def cand_B(interp, seg_id, adult, n_seg, first_pos, counts, maxk):
    acc = interp[adult[first_pos]].copy()
    for r in range(1, maxk):
        m = counts > r
        if not m.any():
            break
        acc[m] += interp[adult[first_pos[m] + r]]
    return acc / counts[:, None]

# 真实性检查：与逐段 mean 逐位一致
for trial in range(30):
    n_seg = int(rng.integers(5, 60))
    counts = np.maximum(1, rng.lognormal(2.0, 0.8, size=n_seg).astype(np.int64))
    tot = int(counts.sum())
    adult = np.arange(tot)
    seg_id = np.repeat(np.arange(n_seg), counts)
    interp = (rng.standard_normal((tot, 16)) * 10.0 ** rng.integers(-20, 20, size=(tot, 16)))
    first_pos = np.concatenate(([0], np.cumsum(counts)[:-1]))
    maxk = int(counts.max())
    ref = np.stack([interp[first_pos[i]:first_pos[i]+counts[i]].mean(axis=0) for i in range(n_seg)])
    for name, got in (("A", cand_A(interp, seg_id, adult, n_seg, first_pos, counts)),
                      ("A2", cand_A2(interp, seg_id, adult, n_seg, first_pos, counts)),
                      ("B", cand_B(interp, seg_id, adult, n_seg, first_pos, counts, maxk))):
        if got.tobytes() != ref.tobytes():
            print(f"  ✗ trial={trial} 候选{name} 有位差；列差数={(got.view(np.int64)!=ref.view(np.int64)).sum()}")
print("位级一致性检查完成（无 ✗ 即全对）")

# 性能：S=800 段，mean count≈12，max≈120，共约 1 万对
n_seg = 800
counts = np.maximum(1, rng.lognormal(2.4, 0.9, size=n_seg).astype(np.int64))
tot = int(counts.sum())
seg_id = np.repeat(np.arange(n_seg), counts)
adult = np.arange(tot)
interp = rng.standard_normal((tot, 16))
first_pos = np.concatenate(([0], np.cumsum(counts)[:-1]))
maxk = int(counts.max())
print(f"规模：S={n_seg} 总对={tot} maxK={maxk}")

def bench(fn, n=200):
    t0 = time.perf_counter()
    for _ in range(n):
        fn()
    return (time.perf_counter() - t0) / n * 1e3

print(f"  A  np.add.at 全量      : {bench(lambda: cand_A(interp, seg_id, adult, n_seg, first_pos, counts)):.3f} ms")
print(f"  A2 np.add.at 仅余项    : {bench(lambda: cand_A2(interp, seg_id, adult, n_seg, first_pos, counts)):.3f} ms")
print(f"  B  rank 分块循环       : {bench(lambda: cand_B(interp, seg_id, adult, n_seg, first_pos, counts, maxk)):.3f} ms")
# 参考：原始逐段 mean 循环
def ref_loop():
    out = np.empty((n_seg, 16))
    for i in range(n_seg):
        out[i] = interp[first_pos[i]:first_pos[i]+counts[i]].mean(axis=0)
    return out
print(f"  原 逐段 mean 循环      : {bench(ref_loop):.3f} ms")
