"""只读扫描 the-world-data 数据仓（不修改任何文件）。"""
import os
import time
from collections import defaultdict
from pathlib import Path

ROOT = Path(r"C:\Users\圣羽\Desktop\temp\tempCode\the-world\the-world-data")


def human(n: int) -> str:
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f}{u}"
        n /= 1024
    return f"{n:.1f}TB"


def scan(root: Path, skip_git: bool = True):
    per_dir: dict[str, list[int]] = defaultdict(lambda: [0, 0])   # [bytes, files]
    per_ext: dict[str, list[int]] = defaultdict(lambda: [0, 0])
    biggest: list[tuple[int, str, float]] = []
    per_year: dict[str, list[int]] = defaultdict(lambda: [0, 0])
    total = [0, 0]
    for dirpath, dirnames, filenames in os.walk(root):
        if skip_git and ".git" in dirnames:
            dirnames.remove(".git")
        rel_dir = os.path.relpath(dirpath, root)
        for fn in filenames:
            p = Path(dirpath) / fn
            try:
                st = p.stat()
            except OSError:
                continue
            sz, mt = st.st_size, st.st_mtime
            total[0] += sz
            total[1] += 1
            # 目录：取前两段（experiments/<name>）
            parts = rel_dir.replace("\\", "/").split("/")
            key = "/".join(parts[:2]) if len(parts) >= 2 else parts[0]
            per_dir[key][0] += sz
            per_dir[key][1] += 1
            ext = p.suffix.lower() or "(无扩展名)"
            per_ext[ext][0] += sz
            per_ext[ext][1] += 1
            ym = time.strftime("%Y-%m", time.localtime(mt))
            per_year[ym][0] += sz
            per_year[ym][1] += 1
            biggest.append((sz, str(p.relative_to(root)), mt))
    return total, per_dir, per_ext, per_year, biggest


total, per_dir, per_ext, per_year, biggest = scan(ROOT)

print(f"=== 数据仓总体：{human(total[0])} / {total[1]} 文件（不含 .git）===\n")

print("### 按顶层/实验目录（前 25）")
rows = sorted(per_dir.items(), key=lambda kv: -kv[1][0])[:25]
print(f"{'目录':<58}{'体积':>10}{'文件数':>9}")
for k, (b, n) in rows:
    print(f"{k:<58}{human(b):>10}{n:>9}")

print("\n### 按扩展名")
rows = sorted(per_ext.items(), key=lambda kv: -kv[1][0])
print(f"{'类型':<14}{'体积':>10}{'文件数':>9}")
for k, (b, n) in rows:
    print(f"{k:<14}{human(b):>10}{n:>9}")

print("\n### 按最后修改月份")
rows = sorted(per_year.items(), key=lambda kv: kv[0])
print(f"{'月份':<12}{'体积':>10}{'文件数':>9}")
for k, (b, n) in rows:
    print(f"{k:<12}{human(b):>10}{n:>9}")

print("\n### 最大的 15 个文件")
for sz, name, mt in sorted(biggest, reverse=True)[:15]:
    print(f"  {human(sz):>9}  {time.strftime('%Y-%m-%d', time.localtime(mt))}  {name}")
