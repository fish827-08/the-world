"""长程轨迹诊断：赤道带个体"直线走"为什么会漂移？"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.stdout.reconfigure(encoding="utf-8")

from simulation.config import SimConfig  # noqa: E402
from simulation.sphere_engine import SphereEngine  # noqa: E402
from simulation.genes import Gene  # noqa: E402

c = SimConfig(seed=42)
c.simulation.use_sim_core = False
c.simulation.l2_dash = False
c.predation.enabled = False
c.resources.distribution = "patchy"
c.resources.bg_production_zero = True
c.resources.regrowth_rate = 0.0
c.population.initial_count = 20
o = c.organisms
o.max_energy = 600.0
o.initial_energy = 600.0
o.stomach_cap_mass = 25.0
o.photo_max = 0.0
o.maturity_fraction = 1.01
c.ars.enabled = True
c.ars.gain = 200.0
c.ars.giveup = 10 ** 9

e = SphereEngine(c)
P = len(e._flat)
e._energy[:P] = 600.0
e._stomach[:P] = 25.0
e._genes[:P, Gene.MOVE_PROB] = 1.0
e._genes[:P, Gene.ROOTING] = 0.0
e._heading[:P] = 4

# 只留赤道带个体（行 20-39）
rows0 = e._flat[:P] // 120
keep = e._id[:P][(rows0 >= 20) & (rows0 < 40)]
ids = set(int(x) for x in keep[:6])
print("跟踪 id:", sorted(ids))
pos = {int(e._id[k]): int(e._flat[k]) for k in range(P) if int(e._id[k]) in ids}

for t in range(1, 301):
    e.resources._grid[:] = 0.0
    e.step()
    cur = {int(e._id[k]): int(e._flat[k]) for k in range(len(e._flat))}
    if t % 25 == 0:
        bits = []
        for i in sorted(ids):
            if i in cur:
                r, cc = divmod(cur[i], 120)
                bits.append(f"id{i}:r{r},c{cc},h{e._heading[list(e._id[:len(e._flat)]).index(i)]},"
                            f"E{e._energy[list(e._id[:len(e._flat)]).index(i)]:.0f}")
        print(f"t={t:>3} " + " | ".join(bits))
