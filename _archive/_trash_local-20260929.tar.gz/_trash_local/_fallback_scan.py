"""临时清点：全仓 `getattr(obj, "field", 字面量)` 兜底 vs config 默认值（R208 §三 纪律测量）。

只做测量，不进仓。输出：命中数 / 与 config 默认不一致 / 字段歧义 / 不在 config。
"""
from __future__ import annotations

import ast
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "simulation" / "config.py"
SCAN_DIRS = ["simulation", "world"]


def lit(node):
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub) and isinstance(node.operand, ast.Constant):
        v = node.operand.value
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            return -v
    return _MISS


_MISS = object()


def config_defaults():
    tree = ast.parse(CONFIG.read_text(encoding="utf-8"))
    out: dict[str, list[tuple[str, object]]] = {}
    for cls in [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]:
        for stmt in cls.body:
            if isinstance(stmt, ast.AnnAssign):
                tgt, val = stmt.target, stmt.value
                if isinstance(tgt, ast.Name) and val is not None:
                    v = lit(val)
                    if v is not _MISS:
                        out.setdefault(tgt.id, []).append((cls.name, v))
    return out


def main() -> None:
    cfgdef = config_defaults()
    hits, mism, ambig, unknown, none_skipped = [], [], [], [], 0
    for d in SCAN_DIRS:
        for p in sorted((ROOT / d).rglob("*.py")):
            if p.name == "config.py":
                continue
            tree = ast.parse(p.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if not (isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                        and node.func.id == "getattr" and len(node.args) == 3):
                    continue
                name_node, def_node = node.args[1], node.args[2]
                if not isinstance(name_node, ast.Constant) or not isinstance(name_node.value, str):
                    continue
                default = lit(def_node)
                if default is _MISS:
                    continue
                field = name_node.value
                rel = f"{p.relative_to(ROOT)}:{node.lineno}"
                if default is None:
                    none_skipped += 1
                    continue
                hits.append((rel, field, default))
                found = cfgdef.get(field)
                if not found:
                    unknown.append((rel, field, default))
                elif len({v for _, v in found}) > 1:
                    ambig.append((rel, field, default, found))
                elif found[0][1] != default:
                    mism.append((rel, field, default, found[0]))

    print(f"命中（字面量兜底，非 None）：{len(hits)}｜None 跳过：{none_skipped}")
    print(f"❗ 与 config 唯一默认不一致：{len(mism)}")
    for rel, field, default, (cls, cfgv) in mism:
        print(f"   {rel}  {field}: 兜底 {default!r} vs {cls}.{field} = {cfgv!r}")
    print(f"⚠️ 字段歧义（同名多默认）：{len(ambig)}")
    seen = set()
    for rel, field, default, found in ambig:
        if field in seen:
            continue
        seen.add(field)
        print(f"   {field}: 兜底 {default!r}｜候选 {found}")
    print(f"❔ 不在 config：{len(unknown)}")
    for rel, field, default in unknown[:25]:
        print(f"   {rel}  {field}={default!r}")


if __name__ == "__main__":
    main()
