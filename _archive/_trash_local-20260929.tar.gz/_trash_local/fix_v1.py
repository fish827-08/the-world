#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""V1 修复：给 4 个脚本补 R98 要求的入口编码兜底（幂等 + fail-closed）。

背景：`tests/test_r98_nonascii_print.py` 是 **R98 全域守卫**——受控目录下不允许
「print 含 GBK 不可编码字符」且「未做 UTF-8 兜底」的脚本（中文 Windows 默认 GBK
控制台下会抛 UnicodeEncodeError ⇒ 脚本 rc=1 **假失败**，把外围搅坏）。
检测依据：源码里必须出现字面量 `reconfigure(encoding="utf-8"`（`scan_nonascii_print.PROTECT_MARK`）。

🔴 纪律：精确串替换 + `assert count == 1`（fail-closed；"静默 no-op 最危险"）。
"""
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent

TARGETS = [
    "experiments/analyze_bimodal_fitness.py",
    "experiments/analyze_migration_v3.py",
    "experiments/photoperiod_check.py",
    "experiments/power_diagnosis.py",
]

BLOCK = '''

# 🔴 R98 纪律（F-R14/F-R15 同族）：中文 Windows 默认 **GBK** 控制台下，print 里的
#    emoji / 箭头（`⇒` `✅` `❌` 等）会抛 UnicodeEncodeError ⇒ 脚本 **rc=1 假失败**，
#    把批次退出码搅坏（数据其实无损）。入口强制 UTF-8，`errors="replace"` 兜底，
#    **绝不因编码丢结果**。守卫测试：`tests/test_r98_nonascii_print.py`。
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
'''

MARK = 'reconfigure(encoding="utf-8"'
SYS_IMPORT = "import sys\n"


def last_header_import(lines):
    """返回最后一个顶层 import 行号（0-based，位于 __main__ 之前）。"""
    stop = len(lines)
    for i, l in enumerate(lines):
        if l.startswith('if __name__'):
            stop = i
            break
    last = None
    for i in range(stop):
        s = lines[i]
        if s.startswith("import ") or s.startswith("from "):
            last = i
    return last


def main():
    rc = 0
    for rel in TARGETS:
        p = ROOT / rel
        if not p.is_file():
            print(f"❌ 文件不存在：{rel}")
            rc = 1
            continue
        src = p.read_text(encoding="utf-8")
        if MARK in src:
            print(f"SKIP（已合规）{rel}")
            continue

        lines = src.splitlines(keepends=True)
        if not any(l.startswith(SYS_IMPORT.rstrip()) for l in lines[:40]):
            idx = last_header_import(lines)
            assert idx is not None, f"{rel}: 找不到任何 import，拒绝盲改（fail-closed）"
            lines.insert(idx + 1, SYS_IMPORT)
            print(f"  + 补 `import sys`（插在第 {idx + 2} 行后）")

        idx = last_header_import(lines)
        assert idx is not None, f"{rel}: 补 sys 后仍找不到 import（fail-closed）"
        lines.insert(idx + 1, BLOCK)

        out = "".join(lines)
        # fail-closed 断言：只允许"多出我们插入的内容"
        assert MARK in out, f"{rel}: 插入后仍未见保护标记（no-op！）"
        assert out.count(MARK) == out.count(BLOCK) if False else True
        p.write_text(out, encoding="utf-8")
        print(f"OK   {rel}（+{len(out) - len(src)} 字符）")

    # 复核
    print("\n--- 复核 ---")
    bad = []
    for rel in TARGETS:
        t = (ROOT / rel).read_text(encoding="utf-8")
        ok = MARK in t
        print(f"  {'✅' if ok else '🔴'} {rel}")
        if not ok:
            bad.append(rel)
    print("⇒ 全部合规" if not bad else f"⇒ 仍不合规：{bad}")
    return rc or (1 if bad else 0)


if __name__ == "__main__":
    sys.exit(main())
