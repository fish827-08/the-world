# tick 面额清点（P0.0 / A2）

- 扫描覆盖：共 11 个文件 ｜ simulation/ 5 个（genes.py, oracle.py, provenance.py, sphere_engine.py, tick.py） ｜ world/ 6 个（light_and_temperature.py, resource_dynamics.py, resource_field.py, signal_field.py, sphere_world.py, subpos.py）
- config 未分类：0；交叉校验不一致：0

## config 字段

| 字段 | 默认值 | 类 | 依据 |
|---|---|---|---|
| `pleasure.arousal_decay` | `0.97` | DECAY | 白名单（人工确认过的分类表） |
| `pleasure.valence_decay` | `0.95` | DECAY | 白名单（人工确认过的分类表） |
| `ars.fast_tau` | `50.0` | DURATION | 白名单（人工确认过的分类表） |
| `ars.giveup` | `20` | DURATION | 白名单（人工确认过的分类表） |
| `ars.slow_tau` | `500.0` | DURATION | 白名单（人工确认过的分类表） |
| `corpse_wound.corpse_decay_ticks` | `600` | DURATION | 白名单（人工确认过的分类表） |
| `info_structure.learning_maturity_ticks` | `1200` | DURATION | 白名单（人工确认过的分类表） |
| `info_structure.softmax_tau` | `0.15` | DURATION | 字段名以 `tau` 结尾 ⇒ 时间常数（tick） |
| `light.rotation_period` | `2400` | DURATION | 白名单（人工确认过的分类表） |
| `light.season_period` | `0` | DURATION | 字段名含 `period` ⇒ 周期（tick 数） |
| `oracle.persistence` | `10` | DURATION | 白名单（人工确认过的分类表） |
| `organisms.repro_cooldown_gene_scale` | `60.0` | DURATION | 白名单（人工确认过的分类表） |
| `resource_dynamics.dead_regen_ticks` | `2000` | DURATION | 白名单（人工确认过的分类表） |
| `resource_dynamics.rest_ticks` | `60` | DURATION | 白名单（人工确认过的分类表） |
| `signals.duration_ticks` | `50` | DURATION | 白名单（人工确认过的分类表） |
| `ars.gain` | `1.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `ars.kappa` | `0.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `ars.lat_exempt_deg` | `85.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `ars.theta` | `0.5` | INVARIANT | 白名单（人工确认过的分类表） |
| `corpse_wound.corpse_cap_per_cell` | `200` | INVARIANT | 白名单（人工确认过的分类表） |
| `corpse_wound.corpse_energy_frac` | `0.9` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `corpse_wound.corpse_patch_boost` | `0.5` | INVARIANT | 白名单（人工确认过的分类表） |
| `corpse_wound.corpse_to_plant_frac` | `0.5` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `corpse_wound.escalation_gap` | `0.25` | INVARIANT | 白名单（人工确认过的分类表） |
| `corpse_wound.holder_adv` | `1.2` | INVARIANT | 白名单（人工确认过的分类表） |
| `corpse_wound.need_aggression_k` | `0.5` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `corpse_wound.scav_gate` | `0.5` | INVARIANT | 白名单（人工确认过的分类表） |
| `corpse_wound.scav_s` | `2.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `corpse_wound.w_fear_health` | `0.5` | INVARIANT | 白名单（人工确认过的分类表） |
| `corpse_wound.wound_base` | `0.35` | INVARIANT | 白名单（人工确认过的分类表） |
| `corpse_wound.wound_fear_threshold` | `0.3` | INVARIANT | 白名单（人工确认过的分类表） |
| `culture.food_threshold` | `0.3` | INVARIANT | 白名单（人工确认过的分类表） |
| `culture.trust_false` | `0.1` | INVARIANT | 白名单（人工确认过的分类表） |
| `culture.trust_true` | `0.05` | INVARIANT | 白名单（人工确认过的分类表） |
| `fruit.digest_ratio` | `0.7` | INVARIANT | 白名单（人工确认过的分类表） |
| `fruit.fruit_ratio` | `0.8` | INVARIANT | 白名单（人工确认过的分类表） |
| `fruit.fruit_threshold` | `10.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `fruit.plant_threshold` | `0.5` | INVARIANT | 白名单（人工确认过的分类表） |
| `genome.gene_count` | `24` | INVARIANT | 计数 ⇒ 不变 |
| `genome.gene_max` | `1.0` | INVARIANT | 上下限 ⇒ 量，不变 |
| `genome.gene_min` | `0.0` | INVARIANT | 上下限 ⇒ 量，不变 |
| `genome.mutation_sigma` | `0.05` | INVARIANT | 白名单（人工确认过的分类表） |
| `info_structure.alignment_noise` | `0.02` | INVARIANT | 白名单（人工确认过的分类表） |
| `info_structure.alignment_step` | `0.15` | INVARIANT | 白名单（人工确认过的分类表） |
| `info_structure.learning_samples_max` | `60` | INVARIANT | 上下限 ⇒ 量，不变 |
| `info_structure.memory_gradient_gain` | `0.3` | INVARIANT | 白名单（人工确认过的分类表） |
| `info_structure.perception_noise` | `0.05` | INVARIANT | 白名单（人工确认过的分类表） |
| `info_structure.perception_radius` | `4` | INVARIANT | 白名单（人工确认过的分类表） |
| `info_structure.reputation_weight` | `0.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `light.day_boost` | `6.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `light.lat_base_ref` | `1.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `light.t_equator` | `30.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `light.t_pole` | `-20.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `light.tilt_rad` | `0.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `migration.gain` | `50.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `migration.min_abs_anomaly` | `0.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `oracle.donation` | `0.05` | INVARIANT | 白名单（人工确认过的分类表） |
| `oracle.gain_multiplier` | `1.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `organisms.assim_carn` | `1.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `organisms.assim_herb` | `1.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `organisms.assim_return_frac` | `1.0` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `organisms.dash_cost_exp` | `2.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `organisms.dash_cost_kappa` | `1.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `organisms.dash_min_energy_frac` | `0.2` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `organisms.eat_efficiency` | `3.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `organisms.eat_threshold_frac` | `0.0` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `organisms.exhaust_frac` | `0.0` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `organisms.far_cap` | `32` | INVARIANT | 白名单（人工确认过的分类表） |
| `organisms.growth_mult` | `1.6` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `organisms.initial_energy` | `60.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `organisms.lifespan_mult` | `1.0` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `organisms.maturity_fraction` | `0.15` | INVARIANT | 白名单（人工确认过的分类表） |
| `organisms.max_energy` | `300.0` | INVARIANT | 上下限 ⇒ 量，不变 |
| `organisms.old_mob_mult` | `0.55` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `organisms.senile_fraction` | `0.75` | INVARIANT | 白名单（人工确认过的分类表） |
| `organisms.senile_mult` | `1.4` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `organisms.starve_frac` | `0.0` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `organisms.stomach_cap_mass` | `0.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `organisms.young_mob_mult` | `0.55` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `pleasure.alone_rpe` | `-0.1` | INVARIANT | 白名单（人工确认过的分类表） |
| `pleasure.expectation_size` | `120` | INVARIANT | 计数 / 数组宽度 ⇒ 不变 |
| `pleasure.inheritance_noise` | `0.02` | INVARIANT | 白名单（人工确认过的分类表） |
| `pleasure.max_reward` | `2.0` | INVARIANT | 上下限 ⇒ 量，不变 |
| `pleasure.optimism` | `0.8` | INVARIANT | 白名单（人工确认过的分类表） |
| `pleasure.social_rpe` | `0.2` | INVARIANT | 白名单（人工确认过的分类表） |
| `pleasure.w_energy` | `0.5` | INVARIANT | 白名单（人工确认过的分类表） |
| `pleasure.w_info` | `0.3` | INVARIANT | 白名单（人工确认过的分类表） |
| `pleasure.w_social` | `0.2` | INVARIANT | 白名单（人工确认过的分类表） |
| `population.init_patch_frac` | `0.0` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `population.initial_count` | `200` | INVARIANT | 计数 ⇒ 不变 |
| `population.max_count` | `5000` | INVARIANT | 上下限 ⇒ 量，不变 |
| `population.soft_cap_target` | `0.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `predation.attack_gene_gate` | `0.3` | INVARIANT | 白名单（人工确认过的分类表） |
| `predation.forage_tradeoff_k` | `0.0` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `predation.stomach_transfer` | `0.4` | INVARIANT | 白名单（人工确认过的分类表） |
| `predation.success_ceil` | `0.9` | INVARIANT | 白名单（人工确认过的分类表） |
| `predation.success_floor` | `0.1` | INVARIANT | 白名单（人工确认过的分类表） |
| `predation.success_gene_gain` | `0.5` | INVARIANT | 白名单（人工确认过的分类表） |
| `predation.transfer_ratio` | `0.4` | INVARIANT | 白名单（人工确认过的分类表） |
| `resource_dynamics.damage_recovery` | `0.5` | INVARIANT | 白名单（人工确认过的分类表） |
| `resource_dynamics.dead_cell_max_frac` | `0.5` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `resource_dynamics.death_threshold` | `0.8` | INVARIANT | 白名单（人工确认过的分类表） |
| `resource_dynamics.kill_frac` | `10.0` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `resource_dynamics.rest_threshold` | `0.3` | INVARIANT | 白名单（人工确认过的分类表） |
| `resources.background_fill` | `0.1` | INVARIANT | 白名单（人工确认过的分类表） |
| `resources.capacity_per_area` | `40.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `resources.initial_fill` | `0.5` | INVARIANT | 白名单（人工确认过的分类表） |
| `resources.light_sensitivity` | `0.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `resources.patch_capacity_mult` | `3.0` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `resources.patch_count` | `30` | INVARIANT | 计数 ⇒ 不变 |
| `resources.patch_radius` | `2` | INVARIANT | 计数 ⇒ 不变 |
| `resources.patch_regrowth_mult` | `3.0` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `resources.temp_sensitivity` | `1.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `simulation.attack_range` | `1` | INVARIANT | 白名单（人工确认过的分类表） |
| `simulation.cell_occupancy_cap` | `3` | INVARIANT | 白名单（人工确认过的分类表） |
| `simulation.history_limit` | `0` | INVARIANT | 白名单（人工确认过的分类表） |
| `simulation.perception_cap` | `32` | INVARIANT | 白名单（人工确认过的分类表） |
| `simulation.perception_span` | `1` | INVARIANT | 白名单（人工确认过的分类表） |
| `simulation.social_move_weight` | `1.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `simulation.w_fear` | `0.5` | INVARIANT | 白名单（人工确认过的分类表） |
| `simulation.w_seek_max` | `0.5` | INVARIANT | 上下限 ⇒ 量，不变 |
| `subpos.lat_floor` | `0.3` | INVARIANT | 白名单（人工确认过的分类表） |
| `subpos.min_energy_frac` | `0.05` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `subpos.speed_gain` | `4.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `subpos.speed_max` | `2.0` | INVARIANT | 上下限 ⇒ 量，不变 |
| `subpos.stay_base` | `0.0` | INVARIANT | 白名单（人工确认过的分类表） |
| `subpos.stay_fear_k` | `0.0` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `subpos.stay_food_k` | `0.0` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `subpos.stay_max` | `0.8` | INVARIANT | 上下限 ⇒ 量，不变 |
| `subpos.stay_signal_k` | `0.0` | INVARIANT | 比例 / 系数 ⇒ 无量纲，不变 |
| `subpos.subdiv` | `4` | INVARIANT | 计数 / 数组宽度 ⇒ 不变 |
| `world.cols` | `120` | INVARIANT | 白名单（人工确认过的分类表） |
| `world.rows` | `60` | INVARIANT | 白名单（人工确认过的分类表） |
| `corpse_wound.contest_cost_energy` | `0.5` | PER_EVENT | 白名单（人工确认过的分类表） |
| `organisms.move_cost` | `0.4` | PER_EVENT | 白名单（人工确认过的分类表） |
| `predation.attack_cost` | `0.1` | PER_EVENT | 白名单（人工确认过的分类表） |
| `fruit.excretion_prob` | `0.1` | PROB | 白名单（人工确认过的分类表） |
| `fruit.germination_prob` | `0.5` | PROB | 白名单（人工确认过的分类表） |
| `fruit.seed_intake_prob` | `0.3` | PROB | 白名单（人工确认过的分类表） |
| `info_structure.codebook_mutation_rate` | `0.02` | PROB | 白名单（人工确认过的分类表） |
| `pleasure.baseline_rate` | `0.001` | PROB | 白名单（人工确认过的分类表） |
| `predation.attack_prob_coef` | `0.2` | PROB | 白名单（人工确认过的分类表） |
| `simulation.stay_prob` | `0.0` | PROB | 字段名含 `prob` ⇒ 每 tick 概率（独立试次） |
| `corpse_wound.wound_heal_energy_cost` | `0.05` | RATE | 白名单（人工确认过的分类表） |
| `corpse_wound.wound_heal_rate` | `0.001` | RATE | 白名单（人工确认过的分类表） |
| `fruit.charge_rate` | `0.1` | RATE | 白名单（人工确认过的分类表） |
| `fruit.eat_rate` | `0.05` | RATE | 白名单（人工确认过的分类表） |
| `genome.mutation_rate` | `0.05` | RATE | 字段名以 `rate` 结尾 ⇒ 每 tick 速率 |
| `info_structure.alignment_rate` | `0.1` | RATE | 白名单（人工确认过的分类表） |
| `info_structure.learning_rate` | `0.15` | RATE | 白名单（人工确认过的分类表） |
| `organisms.base_metabolism` | `0.6` | RATE | 白名单（人工确认过的分类表） |
| `organisms.eat_amount` | `0.9` | RATE | 白名单（人工确认过的分类表） |
| `organisms.homeo_upkeep` | `0.15` | RATE | 白名单（人工确认过的分类表） |
| `organisms.photo_max` | `0.1` | RATE | 白名单（人工确认过的分类表） |
| `pleasure.alpha` | `0.05` | RATE | 白名单（人工确认过的分类表） |
| `resources.regrowth_rate` | `0.5` | RATE | 白名单（人工确认过的分类表） |
| `simulation.ticks` | `1000` | RUNTIME | 白名单（人工确认过的分类表） |
| `fruit.max_seed_carried` | `5` | UNWIRED | **引擎/世界中从未出现** ⇒ 不承载 tick 面额（不参与重标） |
| `fruit.seed_energy` | `5.0` | UNWIRED | **引擎/世界中从未出现** ⇒ 不承载 tick 面额（不参与重标） |
| `info_structure.codebook_mutation_sigma` | `0.3` | UNWIRED | **引擎/世界中从未出现** ⇒ 不承载 tick 面额（不参与重标） |
| `organisms.niche_floor` | `0.4` | UNWIRED | **引擎/世界中从未出现** ⇒ 不承载 tick 面额（不参与重标） |
| `organisms.niche_gain` | `0.6` | UNWIRED | **引擎/世界中从未出现** ⇒ 不承载 tick 面额（不参与重标） |

## 字面量线索区（净剩 261 / 总扫 1186）

| 文件:行 | 值 | 建议类 | 上下文 |
|---|---|---|---|
| `simulation/genes.py:38` | `0` | PROB | `MOVE_PROB = 0            # 移动概率（被 g19 植物化缩放）` |
| `simulation/genes.py:41` | `3` | UNCLASSIFIED | `LIFE_GENE = 3            # 寿命基因（影响 lifespan 派生）` |
| `simulation/genes.py:42` | `4` | UNCLASSIFIED | `EAT_AMOUNT = 4           # 进食量` |
| `simulation/genes.py:43` | `5` | UNCLASSIFIED | `STOMACH_CAP = 5          # 胃容量` |
| `simulation/genes.py:44` | `6` | RATE | `MOVE_COST = 6            # 移动能耗` |
| `simulation/genes.py:45` | `7` | UNCLASSIFIED | `PARENTAL_INVEST = 7      # 传代投入（分给子代的能量比例）` |
| `simulation/genes.py:46` | `8` | UNCLASSIFIED | `PHOTOSYNTHESIS = 8       # 光合产能` |
| `simulation/genes.py:47` | `9` | UNCLASSIFIED | `HOMEOTHERM = 9           # 恒温性` |
| `simulation/genes.py:48` | `10` | UNCLASSIFIED | `FORAGE_NEIGHBOR = 10     # 邻格觅食倾向` |
| `simulation/genes.py:49` | `11` | UNCLASSIFIED | `TEMP_PREF = 11           # 温度偏好` |
| `simulation/genes.py:50` | `12` | DURATION | `REPRO_COOLDOWN = 12      # 繁殖冷却长度` |
| `simulation/genes.py:51` | `13` | UNCLASSIFIED | `SOCIABILITY = 13         # 群居性（移动决策 soc 项，Rust movement 消费）` |
| `simulation/genes.py:52` | `14` | UNCLASSIFIED | `PERCEPTION = 14          # 感知半径（移动决策 perc 项，Rust movement 消费）` |
| `simulation/genes.py:53` | `15` | UNCLASSIFIED | `SIGNAL_STRENGTH = 15     # 信号发射概率（L3）` |
| `simulation/genes.py:54` | `16` | UNCLASSIFIED | `AGGRESSION = 16          # 攻击性（捕食概率，L4，Rust predation 消费）` |
| `simulation/genes.py:55` | `17` | UNCLASSIFIED | `DIET = 17                # 食性（未接线，预留）` |
| `simulation/genes.py:56` | `18` | UNCLASSIFIED | `DEFENSE = 18             # 防御（未接线，预留）` |
| `simulation/genes.py:57` | `19` | UNCLASSIFIED | `ROOTING = 19             # 植物化扎根（移动概率 ×(1-g19) + 额外光合，L4）` |
| `simulation/genes.py:58` | `20` | UNCLASSIFIED | `PERSISTENCE = 20         # 赶路惯性（ARS 14.9：extensive 模式下沿上一步方向继续走的强度）` |
| `simulation/genes.py:59` | `21` | UNCLASSIFIED | `GIVE_UP = 21             # 失望阈值（ARS 14.9：extensive 模式下连走多少格没咬到就重选方向）` |
| `simulation/genes.py:60` | `22` | UNCLASSIFIED | `TRUST_GENE = 22          # 信任阈值（未接线，预留）` |
| `simulation/genes.py:61` | `23` | RATE | `MIGRATE_BIAS = 23        # 迁徙倾向（日历—罗盘式定向迁徙，13.8 接线；原 RESERVED）` |
| `simulation/genes.py:170` | `0.05` | UNCLASSIFIED | `GeneMeta(0.05, 0),    # g0  移动概率：中性（依赖环境）` |
| `simulation/genes.py:171` | `0.03` | UNCLASSIFIED | `GeneMeta(0.03, 0),    # g1  代谢倍率：保守，中性` |
| `simulation/genes.py:172` | `0.05` | UNCLASSIFIED | `GeneMeta(0.05, -1),   # g2  繁殖阈值：低阈值易繁殖（负向选择，但受资源约束）` |
| `simulation/genes.py:173` | `0.02` | UNCLASSIFIED | `GeneMeta(0.02, 0),    # g3  寿命基因：高度保守` |
| `simulation/genes.py:174` | `0.05` | UNCLASSIFIED | `GeneMeta(0.05, 1),    # g4  进食量：高值有利（正向选择）` |
| `simulation/genes.py:175` | `0.05` | UNCLASSIFIED | `GeneMeta(0.05, 1),    # g5  胃容量：高值有利` |
| `simulation/genes.py:176` | `0.03` | UNCLASSIFIED | `GeneMeta(0.03, -1),   # g6  移动能耗：低值有利（负向选择）` |
| `simulation/genes.py:177` | `0.05` | UNCLASSIFIED | `GeneMeta(0.05, 0),    # g7  传代投入：中性（r/K 策略权衡）` |
| `simulation/genes.py:178` | `0.05` | UNCLASSIFIED | `GeneMeta(0.05, 1),    # g8  光合产能：高值有利（植物化路径）` |
| `simulation/genes.py:179` | `0.05` | UNCLASSIFIED | `GeneMeta(0.05, 0),    # g9  恒温性：中性（温度依赖）` |
| `simulation/genes.py:180` | `0.05` | UNCLASSIFIED | `GeneMeta(0.05, 1),    # g10 邻格觅食倾向：高值有利（资源稀缺时）` |
| `simulation/genes.py:181` | `0.05` | UNCLASSIFIED | `GeneMeta(0.05, 0),    # g11 温度偏好：中性（环境依赖）` |
| `simulation/genes.py:182` | `0.05` | UNCLASSIFIED | `GeneMeta(0.05, -1),   # g12 繁殖冷却：低值有利（繁殖快），但受资源约束` |
| `simulation/genes.py:183` | `0.08` | UNCLASSIFIED | `GeneMeta(0.08, 0),    # g13 群居性：探索性，中性（密度依赖）` |
| `simulation/genes.py:184` | `0.08` | UNCLASSIFIED | `GeneMeta(0.08, 1),    # g14 感知半径：探索性，高值有利（信息优势）` |
| `simulation/genes.py:185` | `0.1` | UNCLASSIFIED | `GeneMeta(0.10, 0),    # g15 信号发射概率：高探索性，中性（信号成本/收益权衡）` |
| `simulation/genes.py:186` | `0.08` | UNCLASSIFIED | `GeneMeta(0.08, 0),    # g16 攻击性：中性（捕食/防御权衡，密度依赖）` |
| `simulation/genes.py:187` | `0.1` | UNCLASSIFIED | `GeneMeta(0.10, 0),    # g17 食性（预留）：默认` |
| `simulation/genes.py:188` | `0.1` | UNCLASSIFIED | `GeneMeta(0.10, 0),    # g18 防御（预留）：默认` |
| `simulation/genes.py:189` | `0.08` | UNCLASSIFIED | `GeneMeta(0.08, 1),    # g19 植物化扎根：高值有利（静态生态位）` |
| `simulation/genes.py:190` | `0.1` | UNCLASSIFIED | `GeneMeta(0.10, 0),    # g20 赶路惯性（ARS）：中性，环境决定方向` |
| `simulation/genes.py:191` | `0.1` | UNCLASSIFIED | `GeneMeta(0.10, 0),    # g21 失望阈值（ARS）：中性，环境决定方向` |
| `simulation/genes.py:192` | `0.1` | UNCLASSIFIED | `GeneMeta(0.10, 0),    # g22 信任阈值（预留）：默认` |
| `simulation/genes.py:193` | `0.1` | UNCLASSIFIED | `GeneMeta(0.10, 0),    # g23 迁徙倾向（13.8 接线；探索性位，宽松突变）` |
| `simulation/provenance.py:132` | `32` | UNCLASSIFIED | `return h.hexdigest()[:32]` |
| `simulation/provenance.py:113` | `32` | UNCLASSIFIED | `return hashlib.sha256(fh.read()).hexdigest()[:32]` |
| `simulation/sphere_engine.py:172` | `5` | UNCLASSIFIED | `CANNIB_BINS = 5` |
| `simulation/sphere_engine.py:188` | `7` | UNCLASSIFIED | `EC_N = 7` |
| `simulation/sphere_engine.py:4650` | `3` | UNCLASSIFIED | `SNAPSHOT_VERSION = 3` |
| `simulation/sphere_engine.py:1023` | `0` | UNCLASSIFIED | `self._diag_in_window = 0      # 归因命中 且 在 persistence 窗口内` |
| `simulation/sphere_engine.py:1110` | `0` | DURATION | `self._tick = 0` |
| `simulation/sphere_engine.py:233` | `1e-12` | UNCLASSIFIED | `if float(s[16]) > 1e-12 and float(s[4]) > 1e-12:` |
| `simulation/sphere_engine.py:575` | `8` | UNCLASSIFIED | `nb_stride = max(8, self.world.cols)` |
| `simulation/sphere_engine.py:650` | `1e-09` | UNCLASSIFIED | `self._cap_floor = np.maximum(self.resources._capacity, 1e-9)` |
| `simulation/sphere_engine.py:922` | `0.5` | UNCLASSIFIED | `self._arousal = np.full(n, 0.5, dtype=np.float64)` |
| `simulation/sphere_engine.py:925` | `0.5` | UNCLASSIFIED | `self._trust = np.full(n, 0.5, dtype=np.float64)` |
| `simulation/sphere_engine.py:942` | `0.3` | UNCLASSIFIED | `self._interpret = self.rng.normal(0.0, 0.3, size=(n, 16))` |
| `simulation/sphere_engine.py:1350` | `1e-09` | UNCLASSIFIED | `eff = max(1e-9, float(self.config.organisms.eat_efficiency))` |
| `simulation/sphere_engine.py:1401` | `1e-09` | UNCLASSIFIED | `max_e = max(float(self.config.organisms.max_energy), 1e-9)` |
| `simulation/sphere_engine.py:1610` | `0.5` | UNCLASSIFIED | `cap_mult = 0.5 + self._genes[:P, Gene.STOMACH_CAP] * 1.5` |
| `simulation/sphere_engine.py:2000` | `0.5` | UNCLASSIFIED | `self._pp_anom = np.ascontiguousarray(pp, dtype=np.float64) - 0.5` |
| `simulation/sphere_engine.py:2353` | `0.5` | UNCLASSIFIED | `genes[:, self._NEUTRAL_FREEZE_COLS] = 0.5` |
| `simulation/sphere_engine.py:2528` | `0.5` | UNCLASSIFIED | `eat_mult = 0.5 + genes[:, Gene.EAT_AMOUNT] * 1.0` |
| `simulation/sphere_engine.py:2529` | `0.5` | UNCLASSIFIED | `cap_mult = 0.5 + genes[:, Gene.STOMACH_CAP] * 1.5` |
| `simulation/sphere_engine.py:4408` | `1e-06` | UNCLASSIFIED | `tol = 1e-6 + 1e-9 * max(1.0, abs(float(self._oracle_transfers)))` |
| `simulation/sphere_engine.py:4609` | `0.5` | UNCLASSIFIED | `info = np.where(self.signals._marks[flat] > 0, 0.5, 0.0)` |
| `simulation/sphere_engine.py:4618` | `0.3` | UNCLASSIFIED | `self._valence[:P] += rpe * 0.3` |
| `simulation/sphere_engine.py:4622` | `0.2` | UNCLASSIFIED | `self._arousal[:P] += np.abs(rpe) * 0.2` |
| `simulation/sphere_engine.py:226` | `16` | UNCLASSIFIED | `"g16_mean": float(m[16]),` |
| `simulation/sphere_engine.py:227` | `16` | UNCLASSIFIED | `"g16_std": float(s[16]),` |
| `simulation/sphere_engine.py:228` | `4` | UNCLASSIFIED | `"g4_mean": float(m[4]),` |
| `simulation/sphere_engine.py:229` | `4` | UNCLASSIFIED | `"g4_std": float(s[4]),` |
| `simulation/sphere_engine.py:727` | `1e-12` | UNCLASSIFIED | `_season_on0 = (abs(float(getattr(_lcfg0, "tilt_rad", 0.0))) > 1e-12` |
| `simulation/sphere_engine.py:728` | `1` | UNCLASSIFIED | `and int(getattr(_lcfg0, "season_period", 0)) > 1)` |
| `simulation/sphere_engine.py:781` | `1e-12` | UNCLASSIFIED | `_season_on1 = (abs(float(getattr(_lcfg1, "tilt_rad", 0.0))) > 1e-12` |
| `simulation/sphere_engine.py:782` | `1` | UNCLASSIFIED | `and int(getattr(_lcfg1, "season_period", 0)) > 1)` |
| `simulation/sphere_engine.py:861` | `0.5` | UNCLASSIFIED | `self._ars_theta = float(getattr(_arscfg0, "theta", 0.5))` |
| `simulation/sphere_engine.py:863` | `20` | UNCLASSIFIED | `self._ars_giveup = int(getattr(_arscfg0, "giveup", 20))` |
| `simulation/sphere_engine.py:864` | `50.0` | UNCLASSIFIED | `self._ars_fast_tau = float(getattr(_arscfg0, "fast_tau", 50.0))` |
| `simulation/sphere_engine.py:865` | `500.0` | UNCLASSIFIED | `self._ars_slow_tau = float(getattr(_arscfg0, "slow_tau", 500.0))` |
| `simulation/sphere_engine.py:866` | `85.0` | UNCLASSIFIED | `self._ars_lat_exempt = float(getattr(_arscfg0, "lat_exempt_deg", 85.0))` |
| `simulation/sphere_engine.py:878` | `1e-12` | UNCLASSIFIED | `_ln[_ln < 1e-12] = 1.0` |
| `simulation/sphere_engine.py:1219` | `0.5` | UNCLASSIFIED | `centers = (np.arange(CANNIB_BINS) + 0.5) / CANNIB_BINS` |
| `simulation/sphere_engine.py:1318` | `2000` | UNCLASSIFIED | `self._corpse_boost[cells] = 2000` |
| `simulation/sphere_engine.py:1354` | `1e-12` | UNCLASSIFIED | `scav_mult = g16 ** _s / (g16 ** _s + _g ** _s + 1e-12)` |
| `simulation/sphere_engine.py:1610` | `1.5` | UNCLASSIFIED | `cap_mult = 0.5 + self._genes[:P, Gene.STOMACH_CAP] * 1.5` |
| `simulation/sphere_engine.py:1615` | `1e-09` | UNCLASSIFIED | `stomach_cap_pred = ocfg.max_energy / max(1e-9, ocfg.eat_efficiency)` |
| `simulation/sphere_engine.py:2334` | `3` | UNCLASSIFIED | `"cell_occupancy_cap", 3))` |
| `simulation/sphere_engine.py:2365` | `10.0` | UNCLASSIFIED | `pref_temp = -10.0 + genes[:, Gene.TEMP_PREF] * 50.0` |
| `simulation/sphere_engine.py:2365` | `50.0` | UNCLASSIFIED | `pref_temp = -10.0 + genes[:, Gene.TEMP_PREF] * 50.0` |
| `simulation/sphere_engine.py:2369` | `0.5` | UNCLASSIFIED | `homeo >= 0.5,` |
| `simulation/sphere_engine.py:2405` | `0.5` | UNCLASSIFIED | `metab_mult = 0.5 + genes[:, Gene.METABOLIC] * 1.5` |
| `simulation/sphere_engine.py:2529` | `1.5` | UNCLASSIFIED | `cap_mult = 0.5 + genes[:, Gene.STOMACH_CAP] * 1.5` |
| `simulation/sphere_engine.py:2604` | `0.5` | UNCLASSIFIED | `hunter = self._genes[hung, Gene.FORAGE_NEIGHBOR] >= 0.5` |
| `simulation/sphere_engine.py:2679` | `4` | UNCLASSIFIED | `self._mem_ptr = (ptr + 1) % 4` |
| `simulation/sphere_engine.py:2767` | `0.5` | RATE | `move_cost_ind = ocfg.move_cost * cold_penalty * (0.5 + genes[:, Gene.MOVE_COST])` |
| `simulation/sphere_engine.py:3453` | `0.1` | UNCLASSIFIED | `ocfg.max_energy, ocfg.eat_efficiency, 0.1,` |
| `simulation/sphere_engine.py:3702` | `0.25` | UNCLASSIFIED | `repro_thr = (0.25 + genes[:, Gene.REPRO_THRESHOLD] * 0.65) * ocfg.max_energy` |
| `simulation/sphere_engine.py:4408` | `1e-09` | UNCLASSIFIED | `tol = 1e-6 + 1e-9 * max(1.0, abs(float(self._oracle_transfers)))` |
| `simulation/sphere_engine.py:233` | `16` | UNCLASSIFIED | `if float(s[16]) > 1e-12 and float(s[4]) > 1e-12:` |
| `simulation/sphere_engine.py:233` | `4` | UNCLASSIFIED | `if float(s[16]) > 1e-12 and float(s[4]) > 1e-12:` |
| `simulation/sphere_engine.py:460` | `4` | UNCLASSIFIED | `if _ifcfg.perception_radius not in (4, 8):` |
| `simulation/sphere_engine.py:460` | `8` | UNCLASSIFIED | `if _ifcfg.perception_radius not in (4, 8):` |
| `simulation/sphere_engine.py:619` | `32` | UNCLASSIFIED | `self._span_cap = int(getattr(config.simulation, "perception_cap", 32))` |
| `simulation/sphere_engine.py:1509` | `50` | UNCLASSIFIED | `row[f"g_{name}_net_p50"] = float(np.percentile(v, 50))` |
| `simulation/sphere_engine.py:1614` | `0.5` | UNCLASSIFIED | `else ocfg.max_energy / max(1e-9, ocfg.eat_efficiency) * 0.5 * cap_mult)` |
| `simulation/sphere_engine.py:1745` | `3` | UNCLASSIFIED | `"cell_occupancy_cap": int(getattr(_sim, "cell_occupancy_cap", 3)),` |
| `simulation/sphere_engine.py:2015` | `0.9` | UNCLASSIFIED | `"corpse_energy_frac": float(getattr(cwc, "corpse_energy_frac", 0.9)),` |
| `simulation/sphere_engine.py:2016` | `600` | DURATION | `"corpse_decay_ticks": int(getattr(cwc, "corpse_decay_ticks", 600)),` |
| `simulation/sphere_engine.py:2017` | `0.5` | UNCLASSIFIED | `"corpse_to_plant_frac": float(getattr(cwc, "corpse_to_plant_frac", 0.5)),` |
| `simulation/sphere_engine.py:2018` | `0.5` | UNCLASSIFIED | `"corpse_patch_boost": float(getattr(cwc, "corpse_patch_boost", 0.5)),` |
| `simulation/sphere_engine.py:2019` | `3` | UNCLASSIFIED | `"corpse_cap_per_cell": int(getattr(cwc, "corpse_cap_per_cell", 3)),` |
| `simulation/sphere_engine.py:2020` | `0.5` | UNCLASSIFIED | `"scav_gate": float(getattr(cwc, "scav_gate", 0.5)),` |
| `simulation/sphere_engine.py:2060` | `0.35` | UNCLASSIFIED | `"wound_base": float(getattr(cwc, "wound_base", 0.35)),` |
| `simulation/sphere_engine.py:2061` | `0.001` | RATE | `"wound_heal_rate": float(getattr(cwc, "wound_heal_rate", 0.001)),` |
| `simulation/sphere_engine.py:2062` | `0.05` | RATE | `"wound_heal_energy_cost": float(getattr(cwc, "wound_heal_energy_cost", 0.05)),` |
| `simulation/sphere_engine.py:2063` | `0.3` | UNCLASSIFIED | `"holder_adv": float(getattr(cwc, "holder_adv", 0.3)),` |
| `simulation/sphere_engine.py:2064` | `0.25` | UNCLASSIFIED | `"escalation_gap": float(getattr(cwc, "escalation_gap", 0.25)),` |
| `simulation/sphere_engine.py:2065` | `0.5` | RATE | `"contest_cost_energy": float(getattr(cwc, "contest_cost_energy", 0.5)),` |
| `simulation/sphere_engine.py:2066` | `0.5` | UNCLASSIFIED | `"w_fear_health": float(getattr(cwc, "w_fear_health", 0.5)),` |
| `simulation/sphere_engine.py:2067` | `0.5` | UNCLASSIFIED | `"need_aggression_k": float(getattr(cwc, "need_aggression_k", 0.5)),` |
| `simulation/sphere_engine.py:2311` | `7.0` | UNCLASSIFIED | `return day * mult * (1.0 + g3 * 7.0)` |
| `simulation/sphere_engine.py:2367` | `0.5` | UNCLASSIFIED | `niche_match = np.exp(-0.5 * ((grid_temp - pref_temp) / 15.0) ** 2)` |
| `simulation/sphere_engine.py:2371` | `0.4` | UNCLASSIFIED | `eff_activity * (0.4 + 0.6 * niche_match),` |
| `simulation/sphere_engine.py:2405` | `1.5` | UNCLASSIFIED | `metab_mult = 0.5 + genes[:, Gene.METABOLIC] * 1.5` |
| `simulation/sphere_engine.py:2538` | `0.5` | UNCLASSIFIED | `ocfg.max_energy / max(1e-9, ocfg.eat_efficiency) * 0.5 * cap_mult` |
| `simulation/sphere_engine.py:2603` | `1e-09` | UNCLASSIFIED | `hung = np.flatnonzero(short > 1e-9)` |
| `simulation/sphere_engine.py:2770` | `4` | UNCLASSIFIED | `_d2_asym = _ifcfg.enabled and (_ifcfg.perception_radius == 4 or _ifcfg.perception_noise > 0 or _ifcfg.softmax_tau > 0)` |
| `simulation/sphere_engine.py:2770` | `0` | UNCLASSIFIED | `_d2_asym = _ifcfg.enabled and (_ifcfg.perception_radius == 4 or _ifcfg.perception_noise > 0 or _ifcfg.softmax_tau > 0)` |
| `simulation/sphere_engine.py:3702` | `0.65` | UNCLASSIFIED | `repro_thr = (0.25 + genes[:, Gene.REPRO_THRESHOLD] * 0.65) * ocfg.max_energy` |
| `simulation/sphere_engine.py:3746` | `0.1` | UNCLASSIFIED | `interp_noise = self.rng.normal(0.0, 0.1, size=(K, 16))` |
| `simulation/sphere_engine.py:3770` | `60.0` | UNCLASSIFIED | `gcfg.gene_min, gcfg.gene_max, pcfg.max_reward, 60.0,` |
| `simulation/sphere_engine.py:3784` | `0.3` | UNCLASSIFIED | `split = 0.3 + genes[ri, Gene.PARENTAL_INVEST] * 0.4` |
| `simulation/sphere_engine.py:3809` | `0.5` | UNCLASSIFIED | `child_baseline = self._baseline[ri] * 0.5` |
| `simulation/sphere_engine.py:4047` | `0.9` | UNCLASSIFIED | `cohort = 0 if P < 0.9 * max_count else 1` |
| `simulation/sphere_engine.py:4357` | `1e-09` | UNCLASSIFIED | `abs(self._oracle_payer_paid - self._oracle_sender_received) <= 1e-9` |
| `simulation/sphere_engine.py:4592` | `1e-09` | UNCLASSIFIED | `self.resources._grid[flat] / np.maximum(self.resources._capacity[flat], 1e-9),` |
| `simulation/sphere_engine.py:4952` | `4` | DECAY | `engine._corpse_scav_e, engine._corpse_decayed_e) = _fl[:4]` |
| `simulation/sphere_engine.py:728` | `0` | UNCLASSIFIED | `and int(getattr(_lcfg0, "season_period", 0)) > 1)` |
| `simulation/sphere_engine.py:782` | `0` | UNCLASSIFIED | `and int(getattr(_lcfg1, "season_period", 0)) > 1)` |
| `simulation/sphere_engine.py:1009` | `4` | UNCLASSIFIED | `if not (_ifc.enabled and _ifc.perception_radius == 4 and _ifc.softmax_tau > 0):` |
| `simulation/sphere_engine.py:1009` | `0` | UNCLASSIFIED | `if not (_ifc.enabled and _ifc.perception_radius == 4 and _ifc.softmax_tau > 0):` |
| `simulation/sphere_engine.py:1383` | `1e-12` | UNCLASSIFIED | `self._corpse_eaten_n += int(np.count_nonzero(take > 1e-12))` |
| `simulation/sphere_engine.py:1430` | `0.3` | UNCLASSIFIED | `float(self._health[j]) * (0.3 + g16[j])` |
| `simulation/sphere_engine.py:1617` | `1e-09` | UNCLASSIFIED | `np.count_nonzero(self._stomach[:P] > stomach_cap + 1e-9))` |
| `simulation/sphere_engine.py:1619` | `1e-09` | UNCLASSIFIED | `np.count_nonzero(self._stomach[:P] > stomach_cap_pred + 1e-9))` |
| `simulation/sphere_engine.py:2239` | `1` | DURATION | `self._rd.rotate(self._tick, self.rng.random(max(1, n_patch)))` |
| `simulation/sphere_engine.py:2367` | `15.0` | UNCLASSIFIED | `niche_match = np.exp(-0.5 * ((grid_temp - pref_temp) / 15.0) ** 2)` |
| `simulation/sphere_engine.py:2371` | `0.6` | UNCLASSIFIED | `eff_activity * (0.4 + 0.6 * niche_match),` |
| `simulation/sphere_engine.py:2645` | `1e-12` | UNCLASSIFIED | `\| (self._feed_fast[:P] <= 1e-12)` |
| `simulation/sphere_engine.py:2862` | `1e-09` | UNCLASSIFIED | `_fr_all = self.resources._grid / np.maximum(self.resources._capacity, 1e-9)` |
| `simulation/sphere_engine.py:2974` | `4` | UNCLASSIFIED | `d2_asym = ifcfg3.enabled and ifcfg3.perception_radius == 4` |
| `simulation/sphere_engine.py:2976` | `0` | UNCLASSIFIED | `d2_softmax = ifcfg3.enabled and ifcfg3.softmax_tau > 0` |
| `simulation/sphere_engine.py:2983` | `3` | UNCLASSIFIED | `"cell_occupancy_cap", 3))` |
| `simulation/sphere_engine.py:3654` | `1e-09` | UNCLASSIFIED | `& (self._stomach[:P] <= 1e-9)) if _stv_frac > 0.0 else _z` |
| `simulation/sphere_engine.py:3784` | `0.4` | UNCLASSIFIED | `split = 0.3 + genes[ri, Gene.PARENTAL_INVEST] * 0.4` |
| `simulation/sphere_engine.py:3808` | `0.8` | UNCLASSIFIED | `child_trust = self._trust[ri] * 0.8 + 0.5 * 0.2` |
| `simulation/sphere_engine.py:3808` | `0.5` | UNCLASSIFIED | `child_trust = self._trust[ri] * 0.8 + 0.5 * 0.2` |
| `simulation/sphere_engine.py:3808` | `0.2` | UNCLASSIFIED | `child_trust = self._trust[ri] * 0.8 + 0.5 * 0.2` |
| `simulation/sphere_engine.py:3815` | `0.3` | UNCLASSIFIED | `child_interp = self.rng.normal(0.0, 0.3, size=(K, 16))` |
| `simulation/sphere_engine.py:3819` | `0.1` | UNCLASSIFIED | `child_interp += self.rng.normal(0.0, 0.1, size=child_interp.shape)` |
| `simulation/sphere_engine.py:3868` | `0.5` | UNCLASSIFIED | `[self._arousal, np.full(K, 0.5, dtype=np.float64)]` |
| `simulation/sphere_engine.py:4603` | `24` | UNCLASSIFIED | `context = e_bin * 24 + f_bin * 6 + n_bin * 2 + s_bin` |
| `simulation/sphere_engine.py:4603` | `6` | UNCLASSIFIED | `context = e_bin * 24 + f_bin * 6 + n_bin * 2 + s_bin` |
| `simulation/sphere_engine.py:127` | `1e-09` | UNCLASSIFIED | `(energy[emitters] / max(1e-9, max_energy) * 4).astype(np.int64), 0, 3` |
| `simulation/sphere_engine.py:234` | `16` | UNCLASSIFIED | `out["corr_g16_g4"] = float(np.corrcoef(g[:, 16], g[:, 4])[0, 1])` |
| `simulation/sphere_engine.py:234` | `4` | UNCLASSIFIED | `out["corr_g16_g4"] = float(np.corrcoef(g[:, 16], g[:, 4])[0, 1])` |
| `simulation/sphere_engine.py:1426` | `0.3` | UNCLASSIFIED | `float(self._health[i]) * (0.3 + g16[i])` |
| `simulation/sphere_engine.py:1614` | `1e-09` | UNCLASSIFIED | `else ocfg.max_energy / max(1e-9, ocfg.eat_efficiency) * 0.5 * cap_mult)` |
| `simulation/sphere_engine.py:2099` | `1e-09` | UNCLASSIFIED | `"over": int(np.count_nonzero(ss > st + 1e-9)),` |
| `simulation/sphere_engine.py:2100` | `1e-12` | UNCLASSIFIED | `"negative": int(np.count_nonzero(ss < -1e-12)),` |
| `simulation/sphere_engine.py:2538` | `1e-09` | UNCLASSIFIED | `ocfg.max_energy / max(1e-9, ocfg.eat_efficiency) * 0.5 * cap_mult` |
| `simulation/sphere_engine.py:2935` | `3` | UNCLASSIFIED | `self._mover_n_by_box += np.bincount(_box, minlength=3)[:3]` |
| `simulation/sphere_engine.py:3019` | `0.5` | UNCLASSIFIED | `soc = (genes[idx, Gene.SOCIABILITY] - 0.5) * 2.0` |
| `simulation/sphere_engine.py:3031` | `0.5` | UNCLASSIFIED | `sig_weight = self._trust[idx] * (0.5 + rep_w * self._trust[idx])` |
| `simulation/sphere_engine.py:3162` | `57.29577951308232` | UNCLASSIFIED | `_lat_deg = float(self._lat_abs[_cell_i]) * 57.29577951308232` |
| `simulation/sphere_engine.py:3240` | `1e-09` | UNCLASSIFIED | `elif score.max() - score.min() < 1e-9:` |
| `simulation/sphere_engine.py:3390` | `1e-09` | UNCLASSIFIED | `hunger = np.clip(1.0 - energy / max(ocfg.max_energy, 1e-9), 0.0, 1.0)` |
| `simulation/sphere_engine.py:3612` | `0.1` | UNCLASSIFIED | `self._interpret[int(idx)] += 0.1 * (` |
| `simulation/sphere_engine.py:3719` | `1e-09` | UNCLASSIFIED | `p_soft = min(1.0, max(0.0, (_n_star - P) / max(_n_star, 1e-9)))` |
| `simulation/sphere_engine.py:5031` | `6` | UNCLASSIFIED | `_rc = _rc[:6]` |
| `simulation/sphere_engine.py:5062` | `3` | UNCLASSIFIED | `int(_gc[0]), int(_gc[1]), int(_gc[2]), float(_gc[3]), float(_gc[4]))` |
| `simulation/sphere_engine.py:5062` | `4` | UNCLASSIFIED | `int(_gc[0]), int(_gc[1]), int(_gc[2]), float(_gc[3]), float(_gc[4]))` |
| `simulation/sphere_engine.py:2069` | `0.5` | UNCLASSIFIED | `"health_low_frac": (round(float(np.mean(h < 0.5)), 6) if P else None),` |
| `simulation/sphere_engine.py:2937` | `3` | UNCLASSIFIED | `self._dash_n_by_box += np.bincount(_box[dash], minlength=3)[:3]` |
| `simulation/sphere_engine.py:3043` | `1e-09` | UNCLASSIFIED | `if float(np.abs(g).max()) > 1e-9:` |
| `simulation/sphere_engine.py:3073` | `1e-12` | UNCLASSIFIED | `if float(_sk.max() - _sk.min()) < 1e-12:` |
| `simulation/sphere_engine.py:3141` | `1e-12` | UNCLASSIFIED | `if float(np.abs(_m).max()) < 1e-12:` |
| `simulation/sphere_engine.py:3144` | `1e-12` | UNCLASSIFIED | `if float(_m.max() - _m.min()) < 1e-12:` |
| `simulation/sphere_engine.py:3165` | `8` | UNCLASSIFIED | `if (_lat_deg <= self._ars_lat_exempt and 0 <= _hd < 8` |
| `simulation/sphere_engine.py:3177` | `1e-12` | UNCLASSIFIED | `if float(_m.max() - _m.min()) < 1e-12:` |
| `simulation/sphere_engine.py:3514` | `0.5` | RATE | `* (0.5 + attack_gene[idx] * pcfg.success_gene_gain),` |
| `simulation/sphere_engine.py:3823` | `16` | RATE | `cb_mut = self.rng.random((K, 16)) < ifcfg.codebook_mutation_rate` |
| `simulation/sphere_engine.py:3033` | `0.5` | UNCLASSIFIED | `fr * 0.5 + sp * sig_weight` |
| `simulation/sphere_engine.py:3057` | `0.4` | UNCLASSIFIED | `score = score + 0.4 * perc * interp` |
| `simulation/sphere_engine.py:3077` | `1e-12` | UNCLASSIFIED | `if float(np.abs(_sk).max()) < 1e-12:` |
| `simulation/sphere_engine.py:3092` | `1e-12` | UNCLASSIFIED | `if float(_fe.max() - _fe.min()) < 1e-12:` |
| `simulation/sphere_engine.py:3111` | `1e-12` | UNCLASSIFIED | `if float(_fh.max() - _fh.min()) < 1e-12:` |
| `simulation/sphere_engine.py:3513` | `1e-09` | UNCLASSIFIED | `(energy[idx] / max(energy[idx] + energy[prey], 1e-9))` |
| `simulation/sphere_engine.py:3544` | `0.5` | UNCLASSIFIED | `0.5 + 0.5 * float(attack_gene[idx])` |
| `simulation/sphere_engine.py:4858` | `16` | UNCLASSIFIED | `f"配置指纹不匹配：快照={snap_fp[:16]}...，当前={cur_fp[:16]}..."` |
| `simulation/sphere_engine.py:3050` | `0.3` | UNCLASSIFIED | `score = score + 0.3 * perc * mem_in_nb.astype(np.float64)` |
| `simulation/sphere_engine.py:3108` | `0.3` | UNCLASSIFIED | `if _inj >= float(getattr(_cwc_pred, "wound_fear_threshold", 0.3)):` |
| `simulation/sphere_engine.py:3479` | `16` | UNCLASSIFIED | `cb_mask = self.rng.random(16) < ifcfg_sa_r.alignment_step` |
| `simulation/sphere_engine.py:3537` | `1e-09` | UNCLASSIFIED | `ocfg.max_energy / max(1e-9, ocfg.eat_efficiency),` |
| `simulation/sphere_engine.py:3636` | `16` | UNCLASSIFIED | `cb_mask = self.rng.random(16) < ifcfg_sa.alignment_step` |
| `simulation/sphere_engine.py:3212` | `0.5` | UNCLASSIFIED | `score_wo = perc * (fr * 0.5) + soc * densities[nb]` |
| `simulation/sphere_engine.py:3226` | `0.4` | UNCLASSIFIED | `score_woc = score - 0.4 * perc * interp` |
| `simulation/sphere_engine.py:3563` | `1e-09` | UNCLASSIFIED | `ocfg.max_energy / max(1e-9, ocfg.eat_efficiency),` |
| `simulation/sphere_engine.py:3214` | `0.3` | UNCLASSIFIED | `score_wo = score_wo + 0.3 * perc * np.isin(` |
| `simulation/sphere_engine.py:3270` | `100` | UNCLASSIFIED | `int(self._far_off[_c]) + int(rand_choice[i] // 100) % _fl])` |
| `world/light_and_temperature.py:98` | `2400` | UNCLASSIFIED | `rotation_period: int = 2400,` |
| `world/light_and_temperature.py:99` | `30.0` | UNCLASSIFIED | `t_equator: float = 30.0,` |
| `world/light_and_temperature.py:101` | `6.0` | UNCLASSIFIED | `day_boost: float = 6.0,` |
| `world/light_and_temperature.py:104` | `0` | UNCLASSIFIED | `season_period: int = 0,` |
| `world/light_and_temperature.py:100` | `20.0` | UNCLASSIFIED | `t_pole: float = -20.0,` |
| `world/light_and_temperature.py:171` | `1e-12` | UNCLASSIFIED | `self._lat_term_is_cos = abs(self.lat_base_ref - 1.0) < 1e-12` |
| `world/light_and_temperature.py:436` | `10.0` | UNCLASSIFIED | `t_min, t_ref = -10.0, 10.0` |
| `world/light_and_temperature.py:141` | `1e-12` | UNCLASSIFIED | `self._season_on = (abs(self.tilt_rad) > 1e-12` |
| `world/light_and_temperature.py:142` | `1` | UNCLASSIFIED | `and self.season_period > 1)` |
| `world/light_and_temperature.py:144` | `2` | UNCLASSIFIED | `assert self.season_period >= 2, "season_period 至少 2 tick"` |
| `world/light_and_temperature.py:354` | `1e-09` | UNCLASSIFIED | `eps = 1e-9` |
| `world/light_and_temperature.py:346` | `0.5` | UNCLASSIFIED | `self.world.n_cells, 0.5, dtype=np.float64)` |
| `world/light_and_temperature.py:234` | `1e-12` | UNCLASSIFIED | `cos_lat[:, 0] > 1e-12,` |
| `world/resource_dynamics.py:125` | `0` | DURATION | `assert self.dead_regen_ticks > 0, (` |
| `world/resource_dynamics.py:113` | `300` | DURATION | `self.rest_ticks = int(g("rest_ticks", 300))` |
| `world/resource_dynamics.py:115` | `0.3` | UNCLASSIFIED | `self.rest_threshold = float(g("rest_threshold", 0.3))` |
| `world/resource_dynamics.py:116` | `0.8` | UNCLASSIFIED | `self.death_threshold = float(g("death_threshold", 0.8))` |
| `world/resource_dynamics.py:117` | `0.5` | UNCLASSIFIED | `self.damage_recovery = float(g("damage_recovery", 0.5))` |
| `world/resource_dynamics.py:118` | `0.7` | UNCLASSIFIED | `self.kill_frac = float(g("kill_frac", 0.7))` |
| `world/resource_dynamics.py:120` | `2000` | DURATION | `self.dead_regen_ticks = int(g("dead_regen_ticks", 2000))` |
| `world/resource_dynamics.py:121` | `0.5` | UNCLASSIFIED | `self.dead_cell_max_frac = float(g("dead_cell_max_frac", 0.5))` |
| `world/resource_dynamics.py:416` | `1e-12` | UNCLASSIFIED | `area = self._base_capacity / max(1e-12, float(self._base_capacity.sum()))` |
| `world/resource_dynamics.py:325` | `0` | UNCLASSIFIED | `expired = (self._rest_until >= 0) & (~self._dead) & (tick >= self._rest_until)` |
| `world/resource_dynamics.py:398` | `1e-12` | UNCLASSIFIED | `"capacity_total_rel": round(cap_total / max(1e-12, self._cap_total_0), 9),` |
| `world/resource_dynamics.py:427` | `1e-12` | UNCLASSIFIED | `"capacity_total_rel": round(cap_total / max(1e-12, self._cap_total_0), 9),` |
| `world/resource_field.py:85` | `40.0` | UNCLASSIFIED | `capacity_per_area: float = 40.0,` |
| `world/resource_field.py:86` | `0.5` | RATE | `regrowth_rate: float = 0.5,` |
| `world/resource_field.py:91` | `30` | UNCLASSIFIED | `patch_count: int = 30,` |
| `world/resource_field.py:93` | `3.0` | UNCLASSIFIED | `patch_capacity_mult: float = 3.0,` |
| `world/resource_field.py:97` | `3.0` | UNCLASSIFIED | `patch_regrowth_mult: float = 3.0,` |
| `world/resource_field.py:98` | `0.1` | UNCLASSIFIED | `background_fill: float = 0.1,` |
| `world/resource_field.py:99` | `0.5` | UNCLASSIFIED | `initial_fill: float = 0.5,` |
| `world/resource_field.py:100` | `42` | UNCLASSIFIED | `patch_seed: int = 42,` |
| `world/resource_field.py:408` | `20.0` | UNCLASSIFIED | `factor = np.clip((temps + 20.0) / 20.0, 0.0, 1.0)` |
| `world/resource_field.py:418` | `1e-09` | UNCLASSIFIED | `if m > 1e-9:` |
| `world/signal_field.py:27` | `50` | UNCLASSIFIED | `def __init__(self, world: SphereWorld, duration: int = 50) -> None:` |
| `world/signal_field.py:50` | `0` | DURATION | `self._age[cell] = self.duration if (pattern & 0x0F) else 0` |
| `world/signal_field.py:56` | `15` | UNCLASSIFIED | `p = patterns & 0x0F` |
| `world/signal_field.py:50` | `15` | DURATION | `self._age[cell] = self.duration if (pattern & 0x0F) else 0` |
| `world/sphere_world.py:55` | `60` | UNCLASSIFIED | `def __init__(self, rows: int = 60, cols: int = 120) -> None:` |
| `world/sphere_world.py:55` | `120` | UNCLASSIFIED | `def __init__(self, rows: int = 60, cols: int = 120) -> None:` |
| `world/sphere_world.py:253` | `3` | UNCLASSIFIED | `_MOORE_UP_LEFT, _MOORE_UP, _MOORE_UP_RIGHT, _MOORE_LEFT = 0, 1, 2, 3` |
| `world/sphere_world.py:254` | `4` | UNCLASSIFIED | `_MOORE_RIGHT, _MOORE_DOWN_LEFT, _MOORE_DOWN, _MOORE_DOWN_RIGHT = 4, 5, 6, 7` |
| `world/sphere_world.py:254` | `5` | UNCLASSIFIED | `_MOORE_RIGHT, _MOORE_DOWN_LEFT, _MOORE_DOWN, _MOORE_DOWN_RIGHT = 4, 5, 6, 7` |
| `world/sphere_world.py:254` | `6` | UNCLASSIFIED | `_MOORE_RIGHT, _MOORE_DOWN_LEFT, _MOORE_DOWN, _MOORE_DOWN_RIGHT = 4, 5, 6, 7` |
| `world/sphere_world.py:254` | `7` | UNCLASSIFIED | `_MOORE_RIGHT, _MOORE_DOWN_LEFT, _MOORE_DOWN, _MOORE_DOWN_RIGHT = 4, 5, 6, 7` |
| `world/subpos.py:50` | `4` | UNCLASSIFIED | `DEFAULT_SUBDIV: int = 4` |
| `world/subpos.py:157` | `0.5` | UNCLASSIFIED | `steps = np.floor(s * float(subdiv) + 0.5)` |
