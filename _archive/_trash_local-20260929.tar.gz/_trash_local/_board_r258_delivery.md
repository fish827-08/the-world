### [本地开发·性能线] · 2026-09-29 12:10（Asia/Shanghai）

**R258 §二 交付：13.11 记忆权重基因位（g22 接管）完成 —— 已推 main `79f60aa`**

**一、交付内容（`79f60aa`，gitee/main 远端 SHA 已复核 = 79f60aa）**

- **g22 接管**：`Gene.TRUST_GENE(22)` → `Gene.MEMORY_WEIGHT`（**值不变 ⇒ 基因组仍 24 位**；语义 = 记忆权重乘子）。
  ⚠️ **位选更正**：R258 §二 列 g17/g18/g22 为"空闲位"，其中 **g17/g18 自 §13.2（09-22）起已被消费**（追猎倾向/机动性，引擎实际在用）⇒ 实际只剩 **g22 真空闲**，本次只取 g22（已在 11:53 帖确认）。
- **乘子语义**：`eff_gain = cfg_gain × (2×g22)`（∈[0,2]；g22 均匀初始化 ⇒ **乘子均值 1.0**，与 S3 固定权重批**总体**可比）；精/粗同乘 ⇒ 2:1 比例不变；消费点 = `_memory_egocentric_cos`（**单点**）。
- **开关** `info_structure.memory_weight_gene` 默认 **False ⇒ 逐位不变**（S3 批语义与 C7 digest `(574887, 11266.746993)` 均不动，S2 测试仍在钉）。
- **fail-loud**：`memory_weight_gene ∧ ¬memory_v2` ⇒ 构造期断言（乘子只在 v2 打分路径消费，防静默 no-op）。
- 加基因五步曲全走（Python enum/SEMANTICS/META/WIRED + Rust 常量 + validate 清单 + 引擎消费 + 注册表测试）。

**二、🔴 需重建 sim_core 声明（13.8/R199 环境约束同款）**

改了 Rust 常量名（`G_TRUST_GENE → G_MEMORY_WEIGHT`）⇒ `validate_gene_wiring()` 按**名字**逐位比对 ⇒ **未重建的环境会报 `NAME_MISMATCH(rust=TRUST_GENE)=>REBUILD_SIM_CORE`**。本机已 maturin 重编（`validate_gene_wiring()==[]` ✅）；云端环境如装了 sim_core 同需重建；纯 Python 路径不受影响。

**三、登记与自证（C9）**

- `AGENT.md §13.11` 纪元段（触发/为什么/默认与回滚/自证字段/纪律/状态）；`AGENTS.md` **预留位耗尽声明**（6 位全接管 ⇒ **下次新增基因位必须扩 `gene_count`**）；S3 实施细化稿 §四 补注本乘子。
- a4 `switches` 读回：`memory_weight_gene` + `memory_weight_gene_slot`（=22，自证基因位未被挪，P7 家族）。
- 附：修一处**存量登记漂移** —— g17/g18 自 §13.2 起已被消费，但注册表 `_GENE_WIRED` 仍标"未接线"，本次补登（只动注册表，不改行为）。

**四、验收数据（`[实测]`）**

- 靶向：`test_genes_registry` 18/18 + `test_memory_v2_egocentric` 16/16（含新增 S12×3：乘子语义 0.5/1.0/0.0、开关∧¬v2 fail-loud、开档≠关档 digest）全绿。
- 守卫：r98 / 硬编码扫描 / config 兜底 18/18；config 兜底审计 **0 不一致**；tick 面额审计**无新增红**（存量 5 项 memv2 unclassified 未动，归 memv2 线）。
- 全量：**48 failed / 986 passed / 8 skipped** = 45 存量（09-28 基线 36+5+3+1）+ **3 例 `test_a2b_tick_audit_coverage`**（**非本线**：已用 HEAD（`b957ab7`）临时 worktree 复核确证同 3 红 ⇒ memv2 合并后即红，根因 = memv2 五字段未分类 ⇒ 工具 rc=1；修复窗口归 memv2 线/后续裁定）。
- Rust 路径冒烟（`use_sim_core=True`，5 tick）OK。

**五、给 S3.5 的接线指引**

在 S3 同源装置上，处理臂加 `info_structure.memory_weight_gene=True`（须 `memory_v2=True` + `use_sim_core=False`）；采样 `eng._genes[:, int(Gene.MEMORY_WEIGHT)]` 频率（t=0 + 逐采样点）⇒ 判据③"记忆基因频率被选择"由此复活。
🔴 纪律：**S3 批（固定权重）与 S3.5（基因位开）不可混比**（个体层权重分布不同；仅总体均值 1.0 对齐）。

**六、下一件**

本件已完（R258 §二："完成并纪元登记后开 S3.5"——判读归实验/所有者线）。按 R258 顺延约定，**我线下一件 = ASM（模式仲裁，规格 §三）**，无新裁定即照原规格开工。
