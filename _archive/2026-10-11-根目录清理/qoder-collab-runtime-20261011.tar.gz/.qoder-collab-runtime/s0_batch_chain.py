#!/usr/bin/env python
"""S0 链式跑批编排 —— R398③（≥2 批排队先写链式脚本：跑批→聚合→下一批）

依据：owner 放行 @`c269d08`＋PI 点火程序令 @`dda9d5d`＋F0 #12 定值 20,000t/间隔 100。
本脚本只做**编排**，不含科学判读：判读口径全部在冻结判据（v1.2）里，聚合调用
`aggregate()` 适配器；单 run 执行调用 `run_one()` 适配器。

fail-loud 三条（任一命中即非零退出、停链、不静默跳过）：
  1. s0_kernel/H2 未落地 ⇒ `run_one()` 显式 raise NotImplementedError；
  2. 会签未确认（#1 seed 集 / #2 Z1_base_seed / #12 tick）⇒ 不加 `--confirm-signed` 拒跑；
  3. 任一批聚合失败 ⇒ 后续批不起跑。

断点续跑：`<out-root>/checkpoint.json` 记录逐 run 状态与批级聚合状态；重跑时已
`done` 的 run 跳过（以 manifest 中 output 文件存在＋digest 为准）。

用法：
    python tools/s0_batch_chain.py --schedule          # 只打印批次编排，不执行
    python tools/s0_batch_chain.py --confirm-signed    # 正式执行（候会签后）
    python tools/s0_batch_chain.py --confirm-signed --resume
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent

# —— F0 填值位（以会签终值为准；本常量仅提案在案值 @`48ffcf2`＋#12 定值）——
TICKS = 20000            # #12 定值（长实验轴，owner 放行覆盖）
SAMPLE_INTERVAL = 100    # n=200、k=int(0.25n)=50
SEEDS = [207, 208, 209, 210, 211, 212, 213, 214]   # #1 提案（备位 501–508）
Z1_BASE_SEED = 90000     # #2 提案；派生规则已锁 base + arm_idx*1000 + rep_index
ARM_IDX = {"A": 0, "B": 1}

SIGNED_KEYS = ("TICKS", "SEEDS", "Z1_BASE_SEED")


def z1_seed(arm: str, rep_index: int) -> int:
    return Z1_BASE_SEED + ARM_IDX[arm] * 1000 + rep_index


def build_schedule() -> list[dict]:
    """批次编排：标定批先行 → 正式批（32 run 四组）；每批 {name, runs[], aggregate 描述}。"""
    runs = lambda arm, n, kind: [
        {"run_id": f"{arm}{kind}{i}", "arm": arm, "seed": SEEDS[i], "rep_index": i,
         "kind": kind, "ticks": TICKS, "sample_interval": SAMPLE_INTERVAL,
         "z1_seed": z1_seed(arm, i)}
        for i in range(n)
    ]
    return [
        {"batch": "calib", "desc": "标定批先行（点火程序令；Z1 零样本 M=500＋机时/置换计时）",
         "runs": runs("A", 1, "calib")},
        {"batch": "formal", "desc": "正式批 32 run：A 运行8＋A 重复批8(不得剔)＋B 运行8＋B α_W=0 对照8",
         "runs": runs("A", 8, "") + runs("A", 8, "rep") + runs("B", 8, "") + runs("B", 8, "aw0")},
    ]


def _digest(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()[:16]


def run_one(spec: dict, out_dir: Path) -> Path:
    """单 run 适配器 —— s0_kernel/H2 未落地，显式 fail-loud，禁止静默占位。"""
    raise NotImplementedError(
        "run_one 适配器未接：s0_kernel harness 与澜舟 H2（#10 attack_cost/k 谷窗、#11 alpha_W 键）"
        f"未落地，本 run（{spec['run_id']}）无执行入口。[R398③ fail-loud]")


def aggregate(batch: dict, manifest: list[dict], out_dir: Path) -> dict:
    """批后聚合适配器 —— 判读算账随冻结判据（v1.2）的校验脚本另卡交付，此处 fail-loud。"""
    raise NotImplementedError(
        f"aggregate 未接：批「{batch['batch']}」聚合须调用冻结判据判读脚本（判据双签 @74d171b，禁自行实现）。[R398③ fail-loud]")


class Chain:
    def __init__(self, out_root: Path, resume: bool):
        self.out = out_root
        self.out.mkdir(parents=True, exist_ok=True)
        self.ckpt_path = self.out / "checkpoint.json"
        self.manifest_path = self.out / "run_manifest.jsonl"
        if self.ckpt_path.exists() and resume:
            self.ckpt = json.loads(self.ckpt_path.read_text(encoding="utf-8"))
        else:
            self.ckpt = {"runs": {}, "batches": {}}

    def save(self) -> None:
        tmp = self.ckpt_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.ckpt, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(self.ckpt_path)

    def append_manifest(self, rec: dict) -> None:
        with self.manifest_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    def is_done(self, run_id: str) -> bool:
        st = self.ckpt["runs"].get(run_id)
        if not st or st.get("status") != "done":
            return False
        p = Path(st["output"])
        return p.exists() and _digest(p) == st.get("digest")

    def run(self) -> int:
        for batch in build_schedule():
            b = batch["batch"]
            if self.ckpt["batches"].get(b, {}).get("aggregated"):
                print(f"[chain] 批 {b} 已聚合，跳过")
                continue
            for spec in batch["runs"]:
                rid = spec["run_id"]
                if self.is_done(rid):
                    print(f"[chain] run {rid} 已完成（digest 校验过），续跑跳过")
                    continue
                t0 = time.monotonic()
                try:
                    out = run_one(spec, self.out)
                except NotImplementedError as e:
                    self.ckpt["runs"][rid] = {"status": "blocked", "error": str(e)}
                    self.save()
                    print(f"[chain][FAIL-LOUD] {e}", file=sys.stderr)
                    return 2
                rec = {"run_id": rid, **spec, "status": "done", "output": str(out),
                       "elapsed_sec": round(time.monotonic() - t0, 3), "digest": _digest(Path(out)),
                       "ts": time.strftime("%F %T")}
                self.ckpt["runs"][rid] = rec
                self.append_manifest(rec)
                self.save()
            try:
                agg = aggregate(batch, list(self.ckpt["runs"].values()), self.out)
            except NotImplementedError as e:
                print(f"[chain][FAIL-LOUD] {e}", file=sys.stderr)
                return 2
            self.ckpt["batches"][b] = {"aggregated": True, "result": agg}
            self.save()
            print(f"[chain] 批 {b} 聚合完成 → 进入下一批")
        return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="S0 链式跑批编排（R398③）")
    ap.add_argument("--schedule", action="store_true", help="只打印批次编排")
    ap.add_argument("--confirm-signed", action="store_true",
                    help="确认 #1/#2/#12 会签终值与常量一致（不加则拒跑，防未定值起跑）")
    ap.add_argument("--resume", action="store_true", help="断点续跑")
    ap.add_argument("--out-root", default="_rerun_logs/s0_chain")
    a = ap.parse_args()
    sched = build_schedule()
    if a.schedule:
        for b in sched:
            print(f"批 {b['batch']}（{b['desc']}）：{len(b['runs'])} run")
            for r in b["runs"]:
                print(" ", r["run_id"], "seed", r["seed"], "ticks", r["ticks"], "z1", r["z1_seed"])
        return 0
    if not a.confirm_signed:
        print("[chain][FAIL-LOUD] 未加 --confirm-signed：会签（seed 集/Z1_base_seed/tick 定值）"
              "未确认前禁止起跑。[R402：未定值不得自称短实验；本批为长实验轴]", file=sys.stderr)
        return 3
    return Chain(REPO / a.out_root, a.resume).run()


if __name__ == "__main__":
    sys.exit(main())
