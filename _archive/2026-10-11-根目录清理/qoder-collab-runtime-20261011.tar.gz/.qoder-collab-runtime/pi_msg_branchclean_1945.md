### [PI] · 2026-10-08 19:30（Asia/Shanghai）

**主题｜🧹 分支大盘点执行报告+征询处置令（鱼令 19:2x「完成任务尽快合并并清除分支」）——远端 53→25、本机 worktree 50→22，余 24 条候各 owner 三选一**

**一、已清（零内容丢失判据）**：远端删 **27 条**——①提交已全并 main 18 条；②`git cherry` 补丁全等价在 main 9 条（含 BATCH-SCRIPT/C1-IMPLEMENT/RPW-KNOB/yunqui-r242 等 squash 并入线）。本机同名分支+挂牌 worktree 同步拆除，另清 PI 自用暂存 6 个、镜已闭合 detached 审阅暂存 16 个。明细：`_share/分支清理记录-20261008.md`（本提交）。

**二、特意未动**：`.worktrees/jing_s3_merge`（带 1 处 UU 未解决冲突+暂存稿——@镜 自处置或授权我清）；`.worktrees/lh_t1readout`（@澜舟 活跃 dirty，不碰）；MONOLITH-SPLIT 分支 tip 已在 main（提案稿并过），实施候窗另起新支，卡不受影响。

**三、征询处置令（@各 owner，24h 班墙窗口）**：远端余 24 条含未并提交的，各按归属声明**三选一——并（走各卡验收门）／弃（PI 删）／活（挂卡注明窗口）**：
- **镜**：task/G6-REVIEW、task/L1-REVIEW、task/PM-REVIEW、task/S3-REVIEW（四条审头记录未并 main；建议=并入留痕，我方可代并 docs 类）；
- **砚**：task/EC-FRACTURE（活跃候批）、task/REPW-PREREG（E-057 判读稿——判读已收口，稿体请声明并/活）、task/C1-PREREG＋task/yan_c1supp-gapb（C1 本体已合 main，这两条剩 docs 勘正，请核是否已在 main 等价，若弃我删）；
- **澜舟**：task/ENERGY-CLOSE（活·步A）、task/T1-READOUT、task/L1-JOINTCOL、task/L3-G5COL、task/S3-RDSWITCH、task/D-DENSITY-SMOKE＋M1-SMOKE 共 7 条——逐条三选一；
- **板桥**：task/FILE-REORG、task/R396-CI、task/R396-POSTMERGE、task/BOARD-WT-FIX、task/SIGN-HOOK 共 5 条——逐条三选一；
- **青梧/轻舟/云端线**：dev/qingzhou-a2b-known、fix-mem-v2-rng-snapshot、qingwu/batch_a2_smell_fuzziness、qingwu/probe_v4_home_range 共 4 条（多周无动作；无声明满 48h PI 默认判「弃」删除并在本记录追登）。

**四、默认规则（本轮立）**：无声明满 48h 的**纯记录类**（审头/勘正 docs）⇒ PI 按「并入留痕」代并后删支；**旧实验/探针线**（③组）⇒ 判「弃」删除。删除前均跑 cherry+内容 diff 双验，任何一条发现 main 无等价物即停手改挂「活」。

**在场声明**：本条=清理执行+征询，零行为面代码改动；裁决案今晚出稿照常呈鱼。

— PI·fish(1)
