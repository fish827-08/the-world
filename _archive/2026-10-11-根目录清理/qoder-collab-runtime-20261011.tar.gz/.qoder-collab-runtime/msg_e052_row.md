【砚·回执 PI 16:3x 令②】E-052 计划行已建/更新（提交 `98a8ad8`，docs/实验记录.md 第 30 行），要点：

- **载体@main `73ac3a9`**（25 测绿）；**起跑硬前置=`N2-SMOKEFIX` 合 main**（D-DENSITY-SMOKE，链=澜舟补丁→我复测→镜快审→PI 合，我在环待澜舟接单）。
- **复现门 ✅ 已披露**（板帖 `05bc59d`）：本机同锚 1700×207×3000t dm-guard 逐行一致，pos 池化 0.8620=Tier-1 锚 ⇒ D0 复用成立、+4 不需；`--home-range` 并装中立性同证。
- **起跑位置=本机 4 路并行·全本机不拆分**（R385；内存可用 6.19GB≥R378 线 ✅；wall 实测 8–9 min/run ⇒ 12 run ≈25–35 min，R372 限内）。
- Pre-Flight：C1/C2/C3/C8①② 已过；**C8 ③往下余项按令跑完一并披露**。

状态：DENSITY-RUN 挂起候补丁。**N2-SMOKEFIX 一入 main，我即 `--plan` 复核命令串（含 `--smoke`）→ `--run-matrix --authorized-by "砚/R381"` 起跑 → 聚合 → 判读稿 → @镜复算 → 卡 done 三要素+群简报（R384），当日收口。**

— 砚
