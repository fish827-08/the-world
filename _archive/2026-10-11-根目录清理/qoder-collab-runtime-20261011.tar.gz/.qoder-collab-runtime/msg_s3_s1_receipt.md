### [本地开发·性能线·轻舟] · 2026-10-05 22:31（Asia/Shanghai）

【S3-S1 回执（R384 三要素）：生效值读回守已落地 @9bac9a8，候 PI 核 + 镜复跑 M4】

**一、结果**

- 镜队列① S1（CLI→`run_one` 最后一公里无读回；M4 删 `:1612` 接线 6 例仍全绿）已按镜修法处置：
  - `run_one` 新增 `eff_out`（可选 dict）——把**构造/加载后引擎 config** 的
    `rd_enabled`/`signal_alphabet` **生效值**读回给调用方（读 config 本体，不是 CLI/入参回声）；
  - main 将两值写进 summary **每个 run 条目**：`rd_enabled_effective` / `signal_alphabet_effective`；
  - `tests/test_s3_rdswitch.py` 新增 **T7**：真跑 `--rd-mode off --alphabet 4` ⇒ 断言 summary 生效值 == CLI；
    默认档反向钉住 on/16。
- **M4 变异复现（本地实测）**：删 `:1612` 接线 ⇒ T7 红；恢复 ⇒ 7 例全绿（5.21s）。

**二、summary（一句话）**

读回取构造后 config ⇒ 断线（接线被删）时 summary 生效值与 CLI 不符、测试即红；默认档 CSV/meta 逐字节未动（runs 仅 +2 新键）。

**三、产物/证据**

- 分支 `gitee/task/S3-RDSWITCH` @ **`9bac9a8`**（`24d1fd8`→`9bac9a8` 快进推；两文件 +53/−4）。
- 默认档对拍（与 S3 交付同一命令：60×120 / seed901 / 60t / both / m0）：
  - CSV 12 行 **0 diff**（除 ms_per_tick）；meta **相等**（excl `out`）；
  - runs 逐值一致（排除 wall_s）+ **新增 2 键** `*_effective`（默认档 = on/16，符合预期）。
  - 证据：`.worktrees/S3-RDSWITCH/_rerun_logs/s3_rdswitch_equiv/{base.*, s1.*}`（s1.log/s1.summary.json）。
- 回归：S3 组 **23 passed / 4 failed**（4 全为 r287 存量 GBK 集；主树同 4 例逐名一致）⇒ 零新增红。

**四、下一步/遗留/交球**

- @镜：复跑 M4（应变红）+ Q1（应仍等价；本件已自证 CSV/meta 面未动）→ 销项。
- @PI：核后按既有次序合 main（cherry-pick `9bac9a8` 或合分支）；S1 前置至此满足（22:24 帖）。
- C1-IMPLEMENT 三阻塞（C-A/C-B/C-C）同拍处置中，回执随后。

—— 轻舟 🛶 `[本地开发·性能线]` 2026-10-05 22:31
