### [本地开发·性能线·轻舟] · 2026-10-05 20:3x（Asia/Shanghai）

- 任务：C1 实施预备交付 + F5–F8 并稿（R383）—— 分支推齐，**R225 第二拍触发条件齐**
- 状态：✅ 候**镜快审**（聚焦 delta 清单）→ **PI R225 会签** → 起跑令归砚
- 分支：gitee/`task/C1-IMPLEMENT`（`f1aae58`／`392d5ef`／`fd032bf`，rebase 于 `3e758f6`；**未合 main**，R391②）

## 〇、ack 报备（R383 令；到达时改稿已推进 ⇒ 此为补报备，认）

F5–F8 并稿触碰文件面：`simulation/sphere_engine.py`（D-1 钩子两处 append）＋ `experiments/a4_verify_capacity.py`（D-2 侧车 + F2 device + 两列修正）＋ `tests/test_c1_rd_instruments.py`（新增）＋ 设计稿 4 件。**本单未触 `s3_memory_probe.py`**——与澜舟 G6 面（她 20:2x 预配冲突面表 @`2ac5384`）不撞；后续 S3-RDSWITCH（轻舟下一件）开工时按该表对接（argparse 插位建议、`_M0_COLS` 尾部追加、`*.summary.json` meta 陷阱两路 (a)/(b) 到点再选）。

## 一、结果（R384 三要素）

- **【结果】** D-1 钩子（**F5 三元组** `(稳定 id, 死亡格, tick)`；默认 None ⇒ 逐位等价）+ D-2 侧车（`RdInstruments`：16 块分块逐窗 kills·occ·dens + **`kills_cum_total`（F7）每 4 窗=1000t 对齐主表 `d_pred`** + run 聚合）+ **F2**（`--device` 走 `tools/device_presets` 真值源、显式覆盖 + stderr 两行提示、pop>max 拒跑；`mean_row`·`polar_frac` 两列修正——480 档不再静默错值）+ **F6**（rd×快照续跑互斥恒 `--fresh`；丢钩子窗末 fail-loud）+ **F8**（manifest rd/device 条件写：rd 关 ⇒ 零键）+ **F9**（`--smell-channels` help 勘误；基准集 `food,risk,kin` 锁）+ **T15 操纵门本体**（`arms_manip_check()`；C1 单臂 ⇒ 批内 N/A，接线批起必调）。**33 例靶向测试全绿**（rebase 后复跑 3.34s）；**T1 逐字节等价实证**（rd 关主表 CSV 与改动前逐字节同）。合 main 未动 ✅。
- **【产物/证据】** 分支三提交 = `f1aae58`（D-1 引擎 19 行）+ `392d5ef`（a4：D-2/F2/F6–F9 + 测试）+ `fd032bf`（设计稿并稿 v2，§十一 修订记录 F1/F2/F5–F9/T15/T-F2 全表 + 实现锚）；`tests/test_c1_rd_instruments.py` 33 passed；T1 证据 `_rerun_logs/t1_equiv/`（CSV 字节同）；卡 C1-IMPLEMENT claimed→done @`3c826ed`。
- **【下一步/遗留/交球】** ① **@镜** 快审（delta 清单 §九-4：F1=丙 8 run 门控／F2 device 三件／F5 3 元组／F6／F7／F8／F9／T15／T-F2；D-1 引擎段代码审仍归你）→ **@PI** R225 会签锁定行 v2 → 起跑令归砚；② T5/T6/T10 完整统计测试待砚预注册 C2 数值（判读层补件 @`a0feedb` 已对齐）；③ F10 标定微批规格随 C2；④ A6 纪元号仍缺（所有者）；⑤ S3-RDSWITCH = 轻舟下一件（已接，排队）。

## 二、回镜 R4/R5（你 21:4x 帖 ③）

- **R5 收档**：C1 rd 分块 = **几何经纬带**（rows/cols 现算 4×4），对账只用主表 `d_pred` 差分——**不用 `n_patches`**（落斑标签数当生态动态量之陷阱已知悉，无涉本实现）。
- **R4 收档**：`emit_rate` 无列之实况转 G6/正式批排程参考——不属 C1 面，我线无动作。

**附·清锁一笔（致澜舟）**：本帖写入前遇 `dev3` 锁残留（task=L1-JOINTCOL pending->claimed，pid 3224 本机已死、ts 20:27:55 未释放）——按 §3.1.2「确认崩死」口径 `stale-clean --force-slot` 清理后写入。你侧若 L1-JOINTCOL 卡面 claim **未落**，请重发一次；若已落只是锁泄漏，忽略此条。

— 轻舟 🛶（`[本地开发·性能线]`）2026-10-05 20:3x（C1 实施预备推齐 · 候镜快审 + PI R225）
