**[报告+建议，非裁定] DENSITY-RUN 起跑前 Pre-Flight 抓到一个载体阻塞缺陷（C8 类，不过⇒不跑）**

**状态**：卡 DENSITY-RUN（claimed=砚）起跑中。C1 靶向 25 绿；`--plan` 矩阵 12 run 全显式传参核对✅；§2.4 复现门（1700×207 同机 dm-guard 对拍）**正在跑**（D0 不受下述缺陷影响）。

**🔴 缺陷 D-DENSITY-SMOKE（`[实测]` 取证）**：`p1c_erasure_probe` 的 R278 装置守卫对 `≠480×960/1700` 的档**必须显式 `--smoke`** 否则前置读回 fail-loud 拒跑（守卫位于仿真前：`if (rows, cols, patches) != _S2 and not a.smoke: bad.append(...)`，符号锚点 `_S2 = (480, 960, 1700)`）。而载体 `p1c_density_sweep.build_cmd()` **从不传 `--smoke`**（`[实测]` 我用 D1 档实跑一证：`--patches 850` ⇒ `🔴 非判别装置 480x960p850——仪表冒烟请显式 --smoke`，仿真未开始即终止）。⇒ **D1/D2/D3 全部 12 run 会以 rc≠0 全数拒跑**（好是 fail-loud，不会产出坏数据；坏是白跑）。靶向 25 绿没抓到它，因测试冻结的是命令串本身（`test_build_cmd_frozen_string`）且探针子进程路径未真跑——**"守卫 = 实验变量"的设计冲突**：密度批的 `--patches` 正是被测变量，"非判别装置"是**常态而非冒烟**。

**建议修复案（一行级，征澜舟/镜/PI 择路）**：
- `build_cmd()` 内：`if patches != 1700: cmd += ["--smoke"]`（语义=显式声明非判别档；`verify_readback` 不查 `smoke` 字段，兼容；D0/复现门路径不变）；
- 同步 `test_build_cmd_frozen_string` 断言串（≠1700 档含 `--smoke`）+ 建议补一条"run-matrix 命令串 vs 探针守卫"的贯通测试（可用 ticks=5 微型档真跑子进程，防再次"测试绿而通路断"）。
- 择路：**首选澜舟出补丁**（载体归责，R382 代码审照走，镜快审+PI 合入）；若 PI 判"一行级免周转"，我可代提交补丁+测试同步，**由镜追审**。等裁期间我不改 main。

**其它 Pre-Flight 项**：C2 provenance=main 73ac3a9 ✅；C3 档间差异=patches 即变量 ✅（同 seed 跨档轨迹应不同，批后核）；C4/C5 readback 逐字段=载体 `verify_readback` 内置 ✅；C7 仪器中立性=复现门在跑（home-range 并装须逐字节等价既有列——门过即证）；**C8 前提对账**：① 斑块分布四档同型 `[代码]` `experiments/steady_k_probe.make_cfg()` 内 `c.resources.distribution = "patchy"`（探针 import 该函数，uniform 默认被构造期覆盖——R127 首例事故同族已排）② 富食格位置不可由纬度预测（`default_rng(patch_seed)` 随机中心流）③ 记忆机制未动（memory_v2=False/K4）④ 感知/信号开关未被削弱（readback 6 项锁定）。M1–M4：判据 🔒 N1；混淆剥离=只动 patches；坑账本无冲突；功效沿 Tier-1 4 seed 家规。

**当前不烧机时**：12 run 起跑挂起待修复裁量。**复现门进度**（非结果）：1700×207 同机对拍 run 跑到 **t≈2000/3000**（15:53 起，21/31 采样行），预计 ~16:05 完成；D0 档走 dm-guard 路径不受本缺陷影响。**过/不过结果与外推 wall 另帖追报**——在结果落地前，本帖任何"门已过"表述均不成立，判读/起跑均以追报为准。

— 砚（[实验员·科学主管]）2026-10-04 16:1x
