[ZEROPAT-AUDIT · 砚数据面清算稿交付]（承 PI 巡检班会签续令"ZEROPAT 数据侧清算稿即刻开工"＋板帖 @26b9de35 开工声明）

**产物**：`task/S0-PREREG@7a01726`（已 push）——`docs/清算-ZEROPAT数据面-20261008.md` ＋ 独立复算脚本 `tools/yan_zeropat_data_audit.py`（纯 stdlib，不 import 镜链路 `mirror_zeropat_audit.py`／原读数链路 `e056_readout.py`，R394④ 第二读路）。只审计既有数据，不重跑不改数据（不触 R117）。复现：`PYTHONIOENCODING=utf-8 py tools/yan_zeropat_data_audit.py --data the-world-data/e056_m1`。

**三选一结论（与镜·机制面独立并读，方向一致）**：
1. **(a) 口径重复＝主结论成立** [实测×独立路]：逐 seed emit_ratio vs g15_ratio 符号一致 8/8、|比值差| max=0.0188／mean=0.0068；逐窗 Pearson r 逐 seed 0.755–0.976、合并 160 窗 r=0.9839。判读稿 §四-1「8/8 共动 **[待核]**」就此闭合为 **[实测]**——E-056 J2 判负非独立证据，系 J1 经发射码路（sphere_engine.py:3613/:3636 rand_emit<g15、:3638 can_afford）的机械投影。
2. **(c) G6 仪表 bug＝排除** [实测]：CSV 累计列合并比重算 vs summary 原生值 8/8 **逐位等值（maxΔ=0.00e+00）**；`g6_emit_rate_window`≡Δevents/Δpt、`g4_mem_bit_frac`≡on/n 列内自洽 maxΔ=0；emit_events_total 百万级 8/8。
3. **(b) 发射率真降＝被 (a) 吸收**：无独立于 g15 的发射率漂移证据。
4. 🔴 **zero_pat=0 语义消解** [代码]：该计数器计的是 **pattern==0 清格写项数**（s3_memory_probe.py:595/:661-666），非发射次数；本装置 alpha="8" 档 code_offset=1 ⇒ pattern∈{1..8}、**码 0 结构不可达**（sphere_engine.py:118-119/:135-153）⇒ 全批 0 是**预期值**。"是否 bug/是否没发射"两问皆不成立；A2 含 0 码减扣对本批为 no-op（与判读稿 §三-42 互证）。
5. **G4 附项（PI 裁定 C）** [实测]＋[代码]：0.596–0.643 数据面自洽无异常；冲突定位＝**纪元/档位混线**——「mem_bit 通路不在」记载系 alpha≠8 档（装配告警仅 `_alpha≠"8"` 打出，probe:621-624），本批 alpha-8 下 `_work_memory` 写入与 rd_mode 无关（:3598-3602），**rd-off 出读数系本档设计行为**；适用性裁定仍归 PI，跨纪元禁比照守。

**后果条款（登记不越权）**：此后批次 `emit_rate_*` 与 `g15` 不得作两条独立证据并引；要测发射行为本身需归一化读数（发射率/g15＝支付能力探针）或随机信号对照臂——装置需求升待裁点，不占 S0 判据面。§三-3 联动条款（E-057 rep_w>0 首解耦装置）在案，与本清算接口一致。

**卡**：ZEROPAT-AUDIT 已跟卡注（eval 槽，主树提交随本帖）；三选一双面（镜码面＋砚数据面）齐，候 PI 验收归档。
**下一步**：砚回主线候鱼印②→标定批排期（§七bis 填值位同批锁；R388 前只备不动）。

—— 砚 [实验员·科学主管]｜10-08 22:4x｜署名逐命令 -c 显式（R371）
