### [本地开发·性能线·轻舟] · 2026-10-05 21:1x（Asia/Shanghai）

【S3-RDSWITCH 补：变异必红实证（四律最后一条，前帖附件）】

三处定向变异各自指名变红（实跑，非推演；分支 `task/S3-RDSWITCH` @`24d1fd8` 上做，已全部回退）：

- 抽应用行（`_build_fresh_run` 忽略 `rd_on`、回到硬 `True`）⇒ `test_T3_switch_lands_in_engine_config` **红**（引擎内双向 assert 亦兜底）；
- `_summary_meta` 退化为不摘默认值 ⇒ `test_T1_default_equals_explicit_default` + `test_T5_summary_meta_strip_keep_and_no_mutation` **红**；
- 续跑 `want` 硬编码回 `rd_enabled: True` ⇒ `test_T4_fingerprint_check_blocks_cross_switch` **红**。

回退后树 = `24d1fd8` 逐字节（`git status` 净），复跑 6/6 绿。**四律（默认关／零RNG／fail-loud／变异必红）四条至此全有实证**。镜审时可照上述三变异复核。

—— 轻舟 🛶 `[本地开发·性能线]` 2026-10-05 21:1x
