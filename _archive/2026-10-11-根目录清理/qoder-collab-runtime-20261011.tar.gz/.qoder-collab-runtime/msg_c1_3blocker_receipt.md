### [本地开发·性能线·轻舟] · 2026-10-05 22:44（Asia/Shanghai）

【C1-IMPLEMENT 三阻塞修复回执（R384 三要素）：C-A 启动期 fail-fast @582c1f0 / C-B 两处 append 对账守 / C-C T13 独立期望值，@镜复核三行】

**一、结果**

- **C-A（采 PI② 启动期 fail-fast）**：`a4_verify_capacity.py` 校验段加：计划窗数 `ceil(ticks/rd-sample-every) ≥ 3` 且 `import scipy` 失败 ⇒ `ap.error` **rc=2** 拒跑（报错点名 scipy、给两选一：装 scipy / 减窗 ≤2），崩溃不再留到跑完收尾段。`TestCAFailFast` 双互补例：
  - 无 scipy 档（本机可跑）：断言 rc=2 + 报错含 "scipy" + **未起跑**（主表/侧车一均不存在）——与旧行为"跑完收尾崩 rc=1 且侧车一已在"有明确区分度；
  - 有 scipy 档（本机 skip，随批环境自动生效）：同命令断言 rc=0 + 侧车二存在且 `rd_n_windows ≥ 3`。
- **C-B**：T11b 加镜指定一行 `assert len(log) == int(e._ec_prey_kill_n)`（默认档 site-1：seed221/100t 实测 52==52）。**另补 wound 档**覆盖 site-2——默认配置 `wound_enabled=False` ⇒ site-2 append 是死码，仅按一行修**挡不住"摘第二处 append"**的变异，故新增 `wound_enabled=True, wound_base=1.0` 真跑例（seed221/100t 实测 wounds=64、kill_n=54；覆盖自证断言 wounds>0 防配置退化）。
- **C-C**：T13 弃同义反复（原例用 `rd._cols` 重算同式）改**手算常量表**三档：①mini 60×120（带界 14|15、29|30、44|45；bincount 全 450）；②**非整除 61×125**（lat 带起 0/16/31/46——与"先整除"朴素方案档界不同，含 row=60 边界）；③**480×960 纯映射**（stub 世界，列宽 240≠120）。三档均带 bincount 聚合锚。

**二、summary（一句话）**

三处修毕：≥3 窗缺 scipy 启动即拒（rc=2、跑前拦）；两处 append 各有对账守（默认档+wound 档，M-site1/M-site2 分别必红）；T13 独立期望值三档封"同义反复+120 档宽盲区"。本分支不触 `s3_memory_probe.py`（与 G6/GAP-A 无文件面冲突），未动 main。

**三、产物/证据**

- 分支 `gitee/task/C1-IMPLEMENT` @ **`582c1f0`**（`fd032bf` 快进推；2 文件 +158/−13：`experiments/a4_verify_capacity.py`（C-A 块 +19 行）、`tests/test_c1_rd_instruments.py`）。
- 靶向：`tests/test_c1_rd_instruments.py` **37 passed + 1 skipped**（skip=有 scipy 互补例，本机无 scipy 就地 skip；无 scipy 档跑的即 fail-fast 例）。
- **变异四连（均实测，还原后树净）**：
  - M-CA（摘 fail-fast 块）⇒ 旧行为复现：rc=1 + 收尾段 `ModuleNotFoundError`（正是"侧车二/manifest/provenance 全丢"位置）⇒ 测试红；
  - M-site1（摘第一处 append）⇒ T11b + wound 档**双红**；
  - M-site2（摘第二处 append）⇒ wound 档**红**（len=35 vs 54，差 19=site-2 击杀）、T11b 绿=预期（默认档 wound 关）；
  - M-CC（`_cols` 写死 120 模拟历史硬编码回归）⇒ 61×125 与 480×960 两档红、mini 绿。
- 回归面：a4 改动被 `--rd-instruments` 门控（全仓仅本测试文件使用该开关）⇒ 对其他测试零可达；r98 扫描器失败集与 main 树**逐名一致**（15 个离线存量为存量件，非本 diff 引入）。

**四、下一步/遗留/交球**

- @镜：复核三行（C-A 拦截位置/rc 与"未起跑"断言；C-B 两档对账守含 wound 档覆盖论证；C-C 手算表独立期望 + 480×960 档例）→ 销项。
- @PI：R225 会签后合 main（本分支与 `s3_memory_probe.py` 不相交，合序无冲突）；合后 C1 起跑令归砚（起跑令预留"C1 单臂 ⇒ T15 批内 N/A"）。
- 遗留（如实报）：①有 scipy 互补例在本机 skip，随有 scipy 环境自动生效；②C1 正式批 sample=250、60k tick ⇒ 窗数远超 ≥3 ⇒ **批量环境必须装 scipy**，否则新 fail-fast 会在起跑时直接拒跑（这正是它要拦的位置；正式批前请确认环境）。

—— 轻舟 🛶 `[本地开发·性能线]` 2026-10-05 22:44
