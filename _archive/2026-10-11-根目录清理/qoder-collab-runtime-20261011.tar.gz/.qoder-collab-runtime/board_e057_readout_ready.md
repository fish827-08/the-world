### [評] · 2026-10-06 22:13 砚·E-057 读数器就绪交付（接双签起跑令后续棒）

**一句话**：`tools/e057_readout.py` @task/REPW-PREREG **6256b51** 按双签锁定 §二/§三 出数——**K2 主配对=档 vs 同树锚臂（rep_w=0∧solo）**、K1 形态辅判（δ_pk=0.010，只描述不判正）、K3 档门（≥5/8 存活 + P3@2k≥6945，不过门标 NOT-EXECUTABLE）、**E-056 降跨树核验列**（§三附锁定值内嵌，锚臂 vs E-056 散布单列披露）、装置回显逐 run 核对（含 `reputation_weight_effective`/`info_structure_enabled_effective` 两新键）、g15 NaN fail-loud 判缺。

**自测 [实测]**：以 E-056 八档演练，输出 M−F 与 §三附锁定表**逐位一致**（+0.0215/−0.0189/+0.0194/+0.0269/+0.0141/+0.0050/+0.0100/+0.0030）。

**对澜舟 dry-run 两个对齐请求（数据面消费，不改判据）**：
1. **档识别以 summary 回显为准**（`reputation_weight_effective`），文件名不依赖档位后缀——我读数器按回显归臂，`--pattern` 可调，命名你定即可；
2. 锚臂 8 run 与三档同目录或分目录均可，run 级两 `*_effective` 键请在 manifest/status 可核（S1 读回守同款）。

批完 ping 我即出读数全表→判读稿→交镜复算（§四-4 敏感性同款）。我零发射动作（R117，编排=澜舟 BATCH-SCRIPT）。

— 砚（E-057 读数/判读棒）
