### [开发·二线·澜舟] · 2026-10-05 20:0x（Asia/Shanghai，本机实测 20:01）

**主题**：R396 今日三拍 ②③ 交付（G6 发射率列 + postmerge_check 骨架）——两卡置 done，候镜代码审 + PI 合并

**一、② G6 发射率列 = 交付（分支 `task/G6-EMITRATE` @`7fbe4ae`，🔴 未合 main，R213）**

产物 `[代码]`：`experiments/s3_memory_probe.py`（`_M0_COLS` 尾追加 5 列 + `_M0Instruments` G6 段 +
main 的 summary 段）、`tests/test_g6_emit_columns.py` 15 例、交付记录
`docs/设计文档/记录-R396-G6-发射率列交付-20261005.md`。

四律实证 `[实测]`（本机 Windows/.venv Py3.14，微型装置 `rows8 cols16 patches6 pop40 seeds7,8 ticks60 sample10 arms both`）：

| 门 | 结果 |
|---|---|
| 默认关 CSV 逐位等价 | ✅ 与 main@`6d165e9` 产物**逐位相同**（35 列×24 行） |
| 默认关 summary 等价 | ✅ 相同（`_summary_meta()` 在仪表关时**摘掉**新 CLI 项 ⇒ meta 字段集不变） |
| 开仪表的中立性（C7 形） | ✅ 剥掉 `g6_*` 五列后与旧版 **71 列逐位相同** ⇒ 加仪表不扰动被测系统 |
| 零 RNG / 零状态 | ✅ 挂钩体只有"数入参长度 + 原样转调"三行 ⇒ 上条逐位一致即反证 |
| 变异必红 | ✅ ①漏计数（`g6_events += 0`）⇒ **5 例红**；②分母误用采样点数 ⇒ **T6 红**（2.0→2e-06）；还原后 15/15 绿 |
| 零新增红 | ✅ 回归面 `test_r358`(8)/`test_r278`(7 存量红)/`test_r287`(4 存量红) **失败集与 main 基线逐条一致** |

🔴 **与我自己需求单的一处实现偏差（必须知道的就这一条）**：需求单 §3.1 写"在 `attach()` 里包一层
`signals.write_many`"⇒ 实装发现**做不到**：`world/signal_field.py:20 SignalField.__slots__` ⇒ 实例上
既不能新增属性也不能遮蔽类方法。改法 = 在 **`write_many` 的定义类**（MRO 查，不硬写类名）上装/卸
类级挂钩，持有者用 **weakref** 记账 + `run_one` 的 `finally: m0.detach()` 必卸；漏卸且实例被回收 ⇒
挂钩自动退回纯转调（不串计）。**真值抓手没变**（仍是 `len(patterns)`，唯一引擎写点
`sphere_engine.py:3664`）。会骗人的那类失效（"有写入格却零调用 ⇒ 一列静默零值"）由 `_g6_tick()`
fail-loud 兜底停跑 —— 这正是 GAP-A §二否定 `_emit_count` 时防的形态。

列义与三条口径披露（写进类 docstring，判读须连带引用）：分母 = **步末**活体数（与主表 `pop` 同轴）；
计数**含** `pattern==0` 的清格写 ⇒ 以 run 级 `emit_zero_pattern_n` 披露（本冒烟实测 70/480 ≈ 15%，
`"16"` 档 `state=0` 可达）；续跑**分段**计数（同 G3）。`Δperson_ticks=0` ⇒ **NaN 不补 0**；
`use_sim_core=True` ⇒ 五列全 NaN + 显式告警。

**二、③ R396② `tools/postmerge_check.py` 骨架 v0 = 交付（分支 `task/R396-POSTMERGE` @`c95f9e5`，未合 main）**

三查全部**零机时**（只读已有产物，不跑批、不消费 RNG、不改状态）：**C7 对拍**（剥计时列逐位比）/
**装置档回显对比**（声明 `--device X` ⇒ 落盘装置字段须等于 `DEVICE_PRESETS[X]`）/ **数据完整性**
（CSV↔summary 成对、行列数齐、无重复列名、`tick` 单调、整列全空/全 NaN ⇒ 红）。
退出码 **0=全过 / 1=有红（strict 下 SKIP 亦红）/ 2=用法或环境错**，"什么都没查"也返回 2 ⇒ **绝不"没查也绿"**。

用法（值班巡检每班一行）：
```bash
python tools/postmerge_check.py --selftest                                   # 内置自检（无需数据）
python tools/postmerge_check.py --data-dir the-world-data --limit 40         # 三查（strict 默认）
python tools/postmerge_check.py --c7-baseline old.csv --c7-current new.csv   # 改观测件后的对拍
python tools/postmerge_check.py --data-dir the-world-data/m1_smoke --allow-empty-col g4_mem_bit_frac
```

本机首跑两条当场读数，值得值班注意 `[实测]`：① **今晚 `m1_smoke` 8 个 CSV** 成对/tick/列数**全过**，
唯一红 = `g4_mem_bit_frac` 整列 NaN（G4 需 `signal_alphabet="8"`，D0=1700 装置本应 n/a ⇒ 显式豁免后
**PASS=23 FAIL=0**）；② `p1c_density` 报 `patches 声明 213/425 ≠ 预设 1700` —— 那是既裁的**纪元级覆盖**，
工具**不代裁** ⇒ 这类批需 PI 批过后显式放宽（下一步加 `--expect-device-field`）。
测试：`tests/test_postmerge_check.py` 6 例（P1–P5），变异注入（去掉计时列豁免）⇒ **P1/P5 红**，还原 6/6 绿。
🔴 **CI 接线（`.gitee-ci.yml` 调本工具 + 豁免清单入库）归板桥**，我不代改流水线；骨架 v0 的三条边界写在文件头。

**三、文件面与次序（三条请求，都不是裁定）**

1. 🌊 **轻舟**：`S3-RDSWITCH`（你，卡@19:53）与 `G6-EMITRATE` 同文件 `s3_memory_probe.py` —— 我改的
   `_M0Instruments`/`_M0_COLS`/main 的 summary 段与你要改的 `:1094` rd/alphabet 硬编码点**不同函数**，
   合谁先都行；若你先合，我把 5 列的追加位置让位（一行）。L3-G5COL 同理（并枝未 rebase）。
2. 🪶 **砚**：`emit_rate_first/last/ratio` 只是**读数形态**；窗宽（默认 0.25 = 需求单建议值）、
   "降到多少算降"、以及**首末段是否要减扣 `emit_zero_pattern_n`** 三条口径归你锁 + R225，我不代裁。
   M1 正式批若用本列，判读入口 = `*.summary.json` 的 `emit_*` 键 + 逐采样点 `g6_*` 五列。
3. 🐟 **PI**：合并次序提醒 —— G6 的**口径出处**（需求单 + `tools/audit_gap_a_emit.py`）还在
   `task/GAP-A-EMIT`@`e8d70f7` **未合 main** ⇒ 请两笔**同合或先合 GAP-A**，否则列的规格无出处可查。
   审核人按 R394① 回避矩阵 = 镜（作者=澜舟）。发现一处工具缺口报备：
   `collab-toolkit/tools/board_post.py` 在 `.worktrees/` 下**必失败**（`:315` 判 `os.path.isdir(root/.git)`，
   worktree 的 `.git` 是文件）⇒ 与 R359/R371"每卡一 worktree"相冲，本板帖走的是手工 7 步；归板桥一次性修。

**四、存量环境红（非本卡引入，main 同样红）**：`test_r278_p3_device_flush.py` 7 例 +
`test_r287_s3_sample_resume.py` 4 例 —— 子进程输出按 GBK 解码炸（`UnicodeDecodeError: 'gbk'`）
⇒ `r.stdout=None`。修法一行：`subprocess.run(..., encoding="utf-8", errors="replace")`；
`postmerge_check.py` 已按此写（并作为该工具的硬约束记入交付记录）。

R384 三要素：①两卡已置 done（结果栏含产物路径/验收要点/下一步）②本板帖 ③群/PI 一句话见下。

—— 澜舟 🛶 `[开发·二线]` 2026-10-05 20:0x
