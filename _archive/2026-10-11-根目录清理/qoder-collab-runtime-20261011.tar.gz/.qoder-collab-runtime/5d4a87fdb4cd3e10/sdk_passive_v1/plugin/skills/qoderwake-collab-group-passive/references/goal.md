# Conversation Goal

Use the Goal ID and version in the current Run input. When the runtime designates
you to create a missing Goal, choose its initial 1..96 public member-Message budget
for the whole task. Budget at least two public Messages for each independently
assigned member-work item (receipt/start and completion), then add public handoffs,
material progress, coordinator synthesis, and final delivery. Add about 35% headroom
and round up; multi-member work must not reuse default 20 as its estimate. Private
messages do not consume this budget:

```sh
<cli> goal mutate <convId> --action create --content "<user-facing delivery objective>" --turn-limit <n> --json
```

Read the current version before any later mutation:

```sh
<cli> goal get <convId>
```

Mutations other than `create` require the exact `id`, `generation`, and
`revision` returned by the latest read. A conflict means another Run changed the
Goal; read again and reconsider instead of overwriting it.

```sh
# Refine an active Goal or its 1..96 public member-Message budget.
<cli> goal mutate <convId> --action update --goal-id <goalId> --generation <n> --revision <n> --content "<objective>" --turn-limit <n> --json

# Complete only after this canonical Message delivered the needed result to the human.
<cli> goal mutate <convId> --action complete --goal-id <goalId> --generation <n> --revision <n> --result-message <messageId> --json

# Stop automatic checks while waiting or blocked.
<cli> goal mutate <convId> --action pause --goal-id <goalId> --generation <n> --revision <n> --reason <reason> --json

# Resume a completed or paused Goal for a substantive follow-up.
<cli> goal mutate <convId> --action reopen --goal-id <goalId> --generation <n> --revision <n> --content "<updated objective>" --turn-limit <n> --json
```

Pause reasons are `user_stop`, `awaiting_user`, `turn_limit`, `no_progress`,
`execution_error`, and `leader_unavailable`. Do not increase the turn limit only
to evade an exhausted budget. Goal commands are authorized by the current Run
token and cannot target another Conversation.
