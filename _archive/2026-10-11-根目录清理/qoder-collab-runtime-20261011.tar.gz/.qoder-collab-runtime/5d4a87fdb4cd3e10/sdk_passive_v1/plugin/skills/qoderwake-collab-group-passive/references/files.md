# File locations and transfer

For visibility and delivery requirements, see the Group Collab protocol's
**Privacy** and **Delivery** sections.

## Runtime layout

```text
<conversation-workdir>/
  workers/<waker-id>/   default private cwd
  shared/              shared writable output directory
<managed-default-conversation-dir>/attachments/<waker-id>/
                       private materialized attachment input cache
```

A member workspace override can replace the default cwd. `QODER_WORKSPACE`
identifies that private workspace; it does not relocate the shared directories.
The attachment cache stays under the managed default Conversation directory,
even when a Conversation or member workspace is overridden. The executor receives
the shared directory and only its own attachment cache as additional directories;
only the shared directory is an artifact output root. Use the absolute paths
provided by this Run, not an inferred attachment parent or another member's cache.
A path under another member's private cwd is not an exchanged file location.

For shared code, use one repository clone under `shared/` and a separate git
worktree under each participating Waker's private workspace. Worktree paths
remain private; exchange committed changes through the shared repository.
Moving an existing file changes paths held by others, so coordinate relocation
with its owner before moving it.

## Attachment commands

```text
<cli> messages send <conversation-id> --text "<file description>" --not-mention --file <absolute-path>
<cli> messages attachment download <conversation-id> <message-id> <attachment-id> [--out <absolute-path>] [--json]
```

Send arguments and response fields are in [Messaging](messaging.md).
The Run lists local paths for attachments successfully materialized from its
delivered Messages, including later interjections. Use the Message and attachment
IDs to download any files not listed locally.

Without `--out`, a managed Run downloading in its current Conversation uses
`QODERWAKE_CONVERSATION_ATTACHMENTS_DIR` when supplied as an absolute path.
Older Runs without that path use the default Conversation directory's
`attachments/participants/<participant-id>/`, falling back to the same suffix
under cwd when lookup fails. Human CLI calls instead use the Conversation
workdir's `attachments/`, or cwd's `attachments/` on lookup failure.
The returned path identifies the actual destination.
Identical content reuses a file; different content with the same name receives
a hash suffix. If filename lookup fails, the command asks for an explicit path.

An explicit `--out` writes that exact destination and can overwrite an existing
file. JSON output is `{ path, sizeBytes, attachmentId, messageId }`. Materialized
files persist beyond the Run; attachment IDs themselves are not local paths.
