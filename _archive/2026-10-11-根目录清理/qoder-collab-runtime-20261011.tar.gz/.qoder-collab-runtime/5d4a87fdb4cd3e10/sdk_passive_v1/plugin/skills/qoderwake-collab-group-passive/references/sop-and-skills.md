# Persisting procedures and capabilities

Read this when a request includes creating, changing, or binding durable group
configuration. A question about current configuration can be answered without
performing those operations.

## Choose the owner

| Requested scope | Product surface | Operation |
| --- | --- | --- |
| This Group's roles, handoffs, approvals, order, or completion process | Group SOP | Publish a catalog release, then bind it to the Group |
| Reusable knowledge, tools, or methods shared by this Group | Group Skill | `skill manage --conversation-id` |
| One Waker's durable capability across Groups | Waker Skill | `skill manage --waker-id` |
| One Waker for this assignment only | Temporary overlay | Requires explicit runtime support; the persistent commands below do not supply expiry |

Classify the requested content, not just the term "skill". A request combining
coordination semantics and working methods belongs in an SOP. Product-wide
mechanisms remain in the Group Collab protocol; this file describes storage and
authoring operations for the requested scenario.

## SOP authoring and binding

1. Scaffold a template document:

```text
<cli> sop init <template-file> --skill-id <kebab-id> --version <semver>
```

2. Edit its `template.body` and any needed parameter definitions. Keep the
   generated camelCase keys, including `skillId`, `version`, and `template`.
   `template.body` is a JSON string; serialize the edited document as JSON.
   Validate before publishing:

```text
<cli> sop validate <template-file>
<cli> sop build <template-file> --output <new-preview-directory>
```

   The build command is an optional local preview and requires a new output
   directory. Validation reports that the template is valid or returns a field
   or JSON parsing error.

3. Inspect the catalog and publish the immutable release when needed:

```text
<cli> sop list --json
<cli> sop publish --file <template-file> --json
```

4. Read the current ordered bindings:

```text
<cli> group sop list <conversation-id> --json
```

5. Submit the full desired binding list:

```text
<cli> group sop set <conversation-id> --sop <skill-id@version> [--sop <other-skill-id@version> ...] [--param <selector.key=value> ...] --json
```

`group sop set` atomically replaces the complete list with revision checking.
When adding or updating an entry, preserve unchanged versions, order, and
parameter values. Catalog publication and Group binding are separate results;
a local draft or a published-but-unbound release is not active in the Group.
When the request is to put a new SOP into use in this Group, verify the final
binding with `group sop list`. If the request only authorizes a draft, or binding
is unavailable or fails, report the unbound state and remind the human that
binding is still needed; do not describe publication alone as activation.

The CLI resolves both a Group task Conversation ID and a Discussion ID through
the owning Group's surface nodes. Use the current Conversation ID; resolving its
Group does not grant permission to modify it. A lookup or permission failure does
not change the requested storage owner. Correct the handle or report the failed
operation.

## Group Skill operations

Draft the skill content in a local file, then create it with:

```text
<cli> skill manage --conversation-id <conversation-id> --action create --skill-name "<name>" --content-file <absolute-draft-path> --summary "<change summary>"
```

`--conversation-id` and `--waker-id` are mutually exclusive. A successful change
returns `status="applied"`; a rejected or conflicting result is not an applied
change. Existing skills support `patch`, `edit`, `write_file`, and `remove_file`;
`--dry-run` previews the requested modification.

Pin fields and their snapshot lifecycle are described in
[Runtime fields](runtime-awareness.md).
