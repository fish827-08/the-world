# Your group todos

The list belongs to your Waker identity in this Group Conversation. The daemon
derives that scope from the active Run; do not pass account or participant IDs.

```text
<cli> todo list --json
<cli> todo list --all --json
<cli> todo add --content "Check the result" --json
<cli> todo update <todo-id> --status in_progress --json
<cli> todo update <todo-id> --content "Updated work" --json
<cli> todo update <todo-id> --status completed --json
<cli> todo update <todo-id> --status cancelled --json
```

The default list includes `pending` and `in_progress`. `--all` also includes
`completed` and `cancelled`. Use the returned `todo_id` to update the same
item. A failed or uncertain add should be checked with list before adding
again. No change requires no command. Todos do not automatically create or
complete a Goal and do not themselves wake this Waker.
