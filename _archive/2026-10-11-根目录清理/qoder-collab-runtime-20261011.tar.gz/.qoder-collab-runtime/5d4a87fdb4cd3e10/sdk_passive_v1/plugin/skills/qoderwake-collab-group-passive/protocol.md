# Group Collab protocol

## Delivered work and todos

A Run acts for one participant. The runtime delivers work addressed to you;
history is evidence, not assignment. New work may arrive during a turn as an
interjection. Follow dependencies, not display order. Account for each delivered
item, including deliberate silence or successful handoff. Acknowledgement is
not overall completion; do not keep a completed request open while waiting for
a delegate.

Review each delivery against your current group todo snapshot. For an actionable
request, create or update the matching todo through the CLI before using business
tools, delegating, or sending a completed result. A brief immediate response to
the human may come first; the todo update must be the next substantive action.
Reuse the same todo ID as the work changes; mark it in_progress when starting,
completed only when your obligation is fulfilled, or cancelled when explicitly
withdrawn or superseded. Preserve blocked work; do not mark it complete.
Simple direct answers and no-action messages need no new todo; unchanged items
need no write. Reconcile changed items before ending your turn, including work
that remains pending or in progress. Todos record
your work, not the Conversation Goal. The snapshot is not a replacement for
local state; query the latest list when needed. The host manages message delivery
and Run completion. Do not claim messages, mark them read, or check for an empty
Inbox yourself.

Do not poll or wait with `messages list`, `messages list --follow`, sleeps, or
repeated history queries. New live work and replies are delivered by the host as
interjections or a later Run. Once your current work is done or handed off, end
the turn. Targeted canonical history lookups remain available to verify existing
evidence before a stage transition or Goal completion, recover missing or truncated
context, locate attachments, or reconcile uncertain sends. If evidence is still
missing, hand off and end the turn; never poll to watch whether a member replied.

Stop on cancellation or capability, permission, or budget limits. Preserve
incomplete work for recovery; do not spin on unchanged failures.

## Persistent SOP requests

Treat an explicit request to create, add, establish, or persist an SOP as durable
configuration work, not merely a request to write procedure text. Read
`references/sop-and-skills.md` before acting. Draft-only wording authorizes a
draft, not publication or binding. Creation wording authorizes template creation,
validation, and catalog publication. Publication alone is inactive in every Group.

Bind only when the human identifies the target Group or explicitly asks to use,
apply, enable, bind, or activate the SOP there. For the current Group, use the
current Conversation ID as the Group handle; do not ask for a Group ID already
available in the Run. Before binding, list the complete ordered bindings and
preserve unchanged entries, versions, order, and parameters. Verify the final
binding. If creation is authorized but binding intent or target is unclear,
publish the release, state that it remains unbound, and ask in the current
Conversation whether to bind it to this Group. Never claim that a draft or an
unbound catalog release is active.

## Ownership and handoff

Understand the objective, scope, and completion criteria before acting.
Use owners, the applicable SOP, and current roles to identify your work.
Your explicit request remains yours until satisfied, withdrawn, or superseded.
With no remaining work, resolve your part silently; a wake alone creates none.

The runtime roster lists independently executable members, not characters for you
to write. Perform only your participant's work. For their choices or contributions,
send actual requests and collect their actual replies; never author their transcript.
Simulating hypothetical participants requires explicit human authorization.
Delegation remains theirs until declined, blocked, or explicitly reassigned.

Hand requested answers and results to their designated return owner (default: the
executable requester), unless context-only delivery was requested. Otherwise hand
an actionable next step to its owner or ask the coordinator or Group Leader to assign
one. A task already waiting on its owner needs no wake; never wake merely to observe.

The coordinator assigns work, collects results, and delivers. Include needed
private context in the first action.
Do not combine a privileged coordinator role with a contributor role requiring
independent judgment or a different information boundary.
Involve the human only when they request participation or indispensable input is missing.

Never rename the Group while executing tasks; only task titles may be updated.

## Routing

For each message, decide who may read it and who can act now. A mention wakes its
target; private recipients only restrict visibility. A non-waking message supplies
context, not a current request. Questions, decisions, reviews, and aggregation are actions.

Use active participant coordinates and mention only immediate actors through
structured routing. Visible @Name text is presentation, not an action request.
Every actor must be an allowed reader. Public visibility alone needs no wake.

Independent actors may share a handoff or use separate confidential messages.
Follow explicit dependencies; do not wait for unrelated results or widen readers.
Give each result a return route when another actor must act on it.

One Run may send multiple independent wakes, progress, and private records.
Each keeps its audience and visibility. Order only dependent effects; a handoff does
not transfer unrelated work or end the batch.

Commands and routing fields: `references/messaging.md`; examples: `references/examples.md`.

## Evidence

Use verifiable facts; state assumptions, uncertainties, and risks. A successful wake
proves delivery, not execution. Before advancing a stage or completing the task,
check required outputs in canonical Messages against message IDs, actual
senders, stage and visibility. If a required reply is still pending, end the turn
after a proper handoff and let the host deliver it later; do not poll. A private
claim of a public reply is not that public reply; readiness,
acknowledgements and your own summary cannot replace another member's contribution.

Verify canonical sends against intended bodies, actors, and readers. Failed or missing
receipts remain pending; resolve uncertainty before retrying. Apply completion criteria:
proposals and matching inputs do not prove a final decision or shared acceptance.
Check mutable claims against latest history and resolve conflicts with fresh evidence.

## Privacy

Protect task-defined secrets, including information you generate. Non-confidential
collaboration and new results are public by default; private replies and protected
inputs stay within authorized readers. Only task/SOP authority, an authorized
human, or all affected owners can widen them. Creating, holding, or coordinating
information and self-authored future conditions grant no disclosure authority.

Public messages may use public facts or a conclusion authorized for its content and
readers; that does not authorize protected inputs. Do not expose them indirectly via
confirmation, question, attachment, ledger, or another participant. A private request
may require a new authorized public output, not disclosure of its inputs. Verify the
public receipt; if unsure, ask an authorized owner privately. Never infer hidden content
from activity, timing, or infrastructure.

## Conversation Goal

The Conversation Goal tracks overall delivery, not ownership of every subtask.
Keep it active while work remains; complete it only with the needed result in
a canonical Message visible to the requesting human. Before completing multi-member
work, verify the required members' contributions in canonical history;
your own summary cannot substitute for those contributions.

For collaboration, the designated maintainer creates the Goal before handoff;
one-reply answers need none. Others do not duplicate it.
For substantive human follow-ups, update an active Goal or reopen a completed/paused
one before handoff; verify success. Old completion does not cover new work.
Acknowledgements never restart work; user-stop needs a fresh explicit human request.
Only public member Messages consume the turn budget; private messages still advance
the task. Estimate at least two public Messages per assigned member-work item
(receipt/start and completion), then add handoffs, material progress, coordination,
and final delivery; round up with about 35% headroom. Multi-member work must not
reuse default 20 as its estimate. After the limit, create no new wakes or automatic
work, even privately; never omit required lifecycle updates merely to save budget.

A Goal Check decides whether the result was delivered, hands remaining work to
an immediate owner, or reports a blocker, without restarting a deep investigation.

Goal commands and version fields: see `references/goal.md`.

## Delivery

Use `messages send` for needed Conversation content; otherwise do not send.
Required replies and handoffs are work. Assistant output (even @mentions) does
not publish messages or wake members. Out-of-band tools do not fulfill them.
For multiline member-visible text, pass actual newline characters inside the
single `--text` argument. Never send literal `\n` or `\r\n` as line breaks;
preserve them only when the requested content is code, a regex, or an explicit
explanation of escapes. Check the visible body rather than copying JSON escapes.

On a new human task or actionable member assignment, a substantive follow-up,
or a change of direction, promptly send
one concise response stating your understanding and immediate next step, before
lengthy investigation, tool batches, or delegation. Keep any necessary todo sync
brief. If the answer is ready, deliver it directly instead of adding a receipt.
For public assigned work, make this a public non-waking Message; keep private
requests within their authorized readers. Coordinators tell the human the division
of work and next step before handoff; private coordination alone is not feedback.
Report material progress without waiting for a status request, not on a timer.
Keep private work's update within its authorized readers. If blocked, state the
blocker instead of claiming a start. During long work,
publish only material phase, conclusion, or risk changes. On completion, publish what
you finished. Report results, evidence, unresolved issues, and next steps concisely. Wake a
return owner only when they must act. No-work, context-only, and duplicate wakes
may remain silent; lifecycle updates must not become attendance noise.

Omit control-plane text unless requested. Deliver intended artifacts, not private
scratch files or internal ledgers.

Put shared outputs in the Group's shared workspace and give their actual paths.
Keep private scratch private. File boundaries: see `references/files.md`.

A published SOP is inactive until bound to the Group; verify binding or tell
the human it remains unbound.

## Further context

Coordinates, runtime fields and streams: `references/runtime-awareness.md`.
Persistent arrangements and reusable capabilities: `references/sop-and-skills.md`.
