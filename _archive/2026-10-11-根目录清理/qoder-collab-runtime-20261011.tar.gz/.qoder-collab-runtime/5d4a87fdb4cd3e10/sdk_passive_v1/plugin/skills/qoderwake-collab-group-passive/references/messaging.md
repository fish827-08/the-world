# Message commands

For recipient decisions and evidence requirements, see the Group Collab
protocol's **Routing** and **Evidence** sections.

## Sending

The current Conversation's send API is exposed by this CLI command. External IM
tools address different channel/bot coordinates, not the `conv_*` stream below.

```text
<cli> messages send <conversation-id> --text "<body>" (--mention <member> ... | --not-mention) [--private-to <member> ...] [--intent chat|ask|notify|request_action] [--reply-to <seq-or-message-id>] [--if-latest <seq>] [--file <absolute-path> ...] [--image <absolute-path> ...] [--json]
```

| Parameter | CLI contract |
| --- | --- |
| `--text` | Non-empty body; optional with attachments; for line breaks see [Multiline text](#multiline-text) |
| `--mention` | Repeatable; resolves to `audience`; sets `deliveryPolicy="wake"` |
| `--not-mention` | Selects `deliveryPolicy="store_only"`; exclusive with `--mention`; sends on the first invocation |
| `--private-to` | Repeatable; readers are sender plus these IDs; audience must be within that set. Omitted means public, even with a single `--mention` |
| `--intent` | Display classification; defaults to `request_action` with mentions, otherwise `chat`; all classifications may accompany mentions and do not change routing |
| `--reply-to` | Message ID or visible seq; numeric seq is resolved to a Message ID |
| `--if-latest` | Local compatibility Kernel only: compare-and-send against the sender's latest visible seq; conflict code `MESSAGE_NOT_LATEST`. Cloud Conversations reject it before publication with `CONVERSATION_IF_LATEST_UNSUPPORTED` |
| `--file` | Repeatable upload through the attachment API; see [Files](files.md) |
| `--image` | CLI inline image input: png, jpg, jpeg, gif, webp; cloud Conversations currently reject inline bodies, so use `--file` there |
| `--json` | Emits the response object described below |

Recipient lookup checks participant ID, then Waker ID, then unique
`wakerSnapshot.name`. A current `cpart_*` ID avoids duplicate-name and display
alias ambiguity. The CLI fetches current membership for directed sends.

Reading history before sending is not an atomic guard. Continue ordinary cloud
collaboration from current evidence; if an action requires atomic compare-and-send,
report that capability gap and leave only that dependent action pending. Do not
silently remove a required guard or block unrelated work.

Visible @Name text is presentation only, including quotations, code and fixed
formats; structured mentions determine routing. A private reply reference is
not an automatic visibility setting. Numeric `--reply-to` warns when quoting a
private Message publicly; ID-form references do not perform that warning lookup.

### Multiline text

`--text` preserves the string passed by the shell; it does not decode escape
sequences. For paragraph or list breaks, put real newline characters inside one
quoted argument, not the two characters backslash and n.

Correct (Bash/zsh; Reviewer is assigned the review):

```bash
<cli> messages send <conversation-id> --mention Reviewer --text '@Reviewer, review these findings:
- Build passed.
- One warning remains.' --json
```

Incorrect for the same three-line message: these literal `\n` sequences stay visible.

```bash
<cli> messages send <conversation-id> --mention Reviewer --text '@Reviewer, review these findings:\n- Build passed.\n- One warning remains.' --json
```

If code, a regex, or an explanation intentionally contains literal `\n`, preserve
it; do not replace backslashes indiscriminately. JSON tool inputs and receipts
escape real newlines as `\n`, while `\\n` encodes a literal backslash and n;
distinguish the decoded text from its JSON representation.

## Response fields

The CLI emits `{ "message": { ... }, "deliveries": [...], "replayed": false }`.
The `message` object uses the local API names:

| Field | Value |
| --- | --- |
| `message.id`, `message.seq` | Committed Message coordinates |
| `message.body.text` | Returned member-facing text |
| `message.audience[].participantId` | Resolved action recipients |
| `message.privateTo[].participantId` | Explicit private readers; absent or empty means public |
| `message.deliveryPolicy` | `wake` or `store_only` for these commands |
| `message.replyToMessageId` | Quoted Message ID, when present in the receipt |

These are not the remote wire names `content.text` or `private_to`.
Body text containing an `@name` does not populate `message.audience`;
`--reply-to` does not select action recipients. The current cloud Run adapter
does not forward this quote field; check the returned Message for its presence.
That adapter also returns `deliveries=[]` and `replayed=false` as placeholders,
not recipient execution status.
The sender remains visible implicitly; explicitly selecting only the sender in
`privateTo` represents a self-private record.

## Rejection and uncertain delivery

CLI validation errors occur before publication. Fix a rejected routing, visibility,
or content argument before retrying. `--not-mention` itself does not require a
confirmation retry.

Every invocation creates a new idempotency key. After an uncertain network
outcome, inspect recent Messages before invoking send again; a new invocation
is not a guaranteed replay of the first. The bridge recognizes an exact replay
of its last Message, but this is not a general duplicate-search facility.
The host manages delivered work and Run completion; inspect canonical history
before retrying an uncertain publication.

## History and Run controls

```text
<cli> messages list <conversation-id> --after-seq <seq> --limit <n> --json
<cli> runs list <conversation-id> --json
<cli> runs cancel <run-id> --json
```

`--after-seq` is exclusive and results are ascending by seq. A Message's seq is
stable even when private Messages leave gaps in what this participant can see.
`messages list` returns canonical Message history. Cancel operates on a Run ID
rather than a Conversation ID.

For permitted history lookups and the passive delivery boundary, see the
[protocol](../protocol.md#delivered-work-and-todos).
