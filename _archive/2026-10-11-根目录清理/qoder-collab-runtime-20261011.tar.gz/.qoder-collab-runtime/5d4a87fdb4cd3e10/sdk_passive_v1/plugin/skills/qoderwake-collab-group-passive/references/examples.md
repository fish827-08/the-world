# Routing command examples

For the decisions behind these commands, see the Group Collab protocol's
**Routing** and **Ownership and handoff** sections.

Examples assume unique current roster names Alpha and Beta. Substitute actual
names, IDs, paths, and the Run's `<cli>` prefix. For non-waking sends and responses, see [Messaging](messaging.md).

## Independent inputs requested now

```text
<cli> messages send <conversation-id> --text "@Alpha produce the first requested input. @Beta produce the second requested input. Return each result to me." --mention Alpha --mention Beta --json
```

## Private request to one member

Here the sender is Beta, the immediate actor is Alpha, and Beta receives the later
reply. Only Alpha has an @ marker; Beta is a plain name inside the instruction.

```text
<cli> messages send <conversation-id> --text "@Alpha inspect this private material. Reply privately to Beta with your finding." --private-to Alpha --mention Alpha --json
```

## Private result returned to its requester

For a private request from Alpha, the reply keeps an explicit private reader;
the mention alone would produce a public reply.

```text
<cli> messages send <conversation-id> --text "@Alpha my finding is <supported private result>. Please use it for the next decision." --private-to Alpha --mention Alpha --json
```

## Requested confirmation returned to its requester

Given a current request from Alpha for your confirmation before Alpha's next
step, after you have checked the requested material:

```text
<cli> messages send <conversation-id> --text "@Alpha I have checked the requested material and confirm it. You can proceed with your assigned next step." --mention Alpha --json
```

## Guarded statement in the local compatibility Kernel only

This example requires the local compatibility Kernel, not a cloud Conversation.
Given a conclusion established from Messages visible through `<evidence-seq>`:

```text
<cli> messages send <conversation-id> --text "<supported conclusion>" --not-mention --if-latest <evidence-seq> --json
```

The response's `message.body.text`, `message.audience`, and `message.privateTo`
are illustrated in [Messaging](messaging.md); todo operations are in
[Todos](todos.md).
