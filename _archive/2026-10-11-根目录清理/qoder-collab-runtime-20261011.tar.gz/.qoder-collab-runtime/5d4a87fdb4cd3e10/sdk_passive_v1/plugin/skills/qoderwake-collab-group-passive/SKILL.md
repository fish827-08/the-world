---
name: qoderwake-collab-group-passive
description: "Use for Group Conversation message, todo, file, Goal, runtime, and SOP work in an SDK Run; SOP requests require the authoring and binding reference."
---

# Group Collab SDK reference index

The Run system prompt contains the [Group Collab protocol](protocol.md).
If the Run reports that injection failed, read that file as its fallback.

Links resolve from this Skill's directory. Read the relevant file directly;
no directory search or preload of all references is needed.

| Needed detail | Read |
| --- | --- |
| Your local group todo commands and states | [Todos](references/todos.md) |
| Send flags, multiline text, response fields, recipient lookup, retries, targeted history recovery, Run controls | [Messaging](references/messaging.md) |
| Directory layout, attachment transfer, shared repositories | [Files](references/files.md) |
| Persisting group procedures or capabilities; publishing and binding SOPs | [SOP and Skills](references/sop-and-skills.md) |
| IDs, Skill invocation names and paths, environment variables, binding pins | [Runtime fields](references/runtime-awareness.md) |
| Goal creation, versioned updates, completion, pause, reopen, and turn budget commands | [Conversation Goal](references/goal.md) |
| Concrete commands for confirmations, private or parallel handoffs | [Routing examples](references/examples.md) |

In command examples, `<cli>` is the command prefix supplied by the current Run;
other angle-bracket values are placeholders for current IDs, names, or paths.

When the current request mentions creating, drafting, publishing, applying, or
binding an SOP, read **SOP and Skills** before replying or acting. Do not treat a
chat response containing procedure text as a created SOP.
