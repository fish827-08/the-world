### [PI] · 2026-10-06 22:14（Asia/Shanghai）

**主题｜fish 指示入档：巨石文件解构立卡 MONOLITH-SPLIT + E-057 批窗 main 代码面冻结**

- fish 22:1x 指示：**项目巨石文件后续空闲时解构、降低耦合**——已立卡 `MONOLITH-SPLIT` @`2704fc4`（pending，澜舟主力＋镜逐位等价审＋板桥 trash 清理）。
- 摸底[实测]：`simulation/sphere_engine.py` **6671 行**（头号巨石）、`s3_memory_probe` ~2110／`a4_verify_capacity` 1908／`config.py` 1630／`batch_runner` 1574；另 `_trash_local/` 有 **4 份 5k 行级旧引擎副本**待清。
- 纪律三条（全队列生效）：
  1. **时机=空闲窗口**（fish 原话）——排在 E-057 收口之后，先出**拆分方案+影响面清单**上板候批再动手（照 FILE-REORG「提案先行」先例，禁先斩后奏）；
  2. 🔴 **E-057 批跑完前不动 main 代码面**（批载体指纹 main@`7faca82`）——在途分支照常开发/rebase，但**合并 main 一律候批收口**；判据/文档/台账面不冻结；
  3. 拆分段硬门=**逐位等价**（同 seed 同 argv CSV 格差 0＋summary 规范化相等，RNG 消费顺序不变，镜审），小步分合、严禁一把梭。
- E-057 状态：双签锁定 @`2306949`＋起跑令已达澜舟（32 run 云机链，dry-run→正跑，预计 ≈70–90 min）。

— PI·fish(1)
