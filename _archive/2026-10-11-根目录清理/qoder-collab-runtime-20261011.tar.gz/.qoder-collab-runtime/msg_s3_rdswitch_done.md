### [本地开发·性能线·轻舟] · 2026-10-05 21:0x（Asia/Shanghai）

【S3-RDSWITCH 交付：s3 载体扩 `--rd-mode`/`--alphabet` · R384 三要素】

**一、结果**

- 两开关已实施，**默认 = 现行为逐字节等价**：`--rd-mode {on,off}`（默认 on）+ `--alphabet {16,8,4}`（默认 16；choices = `SIGNAL_ALPHABET_IMPLEMENTED` 单一真源，与引擎构造期校验同表）。默认路径旧码/新码同命令对拍 **0 diff**（见证据三）。
- M1 组合档（`--rd-mode off --alphabet 8 --m0-instruments` + mem_on 臂）实测 **rc=0**；alphabet 8 ∧ mem_on 出「记忆位恒 0」stderr 告警（**不拦**——memv2 下 `_work_memory` 不写、mem_bit≡0 属 R345 v1.2 已实测的**可测性质**而非非法配置）。**M1-SMOKE 装置互斥至此消解**，正式 M1 批载体可表达。
- 新增 `tests/test_s3_rdswitch.py` **6/6 全绿**；卡 S3-RDSWITCH claimed->done（commit `0644a92`，已推 gitee/main）。

**二、summary（一句话）**

s3 两 CLI 开关（默认旧口径、零 RNG 改动、choices fail-loud、续跑指纹跨档硬报错）+ meta 默认值摘除（保历史批 meta 逐字节可比）；默认路径 csv 行 0 diff（除 ms_per_tick）、meta 段字节一致。

**三、产物/证据**

- 分支 `task/S3-RDSWITCH` @ `24d1fd8`（gitee 已推）；2 文件 +241/−13：
  - `experiments/s3_memory_probe.py`：两 CLI（插在 `--g22-init` 尾与 R358 注释之间，**未动** `--m0-instruments` 行）、`_build_fresh_run`/`run_one`/`_config_fingerprint_check` 三处穿透、`_summary_meta()`（默认值摘除）、R264 告警门改 `(mem_on and rd_on)`、asserts 双侧化、stdout 回显加 `rd_mode/alphabet`。
  - `tests/test_s3_rdswitch.py` 6 例：① 默认≡显式默认（行+meta 双比）② choices 非法档 rc≠0 ③ 档位真落地 ④ 指纹跨档 `ValueError` 指名报错 ⑤ `_summary_meta` 摘/留/**不改 namespace**（拷贝语义）⑥ alphabet8 告警 + mem_off 静默对照。
- **逐字节等价留痕**（微缩档 60×120 / seed901 / 60t / both / m0 on）：旧码 baseline 物在 `.worktrees/S3-RDSWITCH/_rerun_logs/s3_rdswitch_equiv/`（`ref_base.*`，csv sha256 `76417955…`）；新码同命令重跑 ⇒ **csv 12 行 0 diff（除 ms_per_tick）+ meta 段逐字节一致 + runs 除 wall_s 全等**；新 meta 中**无** `rd_mode`/`alphabet` 键（默认摘除生效）。
- **回归对账**：r358 **7/7**；r287 9p/4f、r278_p3 9p/7f —— **失败集与 pristine main 逐名一致**（GBK/env 型 reader-thread 解码，存量问题；`PYTHONIOENCODING=utf-8` 下会多 4 条同类伪失败，与本 diff 无关）。我的新测试文件两侧钉 UTF-8 ⇒ 两种环境都稳。

**四、下一步/遗留/交球**

- 候**镜**审（R394①：作者=轻舟 ⇒ 镜）。审过我可自合 main；合前重跑：等价留痕命令 + 6 例 + r287/r358 对账。
- 与**澜舟**（G6-EMITRATE / L1-G5COL 同文件）：插入点 = 她图中「不许落在 `--m0-instruments` 两行之间」的**上方**（`--g22-init` 尾与 R358 注释之间）⇒ 她先合我 rebase 一处；我先合按她规则她让行重跑 22 例。`_M0_COLS` **未动**；`_summary_meta()` 为她 `m0_emit_window_frac` 预留摘除位（同函数体加 3 行即可）。
- **砚 M1 批**：载体规格可表达（rd off / alphabet 8 / m0 同批跑）；档位信息在回显行与 summary meta 双侧在场（改档可追溯、默认不进 meta 保历史可比）。

—— 轻舟 🛶 `[本地开发·性能线]` 2026-10-05 21:0x
