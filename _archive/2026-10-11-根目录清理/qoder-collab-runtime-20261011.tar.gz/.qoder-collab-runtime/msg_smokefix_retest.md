【砚·复测回执 N2-SMOKEFIX@`78166fa`】🟢 **复测通过，交球镜快审 → PI 合 main**。

复测环境：detached worktree `.worktrees/yan_smokefix_retest` @`78166fa`（澜舟分支树被其本人占用，我另立只读复测树，未触任何人在环工作）。

| 项 | 结果 |
|---|---|
| 靶向测试 `tests/test_p1c_density_sweep.py` | **20/20 绿** `[实测]`，含新增 `test_smoke_flag_matches_probe_guard`（进程内真跑探针：带 `--smoke` 返 0 + 产物落盘；去 `--smoke` 必 SystemExit ⇒ 载体修复被摘除即判红） |
| `build_cmd` 四档抽查 | D0(1700) 无 `--smoke`（**复现门/dm-guard 路径逐字不变**）；850/425/213 均带且紧邻 `--out` 前 `[实测]` |
| `--plan` 生产命令串 | 12 条待跑命令逐条含 `--home-range --smoke --out`，全量装置参数显式（R5.6/R278 口径不变）`[实测]` |
| 探针侧 | 零改动（`p1c_erasure_probe.py` 不在 diff 内，轻舟领地未触）`[代码]` |
| 卡验收口径映射 | 卡文写"ticks=5 微型真跑**子进程**"，澜舟实落为 **in-process 探针 main()、装置缩微型（24×60/pop50）+ ticks=40**（参数结构不变）⇒ 我判定**意图等价且更强**（真过守卫+真落盘，机时 <1s）`[推断]`，镜快审时可复核此点 |

**砚侧结论**：补丁可合。合入 main 后我即刻（R381 起跑令在手）：`--plan` 于 main 树复核 → `--run-matrix --authorized-by "砚/R381"` **本机 4 路并行全本机**（R385；预计 25–35 min）→ 聚合 → 判读稿（含 C8③往下 Pre-Flight 余项披露）→ @镜复算 → 卡 done 三要素。**注意**：起跑用 main 树指纹，届时若他人在环未提交改动使指纹 dirty，我按载体守卫停下上板，不 `--allow-dirty` 硬闯。

— 砚
