# -*- coding: utf-8 -*-
"""R316 判读：设计 2（队列消失率）+ 设计 1（行为可遗传性）。

数据：_rerun_logs/disp_20k/results/disp_<seed>_<arm>.csv（seed 193-196 × 双臂，
      旗舰档 20k tick，sample=200）+ 同名 .pairs.csv（存活个体活动量 + 父代 id）。
"""
import csv
import os
import numpy as np

RES = "_rerun_logs/disp_20k/results"
SEEDS = [193, 194, 195, 196]
ARMS = ["off", "on"]


def rows(p):
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def fl(x, d=float("nan")):
    try:
        v = float(x)
        return v if v == v else d
    except (TypeError, ValueError):
        return d


print("=" * 104)
print("【设计 2】队列消失率：死亡按「死前状态」分组（pooled 死亡率 = 累计死亡 / 累计人·区间）")
print("=" * 104)
print("%-5s %-4s %7s %9s %10s %10s %11s %11s %11s %11s" % (
    "seed", "arm", "pop", "died累计", "dr_内", "dr_外", "外/内倍数",
    "dr_留守", "dr_出走", "出走/留守"))
rec = {}
for s in SEEDS:
    for arm in ARMS:
        p = os.path.join(RES, "disp_%d_%s.csv" % (s, arm))
        if not os.path.exists(p):
            continue
        r = rows(p)[-1]
        di, do = fl(r["hr_dr_in"]), fl(r["hr_dr_out"])
        ds, dg = fl(r["hr_dr_stay"]), fl(r["hr_dr_go"])
        rec[(s, arm)] = r
        print("%-5d %-4s %7s %9s %10.5f %10.5f %11s %11.5f %11.5f %11s" % (
            s, arm, r["pop"], r["hr_died_n"], di, do,
            ("%.2f" % (do / di)) if di and di == di else "-",
            ds, dg, ("%.2f" % (dg / ds)) if ds and ds == ds else "-"))

print()
print("--- 成熟个体口径（age≥500，排新生儿混淆）---")
print("%-5s %-4s %12s %12s %10s" % ("seed", "arm", "dr_外(成熟)", "dr_留守(成熟)", "外/留守"))
for s in SEEDS:
    for arm in ARMS:
        r = rec.get((s, arm))
        if r is None:
            continue
        om, sm = fl(r["hr_dr_out_m"]), fl(r["hr_dr_stay_m"])
        print("%-5d %-4s %12.5f %12.5f %10s" % (
            s, arm, om, sm, ("%.2f" % (om / sm)) if sm and sm == sm else "-"))

print()
print("--- 各臂汇总（4 世界平均）---")
for arm in ARMS:
    rs = [rec[(s, arm)] for s in SEEDS if (s, arm) in rec]
    di = np.mean([fl(r["hr_dr_in"]) for r in rs])
    do = np.mean([fl(r["hr_dr_out"]) for r in rs])
    ds = np.mean([fl(r["hr_dr_stay"]) for r in rs])
    dg = np.mean([fl(r["hr_dr_go"]) for r in rs])
    print(" %-4s  dr_内=%.5f  dr_外=%.5f (×%.2f) | dr_留守=%.5f  dr_出走=%.5f (×%.2f)"
          % (arm, di, do, do / di, ds, dg, dg / ds))

print()
print("=" * 104)
print("【设计 1】亲子对：子代活动量 vs 亲代活动量（活动量 = 平均每区间位移 move/(seen-1)）")
print("=" * 104)
print("%-5s %-4s %8s %10s %12s %12s %12s" % (
    "seed", "arm", "配对数", "g22亲-子r", "活动r(Pearson)", "活动rho(秩)", "子代均活动"))
allp = []
for s in SEEDS:
    for arm in ARMS:
        p = os.path.join(RES, "disp_%d_%s.pairs.csv" % (s, arm))
        if not os.path.exists(p):
            continue
        rs = rows(p)
        if not rs:
            continue
        by_id = {int(x["id"]): x for x in rs}
        ch, pa, g_c, g_p = [], [], [], []
        for x in rs:
            pid = int(x["parent"])
            if pid < 0 or pid not in by_id:
                continue
            y = by_id[pid]
            cs, ps = int(x["seen"]), int(y["seen"])
            if cs < 3 or ps < 3:
                continue
            ch.append(fl(x["move"]) / (cs - 1))
            pa.append(fl(y["move"]) / (ps - 1))
            g_c.append(fl(x["g22"]))
            g_p.append(fl(y["g22"]))
        if len(ch) < 20:
            print("%-5d %-4s %8d  （配对太少，跳过统计）" % (s, arm, len(ch)))
            continue
        ch = np.array(ch)
        pa = np.array(pa)
        r_act = float(np.corrcoef(ch, pa)[0, 1])
        rc = np.empty(len(ch)); rc[np.argsort(ch, kind="stable")] = np.arange(len(ch))
        rp = np.empty(len(pa)); rp[np.argsort(pa, kind="stable")] = np.arange(len(pa))
        rho = float(np.corrcoef(rc, rp)[0, 1])
        r_g22 = float(np.corrcoef(np.array(g_c), np.array(g_p))[0, 1])
        allp.append((r_act, len(ch)))
        print("%-5d %-4s %8d %10.3f %12.3f %12.3f %12.3f" % (
            s, arm, len(ch), r_g22, r_act, rho, ch.mean()))

if allp:
    w = np.array([n for _, n in allp], dtype=float)
    r = np.array([x for x, _ in allp], dtype=float)
    print()
    print("  ── 加权平均亲子活动量相关 r = %+.4f（%d 个世界，共 %d 对）" % (
        float((r * w).sum() / w.sum()), len(allp), int(w.sum())))
    print("  参考：g22 是**直接遗传**的基因，其亲子 r 应显著为正（约 0.5）——若活动量 r 远低于此，")
    print("        说明「活动量」大部分不是遗传决定的（更像同一群体内的随机/环境差异）。")
