# -*- coding: utf-8 -*-
"""4-seed 加密采样批（R313）：seeds 190/191/192 × 2 臂，`--sample 200`，带快照保留。

为什么要脚本：直接在本机 shell 里用 `for … & wait` 起后台批**不生效**
（工具的后台包装与循环 `&` 不兼容 ⇒ 3 秒即"完成"、零 log）。
用 `subprocess.Popen`（与已成功的 `_run_hr_20k.py` 同款）才可靠。
"""
import os
import subprocess
import time

ROOT = r"C:\Users\圣羽\Desktop\temp\tempCode\the-world"
TREE = os.path.join(ROOT, "_rerun_logs", "hr200_v2")
PY = os.path.join(ROOT, ".venv", "Scripts", "python.exe")
OUT = os.path.join(TREE, "results")
SNAP = os.path.join(OUT, "snap")
os.makedirs(SNAP, exist_ok=True)
SEEDS = ["190", "191", "192"]


def launch(arm, extra):
    ps = []
    for s in SEEDS:
        cmd = [PY, "-u", "-m", "experiments.s3_memory_probe",
               "--rows", "480", "--cols", "960", "--pop", "10000",
               "--patches", "1700", "--seeds", s, "--arms", arm,
               "--ticks", "20000", "--sample", "200",
               "--home-range",
               "--out", os.path.join(OUT, f"hr200_{s}_{arm}.csv")] + extra
        logf = open(os.path.join(OUT, f"hr200_{s}_{arm}.log"), "w", encoding="utf-8")
        p = subprocess.Popen(cmd, cwd=TREE, stdout=logf, stderr=subprocess.STDOUT)
        ps.append((s, p, logf))
        print(f"[spawn] {s}_{arm} pid={p.pid}", flush=True)
        time.sleep(3)
    while any(p.poll() is None for _, p, _ in ps):
        time.sleep(60)
        n = sum(1 for _, p, _ in ps if p.poll() is None)
        print(f"[mon] {time.strftime('%H:%M')} {arm} alive={n}", flush=True)
    for _, _, f in ps:
        f.close()


print("[wave] off 起跑", flush=True)
launch("off", [])
print(f"[wave] off 完成 {time.strftime('%H:%M')} ⇒ on 起跑", flush=True)
launch("on", ["--weight-gene"])
print(f"[ALLDONE] {time.strftime('%H:%M')}", flush=True)
