# -*- coding: utf-8 -*-
"""R326：把「撤绿洲带」落实到**探针自带默认**（R321 只改了预设档，没改探针默认 ⇒ 实际未生效）。

改动（逐条精确替换，幂等）：
  1. experiments/s3_memory_probe.py —— DEVICE 字典 + run_one 签名默认 0.4/0.05 → 0.0/0.0
  2. experiments/centroid_opt_probe.py —— 同上
  3. tests/test_r278_p3_device_flush.py —— 期望值同步 0.4/0.05 → 0.0/0.0
不做：不碰 `--device` 机制本身；不碰 s2_depletion_probe（其 run_one 默认已是 0.0）。
"""
import io
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

JOBS = [
    ("experiments/s3_memory_probe.py", [
        ("#   bg_low_prod_frac=0.4 bg_low_cap_mult=0.05（不挂 sparse）",
         "#   bg_low_prod_frac=0.0 bg_low_cap_mult=0.0（R326 撤绿洲带；不挂 sparse）"),
        ("    ticks=2000, sample=250, rgm=1.195,\n    bg_low_prod_frac=0.4, bg_low_cap_mult=0.05,\n",
         "    ticks=2000, sample=250, rgm=1.195,\n"
         "    # 🔴 R326（2026-10-02）：**撤绿洲带落到实处**——R321 只改了 tools/device_presets.py\n"
         "    #   的预设档，而**探针自带默认仍是 0.4/0.05**，且 `--device` 只有显式传参才介入\n"
         "    #   ⇒ 不传 `--device` 的运行**仍是旧装置**（冒烟实测 `bg_low_frac=0.4` 才发现）。\n"
         "    #   此处同步为 0.0/0.0，使「默认 = 当前装置」，消除 R278 §三 要消灭的\n"
         "    #   「忘传 --device ⇒ 静默回落旧装置」坑。\n"
         "    bg_low_prod_frac=0.0, bg_low_cap_mult=0.0,\n"),
        ("            bg_low_prod_frac=0.4, bg_low_cap_mult=0.05, weight_gene=False,",
         "            bg_low_prod_frac=0.0, bg_low_cap_mult=0.0, weight_gene=False,"),
    ]),
    ("experiments/centroid_opt_probe.py", [
        ("    rgm=1.195, bg_low_prod_frac=0.4, bg_low_cap_mult=0.05,",
         "    rgm=1.195, bg_low_prod_frac=0.0, bg_low_cap_mult=0.0,   # R326：撤绿洲带"),
    ]),
    ("tests/test_r278_p3_device_flush.py", [
        ('"rgm": 1.195, "bg_low_prod_frac": 0.4, "bg_low_cap_mult": 0.05}',
         '"rgm": 1.195, "bg_low_prod_frac": 0.0, "bg_low_cap_mult": 0.0}'),
        ("# 都未显式传 ⇒ 取预设 0.4", "# 都未显式传 ⇒ 取预设 0.0（R326 撤绿洲带后）"),
        ("assert ns.bg_low_prod_frac == 0.4", "assert ns.bg_low_prod_frac == 0.0"),
    ]),
]

for rel, subs in JOBS:
    p = os.path.join(ROOT, rel)
    txt = io.open(p, encoding="utf-8").read()
    print("== %s ==" % rel)
    for old, new in subs:
        c = txt.count(old)
        print("   命中 %d 处：%s" % (c, old.strip().splitlines()[0][:60]))
        if c:
            txt = txt.replace(old, new)
    io.open(p, "w", encoding="utf-8", newline="").write(txt)
print("完成")
