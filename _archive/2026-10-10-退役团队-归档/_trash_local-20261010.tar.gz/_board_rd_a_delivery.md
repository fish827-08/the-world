**rd-A（A2 束）交付：分支 `dev/qingzhou-rd-a` @ `8d36bdf`（已推 gitee）——rd 全链子集化 + 回写跳过（逐位等价）｜靶向 12/12｜全量 0 新失败｜冒烟"可"｜本窗配对 ×1.71（A1+A2）／×1.27–1.33（A2 单独）；A1 翻档 B 支 seed 仍待裁**

**一、交付物（R294 rd-A 账；串行序已守：T1b 合 main `be79ffe` 后当晚开工）**
- 分支 `dev/qingzhou-rd-a` @ `8d36bdf`（基 `0a38d5b`；4 文件 +684/−84）：`world/resource_dynamics.py`、`simulation/sphere_engine.py`、`tests/test_resource_dynamics_t2.py`（+2 行外部写方契约）、`tests/test_rd_a2_subset.py`（新，12 例）。
- A2 五项 = 19:54 稿 §三-A 明细第 2–6 项（第 1 项=装置翻档属 A1，见 §四）：
  | 稿中项 | 改动 | 逐位机制 |
  |---|---|---|
  | 2 | capacity 合并（缓存） | `capacity_from_base` 缓存 + `_mask_ver` 失效（掩码唯一变更通道） |
  | 3 | note_tick 子集化 | eaten 单次 `flatnonzero` 三用（分母補算／结算／下 tick 清零表）；逐元素同式 |
  | 4 | rotate 扫描子集化 | `_dead_idx`/`_rest_idx` 派生索引（升序唯一 ⇒ RNG 消费次序不变）+ 自愈 |
  | 5 | growth_multiplier 惰性子集 | 可选 `idx` 入参；默认 None=全量、逐位不变 |
  | 6 | 零碎 + 引擎侧 | `_rd_growth_sum`/`_rd_intake_sum` 子集清零（prev-idx 跟踪 + 首 tick 兜底）+ 回写跳过（`_mask_ver` 未变 ⇒ 不重算/不拷贝） |
- 外部写方契约：直改 `_dead`/`_rest_until`（旧档/调试/测试）后须调 `rebuild_indexes()`；引擎 load 路径已挂钩（+`invalidate_capacity` + 首 tick 全量回写兜底）。

**二、验证链（A2 验收四项全绿）**
| 项 | 结果 |
|---|---|
| 靶向单测 `test_rd_a2_subset.py` | **12 passed**（子集 vs 全量逐位：gm／capacity 缓存+失效／note_tick(on/off)／空子集／rotate 双场景／索引自愈／快照重建／引擎级 2000t A/B），4.5s |
| 引擎级 A/B ①跨树 9 模式 × 2001 tick 逐 tick digest | 全等（22:00 帖已报） |
| 引擎级 A/B ②本树 sparse on/off × 1200 tick（seed 101） | **全等 ✓**（t=1200，N=4816；逐 tick 全状态，无首分歧） |
| 全量 pytest（A2 版树） | **60f/1060p/8s = 0 新失败**（60 = 46 基线 + 14 env；+12 绿 = 恰为新测试文件） |
| `rd_resume_smoke`（rd 开 + S2 同款档） | **可**（存档→中断→续跑 500/500 tick digest 全等；墙钟 90s；lazy=True） |
| 计时 16 跑 digest 横验 | **全等**（4 变体 × 4 轮 = main/wt × sparse off/on，t=900，N=3424；17 键含状态+计数+RNG） |

**三、计时（in-window ABBA 4 轮 × 16 跑；⚠️ 本机 off×4 批跑叠加中 ⇒ 载荷窗口口径，绝对值禁跨列比）**
装置 = 旗舰 off 档 seed 101；预热 800t 后 5×20 tick 取中位：

| 变体（4 轮中位） | ms/t |
|---|---|
| main 基线（装置现档） | 91.1 |
| main + A1（sparse on） | 68.1 |
| wt + A2（sparse off） | 68.4 |
| wt + A1 + A2 | **50.4** |

- 逐轮配对比值（抗负载漂移）：基线→**A1+A2 = [1.41, 1.90, 1.70, 1.73] ⇒ 中位 ×1.71**（= R294 目标带 1.5–1.7× 上沿）；基线→**A2 单独 = [1.47, 1.26, 1.14, 1.27] ⇒ 中位 ×1.27**（原始中位比 ×1.33）。R1 含一次载荷台阶（wt_s1=69.1 偏慢），全表已留档可复核。
- **R294 目标「rd 27→≈5 静默｜off 1.5–1.7×」= A1+A2 合并口径**（A1=第 1 项 ≈9 静默；A2=第 2–6 项 ≈13 静默）——本窗合并配对 ×1.71 与目标吻合。**A2 与 A1 正交**：A2 单独在装置现档（sparse off）即生效，不依赖 A1 翻档裁定。A2 单体量级自洽：22.7 ms/t 窗差 ÷ 窗口膨胀 1.4–1.9 [外推] ≈ 12–16 静默，与稿估 ≈13 同量级。
- 🔴 **静默复测 = 稿 §四 规定的收益收口**：本机整夜有批（R298）⇒ 本窗比值先行、口径已标；脚本随分支可复跑（`_trash_local/_rd_a2_timing.py --sparse 0|1 --rd 0|1`），**待空窗**（计划明早批跑完；或按指定窗口）。

**四、A1 状态（#40；等 22:00 帖三问裁定）**
- A 支 seed（101/169/171）：旗舰档 sparse on 构造 ✓ + **双引擎 1200 tick 逐 tick 全状态全等 ✓**（A sparse 47.5 ｜ B 基线 71.6 ms/t，本窗口）——A1 验收「新装置首跑前 ≥1000 tick 自检」对 A 支已履行。
- B 支 seed（167/170/172）：构造期 `ValueError`（`sphere_engine.py:1201`）⇒ 翻档阻断（22:00 帖 §四）。

**五、请裁**
1. **验收**：分支 `dev/qingzhou-rd-a` @ `8d36bdf` 请按 T1b 同标准验收（证据均在本帖；静默复测按 §三 收口）。
2. **静默复测窗口**：明早批跑完补测（或指定窗口）？
3. A1 三问（判读分层／修法甲·乙·丙／A1 顺延）仍待裁。

**附**：脚本 `_trash_local/_rd_a2_timing.py`（计时+17 键 digest）、`_rd_a2_timing_report.py`（聚合）、`_rd_a1_dual_engine.py`（1200t 双引擎）；16 跑 JSON 明细 `_trash_local/_rd_a2_timing/`。
