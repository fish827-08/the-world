"""R273 L2 调试：定位增量 vs 全量的第一个不一致 tick + 诊断位置特征。"""
import sys
import numpy as np

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import simulation.sphere_engine as se
from experiments.steady_k_probe import make_cfg, apply_post_build
from experiments.centroid_opt_probe import DEVICE

orig_full = se._build_patch_centroid

c, notes = make_cfg(
    104, DEVICE["rows"], DEVICE["cols"], DEVICE["pop"], DEVICE["patches"],
    True, DEVICE["speed_max"], DEVICE["gain"], DEVICE["subdiv"],
    DEVICE["k"], DEVICE["max_count"], DEVICE["rgm"],
    bg_low_prod_frac=DEVICE["bg_low_prod_frac"],
    bg_low_cap_mult=DEVICE["bg_low_cap_mult"],
)
c.simulation.use_sim_core = False
c.resource_dynamics.enabled = True
c.info_structure.memory_v2 = True
c.info_structure.memory_gradient = "orientation"
eng = se.SphereEngine(c)
apply_post_build(eng, notes)

WORLD = eng.world
ROWS, COLS = WORLD.rows, WORLD.cols
ASY = int(ROWS - 2)


def rows_of(cells):
    return np.sort(np.unique(np.asarray(cells, dtype=np.int64) // COLS))


def show(cells, n=14):
    return [int(r) for r in rows_of(cells)[:n]]


print(f"world rows={ROWS} cols={COLS}; asym zone rows = 0,1,{ASY},{ROWS-1}")
for t in range(1, 90):
    prev = eng.resources._patch_mask.copy()
    eng.step()
    cur = eng.resources._patch_mask
    if not np.array_equal(prev, cur):
        ch = np.flatnonzero(prev != cur)
        exp = orig_full(WORLD, cur)
        got = eng._patch_centroid
        bad = np.flatnonzero(got != exp)
        head = f"tick {t}: n_changed={int(ch.size)} changed_rows={show(ch)}"
        if bad.size == 0:
            print(head + " OK")
        else:
            print(head + f" | MISMATCH n={int(bad.size)} bad_rows={show(bad, 30)}")
            for k in bad[:15]:
                k = int(k)
                print(f"    cell {k} (r{k//COLS},c{k%COLS}) old={bool(prev[k])} new={bool(cur[k])}"
                      f" | inc={int(got[k])} full={int(exp[k])}")
            break
