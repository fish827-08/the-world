# -*- coding: utf-8 -*-
"""T1 评估：memv2 写入/旋转/打分 三件套的 on 臂热点归因（S3 装置 seed 104）。

两段：
  A) 手动计时（perf_counter 包三方法实例属性）→ 精确 wall 归因（含 _cell_dir_slot）
  B) cProfile → 其余开销分布（残余热点）
"""
import sys, os, time, cProfile, pstats
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine


def build(seed, mem_on=True):
    B = dict(rows=480, cols=960, patches=1700, pop=10000,
             speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
             bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)
    c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                        B["speed_max"], B["gain"], B["subdiv"], B["k"], B["max_count"], B["rgm"],
                        bg_low_prod_frac=B["bg_low_prod_frac"], bg_low_cap_mult=B["bg_low_cap_mult"])
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = True
    c.info_structure.memory_v2 = bool(mem_on)
    c.info_structure.memory_gradient = "orientation" if mem_on else "none"
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    return eng


def timed(eng, T=100):
    acc = {}

    def wrap(name):
        orig = getattr(SphereEngine, name)

        def _w(*a, **k):
            t = time.perf_counter()
            try:
                return orig(*a, **k)
            finally:
                d = time.perf_counter() - t
                s = acc.setdefault(name, [0, 0.0])
                s[0] += 1
                s[1] += d

        setattr(SphereEngine, name, _w)

    for n in ("_mem_v2_write", "_mem_v2_step_one",
              "_memory_egocentric_cos", "_cell_dir_slot"):
        wrap(n)
    for _ in range(10):
        eng.step()
    acc.clear()
    t0 = time.perf_counter()
    for _ in range(T):
        eng.step()
    dt = time.perf_counter() - t0
    print(f"[手动计时] on 臂 {T}t 总 {dt:.1f}s = {dt/T*1e3:.1f} ms/tick "
          f"(tick 末 pop={int((eng._alive[: eng._n_alive]).sum()) if hasattr(eng, '_alive') else '?'})")
    tot = 0.0
    for n in ("_memory_egocentric_cos", "_mem_v2_step_one", "_mem_v2_write"):
        c, s = acc.get(n, [0, 0.0])
        tot += s
        print(f"  {n:26s} calls={c:8d}  total={s:8.2f}s  ({s/T*1e3:7.1f} ms/tick, {s/dt*100:5.1f}%)")
    c, s = acc.get("_cell_dir_slot", [0, 0.0])
    print(f"  {'_cell_dir_slot(内含)':26s} calls={c:8d}  total={s:8.2f}s  ({s/T*1e3:7.1f} ms/tick, {s/dt*100:5.1f}%)")
    print(f"  三方法合计 = {tot:.1f}s ({tot/dt*100:.1f}% of wall)")


def profiled(eng, T=60):
    for _ in range(10):
        eng.step()
    pr = cProfile.Profile()
    pr.enable()
    t0 = time.perf_counter()
    for _ in range(T):
        eng.step()
    dt = time.perf_counter() - t0
    pr.disable()
    print(f"\n[cProfile] on 臂 {T}t 总 {dt:.1f}s ({dt/T*1e3:.0f} ms/tick)")
    st = pstats.Stats(pr)
    st.sort_stats("tottime")
    st.print_stats(18)


if __name__ == "__main__":
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 104
    e1 = build(seed, mem_on=True)
    timed(e1, T=100)
    e2 = build(seed, mem_on=True)
    profiled(e2, T=60)
