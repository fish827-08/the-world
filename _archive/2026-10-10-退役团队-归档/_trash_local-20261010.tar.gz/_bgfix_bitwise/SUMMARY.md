# R328 甲案交付 · 证据包（轻舟 2026-10-02）

分支 `dev/qingzhou-rd-bgzero` @ 786d2c4（基 cd74452）｜3 文件：
`world/resource_dynamics.py` / `tools/check_bg_lottery.py` / `tests/test_242_bg_low_prod.py`

## ① 靶向单测
`pytest tests/test_242_bg_low_prod.py -q` ⇒ **12 passed**（2.4s；8 既有 + 3 参数化 + 1 兼容例）。

## ② check_bg_lottery 复测（修复后）
| 档 | 修复前 B 支 | 修复后 B 支 | 证据文件 |
|---|---|---|---|
| 旧档全池 40–210（0.4/0.05，171 world） | 56/171（`_rd_lottery_scan_40_210.txt`） | **0/171** | `_bgfix_scan_40_210.txt` |
| 旗舰旧档 165–172（0.4/0.05，8 world） | 3（167/170/172） | **0/8** | `_bgfix_flagship_old.txt` |
| 现档 0.0/0.0（12 world） | 0 | **0/12** | `_bgfix_default_check.txt` |

## ③ 现档逐位零变化（main=修复前 vs wt=修复后，同脚本 `_bgfix_bitwise.py`）
装置：新档 0.0/0.0 + rd 开 + seed 201 + 1800 tick（800 预热 + 1000 计时窗）。两树均无 sim_core.so（纯 Python 单路）。
| 跑 | main digest | wt digest | 判定 |
|---|---|---|---|
| sparse 0 | `main_s201_sp0.json` | `wt_s201_sp0.json` | **全同**（17 键） |
| sparse 1 | `main_s201_sp1.json` | `wt_s201_sp1.json` | **全同**（17 键） |

- 附加：4 跑两两全同 ⇒ 新档 sparse on/off **终态逐位等价**（独立进程级）。
- sp1 两树 sparse 均真激活（`sparse_engine=True / lazy=True`）；两树闸诊断 `rd_bgzero=True / b_mult=0.0`。
- 17 键 digest = t/n/flat/ids/e_energy + grid/cap/pmask/marks/age + rd_mask/dead/rest/dsince/damage/cnt/rng。

## ④ 全量 pytest（两树各一次，失败集比对）
- main：**60 failed / 1060 passed / 8 skipped**（534.6s）｜wt：**60 failed / 1064 passed / 8 skipped**（540.1s）。
- **FAILED 集合逐项 diff = 完全一致**（`failed_main.txt` vs `failed_wt.txt`，diff 为空）；wt 恰 +4 passed = 新增 4 用例全绿。
- main 含他人未提交 R330 修订（`_tail_mean` n=3→20，无单测钉死）——不影响对账。

## ⑤ A1 新档自检（`_bgfix_a1_selfcheck.py`，wt 树）
- 新档 + rd 开，sparse off vs on **同进程双引擎逐 tick digest 1050t 全程一致**（含构造态）。
- 闸真开：on 臂 `_sparse_fields=True`+`lazy=True`+信号`_sparse=True`；off 臂全关；`rd_bgzero=True b_mult=0.0`。
- 非空转：脏格非空 1050/1050 tick；活跃信号格非空 1050/1050 tick。
- CPU 软参考（高载，非静默口径）：on=64.1% off（140.1→89.8 ms/t）；末态 N=3783 未灭绝。
