**R291 §四 交付：rd 成本审计 + 下沉评估（③ 方案对比请裁：A 配置+算法先行 vs B Rust 下沉）**

**结论先行**
- **① 审计复核通过**：天平段表与实测一致（跨窗口 ×1.4–1.9，**比值稳定**）；两枚低垂果实均已验证——capacity 合并**等价 30/30 tick + 子集逐位 True**（省 ≈3.5 静默）；regrowth 子集链**引擎早已实现（R244 v1，2758–2775）**，装置只是**没挂 sparse** ⇒ 本次真机 A/B（t=800 + **100 tick 逐位全等**）配对省 **13.34 ms/t（本窗口）**。
- **② Rust 面已勘**：`regrow.rs` 有先例但 **2 路倍率（缺 R242 bg_low 第三路）+ 无 R196 light 因子（其归一化是全场归约⇒非逐位，须传标量）+ 直写与惰性子集互斥**；note_tick/rotate/capacity 无 Rust 对面；rd 唯一 RNG = 斑块搬移（本装置 **bgzero 恒不触发**）。
- **③ 建议：先 A（配置+算法，纯 Python），暂缓 B（Rust）**。A 预计 rd 27→**≈5 静默**（off 臂 53.6→**≈32–36 ⇒ 1.5–1.7×**；60k off 65min→**~39–44min**），成本 ≈1–1.5 人日，全部"同式子集"类改动（等价性与 R217/R244 同族、可逐位对拍）；B 单独 27→10–15（1.3–1.4×），但 **A 落地后 B 边际只剩 2–3 ms/t**，不值 2–4 人日。**请裁 ③。**

---

**一、逐段审计（真机 60k 装置；两口径并列，⚠️ 禁跨列比）**

装置（与旗舰批同模板 `steady_k_probe.make_cfg + apply_post_build`）：rd.enabled ∧ bgzero ∧ rotate_moves_patch；patchy；**现状 sparse 未挂**（`resources._lazy=False`）；temp_sens=1.0｜light_sens=0.0；mults patch 1.195 / bg 0.0 / bglow 0.05；kill_denom=regrowth；t=800：N=2655、dead=4589、resting=1061、eaten≈0.43%。

| 段 | 天平静默 ms/t | 本机负载窗口实测（本窗口 A 臂 tick=178.1） | 证据 |
|---|---|---|---|
| regrowth 全场 | 12.0 | 核心算子逐项复算 ≈11–13（clip 2.84+pow 1.32+temp 1.88+三路 where 5.15+…） | D 微基准 + A/B |
| note_tick | 7.5 | 表达式组 **10.8**（eaten 子集版 **1.1**） | P2 微基准 |
| capacity_from_base ×2 | 3.3 | **2.13/次**；回写拷贝 0.87 | P1 微基准 |
| rotate | 2.7 | 扫描组 **2.91**（子集 0.38） | P3 微基准 |
| growth_multiplier | 1.4 | **1.35**（子集 0.02） | D/P3 微基准 |
| lt.temperature 全场 | — | 1.88 | D |

窗口换算 ≈ ×0.69（=122.7/178.1，对 T1b 静默 on 臂）[外推]；本机负载窗口相对静默普遍 ×1.4–1.9。

**低垂果实 #1：capacity 合并 —— 等价已验证，收益 ≈3.5 静默**
- 等价（两重）：note_tick 处重算值 vs 引擎上一 tick 回写值 **30/30 tick 全等**（v1-A 段）；子集 gather `cap[eaten] == 全量[eaten]` **逐位 True**（P1）。
- 结构：`capacity_from_base()` 是 `(base, mask, 倍率)` 的**纯函数** ⇒ 每 tick 一次足矣；bgzero 档掩码恒定 ⇒ 可"掩码变才重算"（一般档由掩码变更检测兜底，不变则跳过亦 value-identical）。
- 收益：本窗口 2.13×2 + 回写拷贝 0.87 − gather 0.002 ≈ **5.1 ms/t ⇒ ≈3.5 静默** [外推]。（天平估 1–2 = "只合并、不跳过"保守版；合并+跳过+gather 版 ≈3.5。）

**低垂果实 #2：regrowth 子集链 —— 引擎已实现（R244 v1），装置未挂 ⇒ 真机 A/B**
- 现成设施：引擎 2758–2775 惰性子集路径（flatnonzero(脏)→子集 `_regrowth_amount`→min→清脏）；前提链 = `enable_lazy` 逐条校验 + 范围锁 + 构造期 fail-loud；存量测试 `test_sparse_fields.py` 已含 **rd∧bgzero∧sparse 引擎级逐位** + 快照重建 + v1 快照续跑冒烟（T-F）。
- 本次真机 A/B（双引擎同 seed=101、装置逐字同、B 构造期 `sparse_fields=True`；`_sparse_fields=True / resources._lazy=True / signals._sparse=True` 已由探针打印确认）：
  - t=800 全状态 digest **逐位 True**；随后 **100 tick 逐 tick digest 全等 ✓**（覆盖 grid/capacity/patch_mask/flat/genes/marks/age/energy/mem_az/dist/tick/damage + tick/dead/rest 计数）；
  - 脏格 3935/460800 = **0.85%**；
  - 配对墙钟（同窗口、交替）：A 178.1 ｜ B 164.7 ms/t ⇒ **省 13.34 ms/t** [实测]；与同窗口 D 微基准（全场核心 11–13 → 子集残 ≈1）**自洽**，两口径独立互证。
- ⚠️ v1 抛过的 regrowth 24.18/30.03 是**更重窗口**的数（同窗口 D 复算把全场核心拆到 11–13）：**结构结论用比值（全场/子集 60–100×），收益用配对差**。

**二、下沉评估（若走 Rust）**

| 面 | 现状 | 缺口/风险 |
|---|---|---|
| `regrow` / `regrow_patchy` | 已有（Rayon、sens==1 免 pow、take_min、单测） | 只 **2 路**倍率（缺 bg_low 三路）；**无 light 因子**（归约须 Python 算标量传入）；**直写 `_grid` 全场** ⇒ 与惰性子集互斥（若下沉则放弃 A1 的 13.3） |
| note_tick / rotate / capacity | 无 Rust 对面 | 全量段可沉（扫描类）；`argsort(kind="stable")` 需保序对拍；capacity 是纯逐元素（Rust 增益本就 <1.3×，不如合并省） |
| 对拍方案 | `tests/test_sim_core.py`（函数级逐位+边界）、`tests/test_sim_core_engine.py`（引擎级 TickStats/内部状态逐位）先例齐备 | rd 档 use_sim_core=False ⇒ 引擎级 A/B = 纯 Python vs Python+新 Rust 段（可行） |
| RNG | 唯一消费点 `_promote_same_row`（自有 `_rng`） | bgzero 档**恒不触发**；一般档建议搬移留 Python（非热点）或按惯例预生成传入 |
| 增益 | [外推；天平 2–2.7× + regrow.rs 先例] rd 27→10–15 | 工日 2–4（双路径/对拍矩阵/重编） |

**三、方案对比（请裁 ③）**

| | **A：配置 + 算法（纯 Python）** | **B：Rust 下沉** |
|---|---|---|
| rd 走向（静默） | 27 → **≈5**（区间 4–10） | 27 → 10–15 |
| off 臂 | 53.6 → **≈32–36 ⇒ 1.5–1.7×** | 53.6 → 37–42 ⇒ 1.3–1.4× |
| 60k off | 65min → **~39–44min** | 65min → 45–50min |
| 成本 | 配置 0 + 算法 ~1–1.5 人日 | 2–4 人日 |
| 等价证据 | **已有**：R217/R244 前提链 + 存量测试 + 本次 100 tick 真机 A/B；每项=同式子集 ⇒ 逐位可证 | **需新建**：bg_low/light 对拍面、新模块、双路径 |
| 覆盖 | 仅"可开 sparse"的档（bgzero 等）；一般 rd 档 regrow 仍全量 | **唯一独有**：一般 rd 档（非 bgzero）也治 |

**A 明细**（全部 value-identical；验收同 v1 #21 口径：靶向单测 + 引擎级对拍 + 快照续跑 + 静默复测）：
1. **装置开 `sparse_fields`**（下批起；本批 ETA 不变）——**逐位等价 ⇒ 实验轨迹零影响，纯提速**；已证 100 tick 逐位 + 存量测试；收益 13.3（本窗口）⇒ **≈9 静默**；
2. capacity 合并（缓存 + 掩码变才重算 + note_tick 处 gather）⇒ **≈3.5 静默**；
3. note_tick 子集化（eaten 子集；damage 变更逐位验过）⇒ **≈6.7 静默**（P2 复算略低估，含未复算小项）；
4. rotate 扫描子集化（rest/dead 索引 + 子集判定）⇒ **≈1.7 静默**；
5. growth_multiplier 惰性子集（可选 `idx` 参数，默认 None=全量、逐位不变）⇒ **≈1.0 静默**；
6. 零碎：`_rd_growth_sum[:]=0` 全清、`_demoted.any()` 扫描等 ⇒ ~0.5。

⇒ 合计 ≈22 静默 ⇒ **rd ≈5、off ≈32（1.67×）**。与 T1b（on 臂 memv2 批量化 ~2.2×）**正交**，可叠加。

**B 的时机**：若仍要 B，建议 **A1+A2 落地后按残值重估**（届时 rd 残 ~5，B 只剩 2–3 ms/t）；或范围收窄到 A 覆盖不到的**一般 rd 档 regrow**（那里 sparse 被范围锁排除、全量 12 ms 仍在——但那档当前不是产线）。另有一条纯算法孪生项：三路 where→**LUT**（构建 1.87 + 一次乘 1.01 vs 现状 5.15，**逐位等价已验**），但对 bgzero+sparse 档价值≈0，只对"不能挂 sparse"的档有意义。

**四、验收（若裁 A）**
- A1：沿用存量对拍（test_sparse_fields 引擎级逐位 + 快照重建 + v1 续跑冒烟）+ **新装置首跑前 ≥1000 tick 逐位自检**（双引擎，夜间顺跑，~30min）；
- A2：每项靶向单测（子集 vs 全量逐位）+ 引擎级 A/B（≥2000 tick 逐 tick digest）+ 全量 pytest + `rd_resume_smoke`；收益以**静默窗口配对复测**收口。

**五、请裁**：① **A**（我接：A1 装置 flip 报备 + A2 实施，~1–1.5 人日）② **B**（Rust，另估 2–4 人日）③ **先 A 后重估 B**。

—— 探针与原始日志：`_trash_local/_rd_audit.log`（v1 段计时/capacity 等价/子集逐位）、`_rd_lazy_ab2.log`（真机 A/B + D）、`_rd_opt_micro.py`（P1/P2/P3 微基准）。
