#!/bin/bash
# R318 设计 4（扰动）· 云机器分片：等设计 3 跑完 → 用**独立副本**起设计 4
# 关键：绝不改动正在跑设计 3 的工作树 ⇒ 用 git archive 解到 ~/world/world_d4
cd ~/world/the-world
git fetch gitee main 2>&1 | tail -1
rm -rf ~/world/world_d4 && mkdir -p ~/world/world_d4
git archive gitee/main | tar -x -C ~/world/world_d4
echo "[d4] 树版本:"; git log --oneline -1

sed -i 's|^PY = .*|PY = "/home/ubuntu/world/the-world/.venv/bin/python"|' /tmp/run_d3.py
grep -n '^PY = ' /tmp/run_d3.py

mkdir -p ~/world/d4
echo "[d4] 等设计 3 结束…"
for i in $(seq 1 480); do
  if grep -q ALLDONE /tmp/d3.log 2>/dev/null; then break; fi
  sleep 60
done
echo "[d4] 设计3 状态: $(grep -c ALLDONE /tmp/d3.log 2>/dev/null) ⇒ 起跑设计 4 $(date)"

setsid nohup /home/ubuntu/world/the-world/.venv/bin/python -u /tmp/run_d3.py \
  --tree /home/ubuntu/world/world_d4 \
  --out /home/ubuntu/world/d4 \
  --seeds 194,195 \
  --patches 1700 \
  --arms off,on \
  --ticks 20000 --sample 200 --par 2 --home-range \
  --ptb-modes go,rand --perturb-every 2000 --perturb-frac 0.5 \
  > /tmp/d4.log 2>&1 < /dev/null &
sleep 10
echo "== d4 日志 =="
cat /tmp/d4.log
echo "== 进程 =="
ps -eo pid=,rss=,cmd= | grep s3_memory | grep -v grep | cut -c1-90
