# -*- coding: utf-8 -*-
"""延迟 N 秒后进入待机（S3）—— 用于"数据已读完、但要让当前对话先落地"的收尾。

用法：python _suspend_delayed.py [秒数，默认 300]
理由：本机已跑完全部批（设计3 / g22 / 设计4），fish 要求"跑完休眠"；
     但休眠看守的 30 秒宽限期不足以让收尾报告落地，故改用可调延迟。
🔴 用 ctypes 直接调 powrprof.SetSuspendState（`rundll32` 在本机被安全策略黑名单）。
"""
import ctypes
import sys
import time

delay = int(sys.argv[1]) if len(sys.argv) > 1 else 300
print("will suspend in %d s" % delay, flush=True)
time.sleep(delay)
r = ctypes.windll.powrprof.SetSuspendState(0, 1, 0)
print("SetSuspendState -> %r" % r, flush=True)
