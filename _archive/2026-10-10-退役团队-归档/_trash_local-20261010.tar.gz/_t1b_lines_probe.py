# -*- coding: utf-8 -*-
"""T1b 侦察探针：`_step_population` 行级剖面（两法互证，仅观测不改引擎）。

法 1（setprofile）：对目标帧内的 C 调用逐行记账（行号 → 次数/累计秒）⇒ 相对构成；
法 2（微基准）：对逐个体小 op 在真实形状上重复计时 ⇒ 绝对 ns/次 × 逐个体 1 次
         ⇒ 重建"行级 ≈ ms/t"（可放大到 N）。

用法：PYTHONIOENCODING=utf-8 .venv/Scripts/python.exe _trash_local/_t1b_lines_probe.py [seed] [warm] [norm_ticks] [prof_ticks]
"""
import sys, os, time, linecache

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine

B = dict(rows=480, cols=960, patches=1700, pop=10000,
         speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
         bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)


def build(seed, mem_on=True):
    c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                        B["speed_max"], B["gain"], B["subdiv"], B["k"],
                        B["max_count"], B["rgm"],
                        bg_low_prod_frac=B["bg_low_prod_frac"],
                        bg_low_cap_mult=B["bg_low_cap_mult"])
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = True
    c.info_structure.memory_v2 = bool(mem_on)
    c.info_structure.memory_gradient = "orientation" if mem_on else "none"
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    return eng


seed = int(sys.argv[1]) if len(sys.argv) > 1 else 101
warm = int(sys.argv[2]) if len(sys.argv) > 2 else 800
norm_ticks = int(sys.argv[3]) if len(sys.argv) > 3 else 5
prof_ticks = int(sys.argv[4]) if len(sys.argv) > 4 else 2

eng = build(seed, True)
print(f"预热到 t={warm} …", flush=True)
for _ in range(warm):
    eng.step()
N = len(eng._flat)
print(f"N = {N}（t={warm} 后）", flush=True)

# ---------- 法 0：正常计时（无 profiler） ----------
t0 = time.perf_counter()
for _ in range(norm_ticks):
    eng.step()
dt = (time.perf_counter() - t0) / norm_ticks
print(f"[法0] 正常 {norm_ticks} tick：{dt*1e3:.1f} ms/t", flush=True)

# ---------- 法 1：setprofile 行级 C-调用剖面 ----------
code = SphereEngine._step_population.__code__
stats = {}          # lineno -> [n_calls, seconds]
stack = []


def prof(frame, event, arg):
    if event == "c_call":
        if frame.f_code is code:
            stack.append((frame.f_lineno, time.perf_counter()))
    elif event == "c_return" or event == "c_exception":
        if stack and frame.f_code is code:
            ln, t0c = stack.pop()
            s = stats.setdefault(ln, [0, 0.0])
            s[0] += 1
            s[1] += time.perf_counter() - t0c
    return prof


print(f"[法1] setprofile {prof_ticks} tick（含探针开销，只看行间相对构成）…", flush=True)
sys.setprofile(prof)
try:
    for _ in range(prof_ticks):
        eng.step()
finally:
    sys.setprofile(None)

tot_calls = sum(v[0] for v in stats.values())
tot_sec = sum(v[1] for v in stats.values())
print(f"  C 调用总数 = {tot_calls}（{tot_calls/prof_ticks/N:.1f}/个体·tick），"
      f"C 累计 = {tot_sec/prof_ticks*1e3:.0f} ms/t（含探针放大）")
rows = sorted(stats.items(), key=lambda kv: -kv[1][1])[:28]
print(f"  {'行号':>5} {'次/个体·t':>9} {'累计ms/t':>9}  源码")
for ln, (n, sec) in rows:
    src = (linecache.getline(SphereEngine._step_population.__code__.co_filename, ln)
           or "").strip()[:88]
    print(f"  {ln:>5} {n/prof_ticks/N:>9.1f} {sec/prof_ticks*1e3:>9.1f}  {src}")

# ---------- 法 2：逐 op 微基准（真实形状） ----------
import numpy as np

rng = np.random.default_rng(7)
nb = rng.integers(0, 480 * 960, size=8).astype(np.int64)
target = int(nb[3])
food_ratio = rng.random(480 * 960)
sig_present = (rng.random(480 * 960) > 0.95).astype(np.float64)
densities = rng.random(480 * 960)
marks = (rng.random(480 * 960) > 0.98).astype(np.int32)
idx = int(rng.integers(0, 9000))
genes = rng.random((30000, 24))
heading = rng.integers(0, 8, size=30000)
flat = rng.integers(0, 480 * 960, size=30000).astype(np.int64)
trust = rng.random(30000)
mem_az_row = rng.integers(-1, 8, size=4)
mem_dist_row = rng.random(4)
cos_mat = rng.random((8, 8))
perc = 0.7
soc = 0.2
sig_weight = 0.33
g8 = rng.random(8)
REP = 200000


def bench(name, fn, rep=REP):
    fn()  # 预热
    t0 = time.perf_counter()
    for _ in range(rep):
        fn()
    dt = (time.perf_counter() - t0) / rep
    print(f"   {name:<52} {dt*1e9:7.1f} ns/次")
    return dt


print(f"[法2] 微基准（重复 {REP} 次/op）：", flush=True)
res = {}
res["nb 查表（world.neighbors 整体）"] = bench(
    "world.neighbors(cell)（含查表+极点判定）", lambda: eng.world.neighbors(12345))
res["np.asarray(nb)（no-op 包装）"] = bench("np.asarray(已 array)", lambda: np.asarray(nb))
res["genes[idx, k]（2D 标量取）"] = bench("genes[idx, GENE] 2D 标量取",
                                        lambda: genes[idx, 5])
res["flat[idx]/heading[idx]/trust[idx]"] = bench(
    "flat[idx] / heading[idx] / trust[idx]（3 次取）",
    lambda: (flat[idx], heading[idx], trust[idx]))
res["fr = food_ratio[nb].copy()"] = bench("food_ratio[nb].copy()", lambda: food_ratio[nb].copy())
res["sp = sig_present[nb].copy()"] = bench("sig_present[nb].copy()", lambda: sig_present[nb].copy())
res["score 构造（4 组小 op）"] = bench(
    "score = perc*(fr*0.5+sp*w)+soc*dens[nb]",
    lambda: perc * (food_ratio[nb] * 0.5 + sig_present[nb] * sig_weight) + soc * densities[nb])
res["abs(g).max()>1e-9"] = bench("np.abs(g8).max()", lambda: float(np.abs(g8).max()))
res["score = score + perc*g"] = bench("score+g 组合（2 op）", lambda: g8 + perc * g8)
res["nb_sigs = marks[nb]"] = bench("marks[nb]（int32 取）", lambda: marks[nb])
res["(nb_sigs>0).any()"] = bench("(marks[nb]>0).any()", lambda: (marks[nb] > 0).any())
res["score.max()-score.min()"] = bench("score.max()-score.min()", lambda: g8.max() - g8.min())
res["np.argmax(score)"] = bench("np.argmax(score)", lambda: np.argmax(g8))
res["eq=(nb==t); eq.sum(); argmax"] = bench(
    "(nb==t) + sum + argmax（3 op）",
    lambda: (nb == target).sum() + np.argmax(nb == target))
res["heading 读+写"] = bench("heading[idx] 读+写", lambda: heading.__setitem__(idx, 3))
res["int(x) ×3"] = bench("int(np.int64) ×3", lambda: (int(flat[idx]), int(heading[idx]), int(trust[idx])))
res["list.append ×3"] = bench("append ×3", lambda: ([].append(idx), [].append(1), [].append(2)))

print(f"\n[法2] 逐个体重建（每行/op 每体 1 次；N={N}）：", flush=True)
tot = 0.0
for k, v in res.items():
    tot += v
print(f"  Σ 上述 op ≈ {tot*1e6:.2f} µs/个体 ⇒ @N={N} ≈ {tot*N*1e3:.1f} ms/t")
print(f"  对照：天平计数法内联段 ≈ 35.6 ms/t @N=2581（≈13.8 µs/个体）", flush=True)
print(f"  总用时 {time.perf_counter():.1f}s（进程累计）", flush=True)
