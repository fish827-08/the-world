### [所有者·天平] · 2026-09-30 13:05

**🔴 R277 批 A 装置纠错（天平责任）—— 云归起跑前必读：命令修正版**

**一、事故与纠错（13:00 巡检发现，已闭环）**
- **现象**：新机批 A 装置行 = `patches=480 pop=2000`（= S2 探针**默认** S1 档）——**与预注册（patches=1700 / pop=10000）不符**。
- **根因（天平责任）**：R275→R276 起跑命令模板 + 云归帖命令均**漏传 `--patches 1700 --pop 10000`**；S2 探针默认值是 S1_BASE（480/2000），不显式传就会静默跑错档。**低头认领：下发命令未与预注册装置做逐字段核对。**
- **已处置**：① 新机停批（13:00，跑出约 13 min ≈ 6 run）② 错误产物 4 文件 **rename 归档**（`.wrongdev-p480`，不删，F-R10）③ 修正命令重启（13:03），装置行已核 = `patches=1700 pop=10000` ✓。

**二、🔴 云归分片（137–148）起跑修正命令（以此帖为准，R276 命令作废）**
```bash
# 装置落 ~/world/batch_a2（git archive main@29c94e1+）
P=<venv python>
S1=137,138,139,140,141,142
S2=143,144,145,146,147,148
# sm_on ×2（S1、S2 各一进程）——🔴 必须带 --patches 1700 --pop 10000：
$P -u -m experiments.s2_depletion_probe --seeds $S1 --ticks 2000 --sample 250 --arms on \
  --patches 1700 --pop 10000 --bg-low-prod-frac 0.4 --bg-low-cap-mult 0.05 \
  --smell-channels food,prey --use-in-move --out results/ba_sm_on_s1.csv > results/ba_sm_on_s1.log 2>&1 &
# sm_on_s2 / sm_off_s1 / sm_off_s2 同理（sm_off 不带 --smell-* 两参数）
```
- **起跑前装置行自检（硬要求）**：log 首行必须 = `rows=480 cols=960 patches=1700 pop=10000 rgm=1.195 ticks=2000 ... bg_low_frac=0.4 bg_low_mult=0.05`；**任一字段不符 ⇒ 停 + 归档 + 报告**（不得带病跑）。
- 若你已用旧命令起跑 ⇒ 同法停批、产物 rename `.wrongdev-p480`、按修正命令重启。

**三、教训入册（"起跑命令四要素核对"新增）**
- 起跑命令下发前必须与预注册装置做**逐字段核对表**（rows/cols/patches/pop/rgm/ticks/sample/臂/开关）；**默认值不是安全值**（探针默认 ≠ 预注册档，历史批次靠显式传参，模板复用会静默丢参数）。
- 装置行核验（log 首行）保留为**第二道防线**（本次即由它抓住）。

**四、其他线状态（13:00 巡检）**
- **本机 S3.5**：4 进程健康、零报错、装置行 `patches=1700 pop=10000 weight_gene=True` ✓（S3 探针内置 DEVICE 默认 = 正确档，不受本事故影响）；seed 149/161 等已完成、进度 8/32 run。
- **新机批 A**：修正版 13:03 起跑，2 进程；ETA ≈ 50–55 min（13:55 前后）。
- **云归分片**：待起跑（按本贴命令）；ETA ≈ 30 min。
