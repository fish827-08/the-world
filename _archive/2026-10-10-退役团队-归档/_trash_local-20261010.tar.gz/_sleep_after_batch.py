# -*- coding: utf-8 -*-
"""等本机波1（169-172 on）跑完 ⇒ 校验产物 ⇒ 让机器进入待机（S3）。

由 Windows 任务计划程序触发（不依赖任何终端会话）。
- 波1 用旧落盘代码（行在 run 结束才写）⇒ 校验方式 = CSV 数据行数 == 30（t=2000..60000）。
- 任一异常（行数不对 / 超时）⇒ **不睡眠**，只写日志，避免把没跑完的批睡掉。
"""
import ctypes
import os
import subprocess
import sys
import time

ROOT = r"C:\Users\圣羽\Desktop\temp\tempCode\the-world"
RES = os.path.join(ROOT, "_rerun_logs", "flagship60k_on", "results")
LOG = os.path.join(ROOT, "_trash_local", "_sleep_after_batch.log")
PIDS = [8736, 23388, 5856, 21428, 9472]  # 波1 的真解释器 + 编排器
SEEDS = ["169", "170", "171", "172"]

_k32 = ctypes.WinDLL("kernel32", use_last_error=True)


def log(msg):
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}"
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def alive(pid):
    h = _k32.OpenProcess(0x1000, False, pid)
    if h:
        _k32.CloseHandle(h)
        return True
    return False


def csv_rows(seed):
    p = os.path.join(RES, f"f60k_{seed}_on.csv")
    if not os.path.exists(p):
        return -1
    with open(p, encoding="utf-8") as f:
        return max(0, sum(1 for _ in f) - 1)


log("[start] 收尾脚本启动（等待波1 结束）")
t0 = time.time()
while any(alive(p) for p in PIDS):
    if time.time() - t0 > 4 * 3600:
        log("[timeout] 等了 4h 仍未结束 ⇒ 放弃，不睡眠")
        sys.exit(1)
    time.sleep(60)

waited = int(time.time() - t0)
log(f"[done] 波1 进程全部退出（等待 {waited // 60} 分钟）")

rows = {s: csv_rows(s) for s in SEEDS}
log(f"[check] CSV 数据行数 = {rows}")
if any(v != 30 for v in rows.values()):
    log("[abort] 有 run 行数 != 30 ⇒ 产物不完整，不睡眠（请人工查看）")
    sys.exit(2)

log("[sleep] 产物校验通过（4×30 行）⇒ 进入待机 S3")
subprocess.run(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"])
log("[wake] 已唤醒（若这行出现说明睡眠未生效）")
