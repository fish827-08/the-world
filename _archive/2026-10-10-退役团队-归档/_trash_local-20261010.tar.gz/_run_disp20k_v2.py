# -*- coding: utf-8 -*-
"""R317 批跑：设计 1 的**混淆修正版**（亲子对 + 位置列 ⇒ 可做同格非亲缘对照）。

与 R316 批同装置同种子（便于与首跑对拍数字），唯一差别 = 探针 v5.1（pairs 侧车多
`birth_r/birth_c/cur_r/cur_c` 四列）。同种子**科学列应逐位复现** ⇒ 顺带当一次回归。
"""
import os
import subprocess
import time

ROOT = r"C:\Users\圣羽\Desktop\temp\tempCode\the-world"
TREE = os.path.join(ROOT, "_rerun_logs", "disp_20k_v2")
OUT = os.path.join(TREE, "results")
PY = os.path.join(ROOT, ".venv", "Scripts", "python.exe")
SEEDS = [193, 194, 195, 196]
TICKS = 20000
SAMPLE = 200


def cmd(seed, arm):
    c = [PY, "-u", "-m", "experiments.s3_memory_probe",
         "--rows", "480", "--cols", "960", "--pop", "10000", "--patches", "1700",
         "--seeds", str(seed), "--arms", arm,
         "--ticks", str(TICKS), "--sample", str(SAMPLE),
         "--home-range", "--hr-pairs",
         "--out", os.path.join(OUT, "disp_%d_%s.csv" % (seed, arm))]
    if arm == "on":
        c += ["--weight-gene"]
    return c


def wave(arm):
    procs = []
    for s in SEEDS:
        log = open(os.path.join(OUT, "disp_%d_%s.log" % (s, arm)), "w",
                   encoding="utf-8")
        procs.append((s, subprocess.Popen(cmd(s, arm), cwd=TREE,
                                          stdout=log,
                                          stderr=subprocess.STDOUT)))
    print("[wave %s] 起跑 %d 路" % (arm, len(procs)), flush=True)
    bad = []
    for s, p in procs:
        rc = p.wait()
        print("[wave %s] seed=%d rc=%d" % (arm, s, rc), flush=True)
        if rc != 0:
            bad.append(s)
    return bad


def main():
    os.makedirs(OUT, exist_ok=True)
    t0 = time.time()
    print("=== R317 批：seed %s × 2 臂 × %d tick，sample=%d ==="
          % (SEEDS, TICKS, SAMPLE), flush=True)
    bad1 = wave("off")
    print("[wave off] 完成 %.1f min" % ((time.time() - t0) / 60), flush=True)
    t1 = time.time()
    bad2 = wave("on")
    print("[wave on] 完成 %.1f min" % ((time.time() - t1) / 60), flush=True)
    print("ALLDONE 总耗时 %.1f min，失败: off=%s on=%s"
          % ((time.time() - t0) / 60, bad1, bad2), flush=True)


if __name__ == "__main__":
    main()
