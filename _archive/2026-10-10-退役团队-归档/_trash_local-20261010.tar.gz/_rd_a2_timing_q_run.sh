#!/usr/bin/env bash
# rd-A 静默复测：4 变体（base/wt × s0/s1）ABBA×4（每轮内 4 变体相邻、轮间序镜像；本机全静窗口）
set -u
BASE=/c/Users/圣羽/Desktop/temp/tempCode
PY=$BASE/the-world/.venv/Scripts/python.exe
BASET=$BASE/_wt_rd_base
WT=$BASE/_wt_lq_rd
LOG=$BASE/the-world/_trash_local/_rd_a2_timing_q_driver.log
export PYTHONIOENCODING=utf-8

run() {  # tree_path tag sparse
  local t=$1 tag=$2 sp=$3
  echo "=== [$(date '+%H:%M:%S')] run $tag (sparse=$sp) tree=$(basename $t) ===" >> "$LOG"
  ( cd "$t" && "$PY" -u _trash_local/_rd_a2_timing.py --sparse "$sp" --tag "$tag" \
      --out "_trash_local/_rd_a2_timing_q/$tag.json" >> "$LOG" 2>&1 )
  echo "--- exit=$? at $(date '+%H:%M:%S')" >> "$LOG"
}

# Q-R1（同窗 R1 序：b0, w1, b1, w0）
run "$BASET" base_s0_1 0
run "$WT"    wt_s1_1   1
run "$BASET" base_s1_1 1
run "$WT"    wt_s0_1   0
# Q-R2（同窗 R2 序：w0, b1, w1, b0）
run "$WT"    wt_s0_2   0
run "$BASET" base_s1_2 1
run "$WT"    wt_s1_2   1
run "$BASET" base_s0_2 0
# Q-R3（同 R1）
run "$BASET" base_s0_3 0
run "$WT"    wt_s1_3   1
run "$BASET" base_s1_3 1
run "$WT"    wt_s0_3   0
# Q-R4（同 R2）
run "$WT"    wt_s0_4   0
run "$BASET" base_s1_4 1
run "$WT"    wt_s1_4   1
run "$BASET" base_s0_4 0
echo "=== ALL DONE $(date '+%H:%M:%S') ===" >> "$LOG"
