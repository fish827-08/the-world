# -*- coding: utf-8 -*-
"""R291 §四 派工 ①（补跑）：note_tick / rotate / _regrowth_amount / growth_multiplier
行级剖面（setprofile，仅观测不改引擎）。

用法：PYTHONIOENCODING=utf-8 .venv/Scripts/python.exe _trash_local/_rd_lines_probe.py [seed] [warm] [prof_ticks]
⚠️ 本机在跑 60k 批跑 ⇒ 绝对值偏大；看行间相对构成。
"""
import sys, os, time, linecache

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine
from world.resource_dynamics import ResourceDynamics
from world.resource_field import ResourceField

seed = int(sys.argv[1]) if len(sys.argv) > 1 else 101
warm = int(sys.argv[2]) if len(sys.argv) > 2 else 800
prof_ticks = int(sys.argv[3]) if len(sys.argv) > 3 else 3

B = dict(rows=480, cols=960, patches=1700, pop=10000,
         speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
         bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)

c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                    B["speed_max"], B["gain"], B["subdiv"], B["k"],
                    B["max_count"], B["rgm"],
                    bg_low_prod_frac=B["bg_low_prod_frac"],
                    bg_low_cap_mult=B["bg_low_cap_mult"])
c.simulation.use_sim_core = False
c.resource_dynamics.enabled = True
c.info_structure.memory_v2 = True
c.info_structure.memory_gradient = "orientation"
eng = SphereEngine(c)
apply_post_build(eng, notes)
print(f"预热到 t={warm} …", flush=True)
for _ in range(warm):
    eng.step()
print(f"N = {len(eng._flat)}", flush=True)

TARGETS = {
    "note_tick": ResourceDynamics.note_tick.__code__,
    "rotate": ResourceDynamics.rotate.__code__,
    "regrowth": ResourceField._regrowth_amount.__code__,
    "growth_mult": ResourceDynamics.growth_multiplier.__code__,
}
by_code = {v: k for k, v in TARGETS.items()}
fname = {}
stack = []
stats = {}   # (func, lineno) -> [n_calls, seconds]


def prof(frame, event, arg):
    fd = by_code.get(frame.f_code)
    if fd is None:
        return prof
    if event == "c_call":
        stack.append((fd, frame.f_lineno, time.perf_counter()))
    elif event in ("c_return", "c_exception"):
        if stack and stack[-1][0] == fd:
            fd2, ln, t0 = stack.pop()
            s = stats.setdefault((fd2, ln), [0, 0.0])
            s[0] += 1
            s[1] += time.perf_counter() - t0
    return prof


print(f"[profile] {prof_ticks} tick（含探针放大，看相对构成）…", flush=True)
sys.setprofile(prof)
try:
    for _ in range(prof_ticks):
        eng.step()
finally:
    sys.setprofile(None)

for fn in ("regrowth", "note_tick", "rotate", "growth_mult"):
    rows = [(ln, s) for (f2, ln), s in stats.items() if f2 == fn]
    rows.sort(key=lambda kv: -kv[1][1])
    tot = sum(s[1] for _, s in rows)
    code = TARGETS[fn]
    print(f"— {fn}：C 累计 {tot / prof_ticks * 1e3:.1f} ms/t（{prof_ticks} tick）", flush=True)
    for ln, (nn, sec) in rows[:12]:
        src = (linecache.getline(code.co_filename, ln) or "").strip()[:86]
        print(f"  {ln:>5} {nn / prof_ticks:>7.1f} 次/t {sec / prof_ticks * 1e3:>8.2f} ms/t  {src}",
              flush=True)
print("完成。", flush=True)
