# -*- coding: utf-8 -*-
"""通用批跑器（R318）：N 路并行 + 可选"等前置批跑完再开工"。

用途：设计 3（扫斑块几何）在两台机上各跑 12 run；本机那份要等 R317 跑完才能起。

用法：
  python _run_design3.py --tree <冻结树> --out <产物目录> --seeds 194,195
      --patches 400,1700,4000 --arms off,on --ticks 20000 --sample 200 --par 2
      [--wait-glob "<dir>/*.csv" --wait-rows 101]   # 先等这些文件都达标再起跑
"""
import argparse
import glob
import os
import subprocess
import sys
import time

PY = r"C:\Users\圣羽\Desktop\temp\tempCode\the-world\.venv\Scripts\python.exe"


def wait_for(wait_glob, wait_rows, poll=60, max_h=8.0):
    if not wait_glob:
        return
    t0 = time.time()
    print("[wait] 等前置批完成（%s 需 %d 行）…" % (wait_glob, wait_rows), flush=True)
    while time.time() - t0 < max_h * 3600:
        fs = sorted(glob.glob(wait_glob))
        if fs:
            done = 0
            for f in fs:
                try:
                    with open(f, "rb") as fh:
                        done += 0
                    with open(f, encoding="utf-8") as fh:
                        n = sum(1 for _ in fh)
                    if n >= wait_rows:
                        done += 1
                except OSError:
                    pass
            if fs and done == len(fs) and len(fs) >= 8:
                print("[wait] 前置批完成（%d/%d）⇒ 开工" % (done, len(fs)), flush=True)
                # 再等 60s 让文件句柄收尾
                time.sleep(60)
                return
        time.sleep(poll)
    print("[wait] 超时 ⇒ 仍开工（请人工核对前置批状态）", file=sys.stderr, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tree", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seeds", required=True)
    ap.add_argument("--patches", required=True)
    ap.add_argument("--arms", default="off,on")
    ap.add_argument("--ticks", type=int, default=20000)
    ap.add_argument("--sample", type=int, default=200)
    ap.add_argument("--par", type=int, default=2)
    ap.add_argument("--rows", type=int, default=480)
    ap.add_argument("--cols", type=int, default=960)
    ap.add_argument("--pop", type=int, default=10000)
    ap.add_argument("--home-range", action="store_true")
    ap.add_argument("--wait-glob", default="")
    ap.add_argument("--wait-rows", type=int, default=101)
    ap.add_argument("--wait-max-h", type=float, default=8.0,
                    help="等前置批的最长小时数（默认 8）")
    ap.add_argument("--ptb-modes", default="none",
                    help="扰动模式列表（none/go/rand），逗号分隔；非 none 时自动加 "
                         "--perturb/--perturb-every/--perturb-frac")
    ap.add_argument("--perturb-every", type=int, default=2000)
    ap.add_argument("--perturb-frac", type=float, default=0.5)
    ap.add_argument("--g22-inits", default="",
                    help="初始 g22 扰动列表（逗号分隔的浮点；R320 双端扰动实验）。"
                         "空 = 不干预")
    a = ap.parse_args()

    # 🔴 必须转绝对路径：子进程以 `cwd=a.tree` 启动 ⇒ 相对 `--out` 会落到
    #   `<tree>/<out>` 的嵌套目录里（实测踩过：CSV 写进
    #   `_rerun_logs/disp_20k_v2/_rerun_logs/d3_local/`，而日志在预期位置）
    a.tree = os.path.abspath(a.tree)
    a.out = os.path.abspath(a.out)

    os.makedirs(a.out, exist_ok=True)
    wait_for(a.wait_glob, a.wait_rows, max_h=a.wait_max_h)

    _g22 = [float(x) for x in a.g22_inits.split(",") if x.strip()] or [None]
    jobs = []
    for g22v in _g22:
        for ptb in a.ptb_modes.split(","):
            for arm in a.arms.split(","):
                for pc in [int(x) for x in a.patches.split(",") if x.strip()]:
                    for sd in [int(x) for x in a.seeds.split(",") if x.strip()]:
                        jobs.append((arm, pc, sd, ptb.strip(), g22v))

    print("=== 共 %d 个 run，%d 路并行 ===" % (len(jobs), a.par), flush=True)
    t0 = time.time()
    running = []
    fails = []
    while jobs or running:
        while jobs and len(running) < a.par:
            arm, pc, sd, ptb, g22v = jobs.pop(0)
            tag = "d3_p%d_%d_%s%s%s" % (pc, sd, arm,
                                        "" if ptb == "none" else "_" + ptb,
                                        "" if g22v is None else "_g%.1f" % g22v)
            cmd = [PY, "-u", "-m", "experiments.s3_memory_probe",
                   "--rows", str(a.rows), "--cols", str(a.cols),
                   "--pop", str(a.pop), "--patches", str(pc),
                   "--seeds", str(sd), "--arms", arm,
                   "--ticks", str(a.ticks), "--sample", str(a.sample),
                   "--out", os.path.join(a.out, tag + ".csv")]
            if a.home_range:
                cmd += ["--home-range"]
            if arm == "on":
                cmd += ["--weight-gene"]
            if ptb != "none":
                cmd += ["--perturb", ptb,
                        "--perturb-every", str(a.perturb_every),
                        "--perturb-frac", str(a.perturb_frac)]
            if g22v is not None:
                cmd += ["--g22-init", str(g22v)]
            log = open(os.path.join(a.out, tag + ".log"), "w", encoding="utf-8")
            running.append((tag, subprocess.Popen(cmd, cwd=a.tree,
                                                  stdout=log,
                                                  stderr=subprocess.STDOUT)))
            print("[start] %s  (%.1f min)" % (tag, (time.time() - t0) / 60), flush=True)
        time.sleep(5)
        still = []
        for tag, p in running:
            if p.poll() is None:
                still.append((tag, p))
            else:
                print("[done ] %s rc=%d  (%.1f min)" % (tag, p.returncode,
                                                        (time.time() - t0) / 60),
                      flush=True)
                if p.returncode != 0:
                    fails.append(tag)
        running = still
    print("ALLDONE 总耗时 %.1f min，失败 %s" % ((time.time() - t0) / 60, fails),
          flush=True)


if __name__ == "__main__":
    main()
