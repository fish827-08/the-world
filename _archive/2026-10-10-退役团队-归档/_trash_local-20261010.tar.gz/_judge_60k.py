# -*- coding: utf-8 -*-
"""R318 · 旗舰 60k 终判（严格按 `docs/tasks/派工-旗舰60k-20260930.md` §三 预注册口径）。

预注册判据（工单内锁死）：
  · B 主门：60k 终点 `g22_mean_gen3p` 配对差（on−off），逐 seed 配对；
            SD_null = **off 臂种子间 SD**（自校准漂移基线）；
            通过线 = **|中位差| > 2×SD_null 且 ≥6/8 同向**（方向如实报，正负皆有效）
  · B 支持：差值的**时间趋势**（on−off 差 @ 每 10k）；Slope>0 = 定向增强（强证据）
  · A/C：只报不判
  · gen3+ 为主指标、latest 为辅
数据：本机 169–172（本机同机配对）+ 云机器 165–168（云机器同机配对）= 8 对干净配对。
"""
import csv
import os
import numpy as np

LOCAL_OFF = "_rerun_logs/flagship60k_local/results/f60k_%d_off.csv"
LOCAL_ON = "_rerun_logs/flagship60k_on/results/f60k_%d_on.csv"
CLOUD_OFF = "_rerun_logs/flagship60k_cloud/results/f60k_%d_off.csv"
CLOUD_ON = "_rerun_logs/flagship60k_cloud/results/f60k_%d_on.csv"

PAIRS = [(s, "cloud") for s in (165, 166, 167, 168)] + \
        [(s, "local") for s in (169, 170, 171, 172)]


def rows(p):
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def fl(x):
    try:
        v = float(x)
        return v if v == v else float("nan")
    except (TypeError, ValueError):
        return float("nan")


def load(seed, machine, arm):
    p = (CLOUD_OFF if arm == "off" else CLOUD_ON) if machine == "cloud" \
        else (LOCAL_OFF if arm == "off" else LOCAL_ON)
    p = p % seed
    if not os.path.exists(p):
        return None
    return rows(p)


print("=" * 100)
print("【0】完整性校验（预注册要求：30 采样点、末 tick=60000）")
print("=" * 100)
ok = True
D = {}
for s, m in PAIRS:
    a, b = load(s, m, "off"), load(s, m, "on")
    for arm, r in (("off", a), ("on", b)):
        if r is None:
            print("  %-6s seed=%d %s  缺文件" % (m, s, arm))
            ok = False
            continue
        D[(s, m, arm)] = r
        last = r[-1]
        flag = "" if (len(r) == 30 and last["tick"] == "60000") else "  ❌"
        if flag:
            ok = False
        print("  %-6s seed=%d %-3s 行=%2d 末tick=%-6s K=%-7s 支=%-2s%s" % (
            m, s, arm, len(r), last["tick"], last["pop"],
            "A" if fl(last["abs_cap"]) < 3.3e6 else "B", flag))
print("  ⇒ 完整性：%s" % ("✅ 全通过" if ok else "❌ 有缺"))
print()

print("=" * 100)
print("【B 主门】60k 终点 g22_mean_gen3p 配对差（on − off）")
print("=" * 100)
print("%-6s %-5s %-4s %12s %12s %12s" % ("机器", "seed", "支", "off(gen3p)", "on(gen3p)", "差(on-off)"))
diffs = []
offv = []
for s, m in PAIRS:
    a, b = D.get((s, m, "off")), D.get((s, m, "on"))
    if not a or not b:
        continue
    xo, xn = fl(a[-1]["g22_mean_gen3p"]), fl(b[-1]["g22_mean_gen3p"])
    br = "A" if fl(b[-1]["abs_cap"]) < 3.3e6 else "B"
    offv.append(xo)
    diffs.append(xn - xo)
    print("%-6s %-5d %-4s %12.4f %12.4f %+12.4f" % (m, s, br, xo, xn, xn - xo))
diffs = np.array(diffs)
offv = np.array(offv)
sd_null = float(np.nanstd(offv, ddof=1))
med = float(np.nanmedian(diffs))
pos = int((diffs > 0).sum())
n = len(diffs)
print()
print("  配对差 中位数 = %+.4f ｜ 同向 %d/%d（正 %d）" % (med, max(pos, n - pos), n, pos))
print("  SD_null（off 臂种子间 SD）= %.4f  ⇒ 2×SD_null = %.4f" % (sd_null, 2 * sd_null))
gate1 = abs(med) > 2 * sd_null
gate2 = max(pos, n - pos) >= 6
print("  门 1  |中位差| > 2×SD_null ：%s（%.4f vs %.4f）" % ("✅ 过" if gate1 else "❌ 不过", abs(med), 2 * sd_null))
print("  门 2  ≥6/8 同向          ：%s（%d/%d）" % ("✅ 过" if gate2 else "❌ 不过", max(pos, n - pos), n))
print("  ⇒ **B 主门 %s**" % ("通过 ✅" if (gate1 and gate2) else "未通过 ❌"))
print()
# 按支分层（只报不判，供解释）
print("  --- 按支分层（报告用，非判据）---")
for br in ("A", "B"):
    sub = []
    for s, m in PAIRS:
        b = D.get((s, m, "on"))
        if not b:
            continue
        if ("A" if fl(b[-1]["abs_cap"]) < 3.3e6 else "B") != br:
            continue
        a = D.get((s, m, "off"))
        sub.append(fl(b[-1]["g22_mean_gen3p"]) - fl(a[-1]["g22_mean_gen3p"]))
    if sub:
        print("   支 %s（n=%d）：中位差 %+.4f ｜ 各值 %s" % (
            br, len(sub), float(np.median(sub)), np.round(sub, 4).tolist()))

print()
print("=" * 100)
print("【B 支持】on−off 差值的时间趋势（每 10k）")
print("=" * 100)
TS = ["10000", "20000", "30000", "40000", "50000", "60000"]
print("%-6s %-5s %s" % ("机器", "seed", "  ".join("%9s" % t for t in TS)))
trend = []
for s, m in PAIRS:
    a, b = D.get((s, m, "off")), D.get((s, m, "on"))
    if not a or not b:
        continue
    ra = {x["tick"]: x for x in a}
    rb = {x["tick"]: x for x in b}
    line = []
    vals = []
    for t in TS:
        if t in ra and t in rb:
            v = fl(rb[t]["g22_mean_gen3p"]) - fl(ra[t]["g22_mean_gen3p"])
            vals.append(v)
            line.append("%+9.4f" % v)
        else:
            line.append("%9s" % "-")
            vals.append(float("nan"))
    trend.append(vals)
    print("%-6s %-5d %s" % (m, s, "  ".join(line)))
T = np.array(trend, dtype=float)
if T.size:
    xs = np.arange(len(TS), dtype=float)
    slopes = []
    for r in T:
        msk = ~np.isnan(r)
        if msk.sum() >= 3:
            slopes.append(float(np.polyfit(xs[msk], r[msk], 1)[0]))
    print()
    print("  各 seed 斜率（每 10k 的差值变化）：%s" % np.round(slopes, 5).tolist())
    print("  斜率中位 = %+.5f  ⇒ %s" % (
        float(np.median(slopes)),
        "Slope>0（定向增强）= **强证据**" if np.median(slopes) > 0 else "Slope≤0 ⇒ 无定向增强"))

print()
print("=" * 100)
print("【A/C 只报不判】承载力与生态读数（60k 终点）+ 性能")
print("=" * 100)
print("%-6s %-5s %-4s %8s %8s %10s %12s %12s %10s" % (
    "机器", "seed", "支", "K_off", "K_on", "K倍数", "未访斑块off", "未访斑块on", "ms/t_on"))
Ks = []
for s, m in PAIRS:
    a, b = D.get((s, m, "off")), D.get((s, m, "on"))
    if not a or not b:
        continue
    br = "A" if fl(b[-1]["abs_cap"]) < 3.3e6 else "B"
    ko, kn = fl(a[-1]["pop"]), fl(b[-1]["pop"])
    Ks.append((br, ko, kn))
    print("%-6s %-5d %-4s %8.0f %8.0f %10s %12.4f %12.4f %10.1f" % (
        m, s, br, ko, kn, ("%.2fx" % (kn / ko)) if ko > 0 else "-",
        fl(a[-1]["never_visited_patch_cell_frac"]),
        fl(b[-1]["never_visited_patch_cell_frac"]), fl(b[-1]["ms_per_tick"])))
print()
print("  K 倍数：A 支 %s ｜ B 支 %s" % (
    np.round([kn / ko for br, ko, kn in Ks if br == "A" and ko > 0], 2).tolist(),
    np.round([kn / ko for br, ko, kn in Ks if br == "B" and ko > 0], 2).tolist()))
