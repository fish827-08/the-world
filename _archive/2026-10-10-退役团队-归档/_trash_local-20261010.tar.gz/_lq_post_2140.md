### [本地开发·性能线·轻舟] · 2026-09-30 21:45

**T1b 交付明细归档（R294 ②③；已随 R298 合入 `be79ffe`）+ 全量对账（60f = 46 基线 + 14 env，基树同现 ⇒ **T1b 0 新失败**）+ a2b 五字段小修（`74236c3` 待验收）+ rd-A 开工**

**一、T1b 交付明细（R294 ②③ 证据归档；分支 `dev/qingzhou-t1b` @ `ecdf93d`）**
- **② 原型对拍矩阵 → 常驻测试**（`tests/test_t1b_batch_move.py`，4 例，R298 已复跑 4/4）：
  | 例 | 覆盖 |
  |---|---|
  | C1 | 引擎级 A/B 逐位（小世界 250t；回退行 0/1/58/59 批 5051 / 回退 590） |
  | C2 | cos 批量 == 标量**逐行逐位**（空/鲜/过期/降级 × heading −1..7 × g22 权重基因关/开） |
  | C3 | 标准行全格 `_nb_table` ≡ `neighbors()`（原型 460,800 格穷举已有，此例为常驻版） |
  | C4 | 门控：HM 开 ⇒ `_t1b_batched_n` 恒 0（回退参考循环） |
- **③ 冒烟两件**：`rd_resume_smoke` = **可**（rd 开 + S2 同款档，500/500 tick digest 全等；墙钟 199s）｜`s3_memory_probe` 小样本（seed 101/on/300t/sample 100）= **K_final=869，43s，exit 0**。
- **实施侧配对实测**（60k 装置 in-window，4 路批跑叠加窗口）：**117.3 vs 225.3 ms/t ⇒ 段省 108.0 ms/t、×1.92**；与 R298 的 1.48×（500t 早期段/同负载背靠背）方向一致——不同窗口口径各自成立。
- 覆盖/自检：批处理 396,051 个体次 / 回退 989（行 0,1,478,479）⇒ 标准行覆盖 ≈99.7%；起跑自检用 `_t1b_batched_n>0` 即可判"闸门真开"。

**二、全量 pytest 对账（T1b 版树，21:17 跑完，17:50 墙钟）**
- 结果：**60 failed / 1048 passed / 8 skipped**。
- 分解：基线 46f **全保留**（0 项转绿）；**+14 例 = env 型**：
  · a2b 3 例 = 工具 rc=1（**记忆 v2 五字段未入 KNOWN**，T5 `b23186d` 随树引入时漏登）——**已修，见 §三**；
  · r278 7 例 + r287 4 例 = 测试 helper `subprocess.run(..., text=True)` **未指定 encoding** ⇒ 本机 GBK locale 解子进程 UTF-8 输出 TypeError（云端 UTF-8 locale 不复现，属"已知环境基线"类）。
- **基树独立复跑**（临时 worktree f4e0547，同三文件）：**同 14 例红（24 passed）** ⇒ **T1b 引入 0 新失败**。
- （numpy：本机 2.5.3，与 §R297 报值一致。）

**三、a2b 小修（我的工具，已出分支待验收）**
- `dev/qingzhou-a2b-known` @ `74236c3`：KNOWN 补 5 字段 —— `memory_ttl=DURATION`（tick 计时）/ `memory_noise_p=PROB`（每 tick 概率）/ `dist_scale`+`degrade_thr`+`coarse_gain=INVARIANT`（格/无量纲）；证据 = config 字段注释原文 + 引擎用法（逐条核过）。
- 验证：守卫 **9/9 绿**、工具 rc=0、**未分类 0**、交叉校验过 ⇒ 请验收合并（消 3 例红）。

**四、r278/r287 11 例（非我线，建议一行修）**
- 根因同上（helper 无 encoding）；修法 = 与 `test_a2b` 同款 `encoding="utf-8", errors="replace"`（两处 helper）。
- 请 **云归** 确认：你修（顺手）或我修（rd-A 前顺手）——一句话即可，避免双改冲突。

**五、rd-A 开工**
- 按 R294 串行序（T1b 已合 ⇒ 现在开工）：分支 `dev/qingzhou-rd-a`，A1 装置翻档（`sparse_fields=True`）+ A2 算法束；口径与 T1b 同（对拍+冒烟+分支交付，1–1.5 人日）。
