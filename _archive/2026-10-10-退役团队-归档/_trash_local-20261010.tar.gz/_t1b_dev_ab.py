# -*- coding: utf-8 -*-
"""T1b 交付证据：60k 装置上的**引擎级逐位对拍 + 配对计时**。

A = T1b 开（`_batch_move_on=True`，默认）；B = 纯参考循环（`_batch_move_on=False`）。
同种子、同时钟窗：预热 WARM tick（交错步进）⇒ 全状态逐位对比；
再交替 5×20 tick 计时取中位 ⇒ 窗口内配对比值（本机 4 路 60k 批跑在跑，绝对数不可比）。

用法：PYTHONIOENCODING=utf-8 .venv/Scripts/python.exe _trash_local/_t1b_dev_ab.py [warm] [reps]
"""
import sys, os, time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine

B = dict(rows=480, cols=960, patches=1700, pop=10000,
         speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
         bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)


def build(seed, t1b):
    c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                        B["speed_max"], B["gain"], B["subdiv"], B["k"],
                        B["max_count"], B["rgm"],
                        bg_low_prod_frac=B["bg_low_prod_frac"],
                        bg_low_cap_mult=B["bg_low_cap_mult"])
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = True
    c.info_structure.memory_v2 = True
    c.info_structure.memory_gradient = "orientation"
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    eng._batch_move_on = bool(t1b)
    return eng


WARM = int(sys.argv[1]) if len(sys.argv) > 1 else 400
REPS = int(sys.argv[2]) if len(sys.argv) > 2 else 5
TK = 20

t0 = time.time()
a = build(101, True)
b = build(101, False)
print(f"建双引擎 {time.time() - t0:.0f}s；预热 {WARM} tick（交错步进）…", flush=True)

# 批/回退路径覆盖统计（a 侧）
orig = SphereEngine._move_decide_v2_batch
stat = {"batch": 0, "fall": 0, "ticks_fall": 0, "edge_rows": set()}


def wrap(self, mi, targets, rand_choice, food_ratio, sig_present, densities, rep_w,
         c_idx, c_hdo, c_hdn):
    sel = orig(self, mi, targets, rand_choice, food_ratio, sig_present, densities,
               rep_w, c_idx, c_hdo, c_hdn)
    if sel is None:
        stat["fall"] += len(mi)
        stat["ticks_fall"] += 1
        return sel
    nb_ = int(sel.sum())
    stat["batch"] += nb_
    stat["fall"] += int(len(mi) - nb_)
    if nb_ < len(mi):
        stat["ticks_fall"] += 1
        stat["edge_rows"].update(
            np.unique(self._flat[mi[~sel]] // self.world.cols).tolist())
    return sel


SphereEngine._move_decide_v2_batch = wrap
t0 = time.time()
for t in range(1, WARM + 1):
    a.step()
    b.step()
    if t % 100 == 0:
        print(f"  t={t} N={len(a._flat)} 墙钟 {time.time() - t0:.0f}s", flush=True)
SphereEngine._move_decide_v2_batch = orig

print("—" * 72)
print(f"预热完成：N={len(a._flat)}（t={WARM}）｜T1b 累计批处理 {a._t1b_batched_n}"
      f"｜A 侧批/回退 = {stat['batch']}/{stat['fall']}（含回退的 tick {stat['ticks_fall']}，"
      f"回退行 {sorted(stat['edge_rows'])}）")

names = ("_flat", "_heading", "_mem_az", "_mem_dist", "_mem_tick", "_mem_degraded",
         "_mem_food", "_energy", "_genes", "_age", "_id", "_trust", "_giveup_ct")
bad = [n for n in names if not np.array_equal(getattr(a, n), getattr(b, n))]
print(f"【逐位对拍】{WARM} tick 后全状态：{'✓ 全绿' if not bad else '✗ 分岔: ' + str(bad)}"
      f"（{len(names)} 个数组）")
print(f"  记忆填充槽 {(a._mem_az >= 0).sum()}／{a._mem_az.size}；tick={int(a.tick)}")

# ── 配对计时（交替、同窗）──────────────────────────────────────────────
ta, tb = [], []
for k in range(REPS):
    t0 = time.perf_counter()
    for _ in range(TK):
        a.step()
    ta.append(time.perf_counter() - t0)
    t0 = time.perf_counter()
    for _ in range(TK):
        b.step()
    tb.append(time.perf_counter() - t0)
ma = float(np.median(ta)) / TK * 1e3
mb = float(np.median(tb)) / TK * 1e3
print("—" * 72)
print(f"【配对计时】{REPS}×{TK} tick 交替（N={len(a._flat)}，窗口内口径 ms/t）")
print(f"  A  T1b 开：{ma:.1f} ms/t（中位）｜B 参考循环：{mb:.1f} ms/t")
print(f"  ⇒ 段省 {mb - ma:.1f} ms/t，比值 ×{mb / ma:.2f}（本机有 4 路 60k 批跑叠加）")
bad2 = [n for n in names if not np.array_equal(getattr(a, n), getattr(b, n))]
print(f"  计时后复核逐位：{'✓ 全绿' if not bad2 else '✗ ' + str(bad2)}"
      f"（t={int(a.tick)}，N={len(a._flat)}）")
print("完成。", flush=True)
