# -*- coding: utf-8 -*-
"""T1 对拍：两个 s3 探针 CSV 的逐格比较（排除计时列 ms_per_tick）。"""
import sys
import csv


def load(path):
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    return rows


a_path, b_path = sys.argv[1], sys.argv[2]
skip = {"ms_per_tick"}
a, b = load(a_path), load(b_path)
assert len(a) == len(b), f"行数不同：{len(a)} vs {len(b)}"
n_cmp = n_diff = 0
for i, (ra, rb) in enumerate(zip(a, b)):
    assert ra.keys() == rb.keys()
    key = (ra["seed"], ra["arm"], ra["tick"])
    assert key == (rb["seed"], rb["arm"], rb["tick"]), f"行 {i} 键错位"
    for k in ra:
        if k in skip:
            continue
        n_cmp += 1
        if ra[k] != rb[k]:
            n_diff += 1
            if n_diff <= 20:
                print(f"DIFF {key} {k}: base={ra[k]} new={rb[k]}")
print(f"比较 {n_cmp} 格（排除 {sorted(skip)}），差异 {n_diff} 格")
print("VERDICT:", "BITWISE-IDENTICAL ✅" if n_diff == 0 else "DIFF ❌")
