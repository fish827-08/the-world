# -*- coding: utf-8 -*-
"""g22 初始值 vs 种群数量：把 0.1/0.9 双臂与**默认 g22(≈0.5)** 在**同一 tick** 上比。

数据：
  默认 g22  = 云机器 60k 臂 `the-world-data/r323_20261002/d3_cloud/...`？否——
              默认参考取 **60k 云机器臂** `_rerun_logs/flagship60k_cloud/results/f60k_{165..168}_{on,off}.csv`
              （t=20000 行；同一旧装置档、同一 rd/T1b 代码线）
  扰动 g22  = `_rerun_logs/g22_local/d3_p1700_{165,167}_{on,off}_g{0.1,0.9}.csv`
"""
import csv
import glob
import os

import numpy as np


def rows(p):
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def at(p, tick):
    r = rows(p)
    for x in r:
        if x["tick"] == str(tick):
            return x
    return None


def fl(x, k):
    try:
        return float(x[k])
    except Exception:
        return float("nan")


CLOUD = "_rerun_logs/flagship60k_cloud/results"
T = 20000

print("=== 默认 g22（≈0.5）参考：60k 云机器臂 @ t=%d ===" % T)
base = {}
for sd in (165, 166, 167, 168):
    for arm in ("on", "off"):
        p = os.path.join(CLOUD, "f60k_%d_%s.csv" % (sd, arm))
        if not os.path.exists(p):
            continue
        x = at(p, T)
        if x is None:
            print("  %d %s: 无 t=%d 行" % (sd, arm, T))
            continue
        base[(sd, arm)] = (fl(x, "pop"), fl(x, "g22_mean"))
        print("  seed %d %-3s  K=%7d   g22_mean=%.4f" % (sd, arm, fl(x, "pop"), fl(x, "g22_mean")))

print()
print("=== 扰动 g22 的双端 vs 默认（同 tick=%d；g22 越大越靠右）===" % T)
print("%-6s %-4s %9s %9s %10s %9s %9s %10s" %
      ("seed", "臂", "K@g22=.1", "K@默认", "K@g22=.9", "差(.1-默认)", "差(.9-默认)", "默认g22实测"))
for sd in (165, 167):
    for arm in ("on", "off"):
        ks = {}
        for ini in (0.1, 0.9):
            p = "_rerun_logs/g22_local/d3_p1700_%d_%s_g%.1f.csv" % (sd, arm, ini)
            x = at(p, T) if os.path.exists(p) else None
            ks[ini] = fl(x, "pop") if x else float("nan")
        bk, bg = base.get((sd, arm), (float("nan"), float("nan")))
        d1 = ks[0.1] - bk
        d9 = ks[0.9] - bk
        print("%-6d %-4s %9.0f %9.0f %10.0f %+10.0f %+10.0f %10.4f"
              % (sd, arm, ks[0.1], bk, ks[0.9], d1, d9, bg))
print()
print("=== 相对差（%）===")
for sd in (165, 167):
    for arm in ("on", "off"):
        ks = {}
        for ini in (0.1, 0.9):
            p = "_rerun_logs/g22_local/d3_p1700_%d_%s_g%.1f.csv" % (sd, arm, ini)
            x = at(p, T) if os.path.exists(p) else None
            ks[ini] = fl(x, "pop") if x else float("nan")
        bk = base.get((sd, arm), (float("nan"),))[0]
        if not np.isfinite(bk) or bk == 0:
            continue
        print("  seed %d %-3s：g22=.1 → %+7.1f%% ｜ g22=.9 → %+7.1f%%"
              % (sd, arm, (ks[0.1] - bk) / bk * 100, (ks[0.9] - bk) / bk * 100))
print()
print("=== 另：本批 g22_local 自身的 g22 实测均值（确认初始值生效）===")
for p in sorted(glob.glob("_rerun_logs/g22_local/*.csv")):
    x2 = at(p, 2000)
    x20 = at(p, T)
    if x2 and x20:
        print("  %-34s g22@2k=%.4f → @20k=%.4f  K@20k=%d"
              % (os.path.basename(p)[:-4], fl(x2, "g22_mean"), fl(x20, "g22_mean"), fl(x20, "pop")))
