#!/usr/bin/env bash
# rd-A 交付：4 变体（main/wt × s0/s1）ABBA×2 平衡序列（窗口内配对计时）
set -u
BASE=/c/Users/圣羽/Desktop/temp/tempCode
PY=$BASE/the-world/.venv/Scripts/python.exe
MAIN=$BASE/the-world
WT=$BASE/_wt_lq_rd
LOG=$MAIN/_trash_local/_rd_a2_timing_driver.log
export PYTHONIOENCODING=utf-8

run() {  # tree_path tag sparse
  local t=$1 tag=$2 sp=$3
  echo "=== [$(date '+%H:%M:%S')] run $tag (sparse=$sp) tree=$(basename $t) ===" >> "$LOG"
  ( cd "$t" && "$PY" -u _trash_local/_rd_a2_timing.py --sparse "$sp" --tag "$tag" \
      --out "_trash_local/_rd_a2_timing/$tag.json" >> "$LOG" 2>&1 )
  echo "--- exit=$? at $(date '+%H:%M:%S')" >> "$LOG"
}

run "$MAIN" main_s0_1 0
run "$WT"   wt_s1_1   1
run "$MAIN" main_s1_1 1
run "$WT"   wt_s0_1   0
run "$WT"   wt_s0_2   0
run "$MAIN" main_s1_2 1
run "$WT"   wt_s1_2   1
run "$MAIN" main_s0_2 0
echo "=== ALL DONE $(date '+%H:%M:%S') ===" >> "$LOG"
