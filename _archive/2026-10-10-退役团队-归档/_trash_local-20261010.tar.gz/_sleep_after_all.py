# -*- coding: utf-8 -*-
"""跑完本机全部批后自动休眠（fish 2026-10-01 指示："跑完本机休眠"）。

等两批各自产出完整文件数：
  · `_rerun_logs/d3_local2/*.csv`  → 12 个（设计 3 本机分片，seed 196/197）
  · `_rerun_logs/g22_local/*.csv`   →  8 个（g22 双端扰动，seed 165/167）
每个文件需 ≥101 行（表头 + 100 个采样点，末 tick=20000）。

🔴 为什么用 ctypes 而不是 `rundll32.exe powrprof.dll,SetSuspendState`：
   后者被本机安全策略列入**黑名单程序**，从任何 shell/子进程启动都会被拦。
   `ctypes.windll.powrprof.SetSuspendState` 是**直接 DLL 调用**，不启动任何被禁程序。
"""
import ctypes
import glob
import os
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPEC = [("_rerun_logs/d3_local2/*.csv", 12, 101),
        ("_rerun_logs/g22_local/*.csv", 8, 101),
        ("_rerun_logs/d4_local/*.csv", 16, 61)]
LOG = os.path.join(ROOT, "_trash_local", "_sleep_after_all.log")
MAX_H = 14.0


def log(msg: str) -> None:
    with open(LOG, "a", encoding="utf-8") as f:
        f.write("[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))


def n_lines(p: str) -> int:
    with open(p, encoding="utf-8") as fh:
        return sum(1 for _ in fh)


def ready() -> tuple:
    ok = True
    parts = []
    for pat, need_n, need_rows in SPEC:
        fs = sorted(glob.glob(os.path.join(ROOT, pat)))
        good = 0
        for f in fs:
            try:
                if n_lines(f) >= need_rows:
                    good += 1
            except OSError:
                pass
        parts.append("%s=%d/%d" % (os.path.basename(os.path.dirname(pat)), good, need_n))
        if good < need_n:
            ok = False
    return ok, " ".join(parts)


def main() -> None:
    log("=== 启动：等待本机三批跑完（d3_local2 12 个 / g22_local 8 个 / d4_local 16 个）===")
    t0 = time.time()
    while time.time() - t0 < MAX_H * 3600:
        ok, msg = ready()
        log("等待中 " + msg)
        if ok:
            log("✅ 两批全部完成 ⇒ 30 秒后进入待机（S3 sleep）")
            time.sleep(30)
            try:
                r = ctypes.windll.powrprof.SetSuspendState(0, 1, 0)
                log("SetSuspendState 返回 %r ⇒ 已发出待机指令" % r)
            except Exception as e:  # noqa: BLE001
                log("❌ 待机调用失败：%r —— 请手动休眠" % e)
            return
        time.sleep(120)
    log("❌ 超时 %.0fh 未完成 ⇒ 不待机（请人工检查）" % MAX_H)


if __name__ == "__main__":
    main()
