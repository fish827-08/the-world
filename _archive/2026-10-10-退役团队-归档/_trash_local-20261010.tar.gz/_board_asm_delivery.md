### [本地开发·性能线] · 2026-09-29 13:08（Asia/Shanghai）

**R258 §二 交付：ASM（行动选择模式仲裁，规格 §三）完成 —— 分支 `dev/qingzhou-asm` @ `cbd2c60`，未合 main**

**一、交付内容（分支 `dev/qingzhou-asm` @ `cbd2c60`；🔴 等验收，未合 main —— R260 §五）**

10 文件 +658/−66，另新增 2 文件（`tests/test_action_selection.py` 611 行 / `experiments/asm_perf_probe.py` 153 行）：

- **配置** `ActionSelectionConfig`：`mode="fusion"`（默认）/ `"arbitration"`；参数 `base_explore=0.2 / hyst=0.15 / hold_ticks=20 / w_feed=1.0 / w_hunger=0.5 / w_flee=1.0 / w_join=0.5`；`__post_init__` 断言 + `fingerprint()` 入指纹 + `from_dict` 白名单回退。
- **引擎**：新增两状态数组 `_mode (n,) int8` + `_mode_tick (n,) int32`（`__slots__` 四处登记 + 快照存/恢复 + 出生增长/死亡压缩）；`_asm_update_modes(P)` **每 tick 单点前置**（WTA + 严格迟滞 `>` + 最小锁定；公式见 `AGENT.md §13.12`）；**三路径同式**：Python 参考循环 / Rust `movement.rs`（`lib.rs` +5 参透传）/ 向量化 `_move_decide_batch`。
- **气味读接口**：`smell_field.channel_norm(cells, ch)` 单通道归一化读；复用 `_smell_stamp/_smell_gen` **逐代缓存**机制（三通道与 `combined` 同代同失效）。
- **构造期 fail-loud**：前置 `smell.channels ⊇ {food,risk,kin}` + **12 项互斥表**（同开 = 仲裁静默吞并其一 ⇒ 一律硬报错）。
- **a4 接线**：`--asm-mode` 等 **8 个 CLI** + `--smell-channels`（含"未传≠空串"的续跑对账语义）+ `switches` 9 字段 / `result.asm` 读数块回写（fusion 档 ⇒ `null` = 未适用，R120 口径）。
- **登记**：`tools/tick_denomination_audit.py`（`hold_ticks`=DURATION，其余 7 项 INVARIANT，`mode` 亦登记）；`AGENT.md §13.12` 纪元段。

**二、验收数据（`[实测]` 本机）**

- **靶向**：`tests/test_action_selection.py` **34/34**（迟滞严格边界/锁定/dithering 反例/排他性/逐通道变异检查/双路径 Python-vs-Rust 逐位/快路径 lockstep `_move_decide_batch`/快照往返/出生-死亡登记/fail-loud 11 例/配置四件套/`channel_norm` 裁剪）；ASM+HM 联合 **45 passed**。
- **C7 自审**：`tools/self_audit.py digest` ⇒ **252 passed，exit 0 ⇒ 关档逐位等价（基线未漂移）**。`mode="fusion"`（默认）⇒ 仲裁段整段不执行（无 RNG、无状态改变）⇒ 逐位等价的**构造性**保证。
- **全量**：`48 failed / 1020 passed / 8 skipped`（327.6s）= **存量 45** + 3 例 `test_a2b_tick_audit_coverage`〔memv2 五字段未分类，**非本线**〕；**ASM 归因 = 0**（逐项差分：48 项与 09-29 11:46 基线同集，唯 r98 一项现稳定通过）。
  - 存量 45 = 36 例 `test_f_r21_presets` + 5 例 `test_share_lock` + 3 例 `test_221_snap_shard` + 1 例 `test_f_r10_f_r12`。
  - ⚠️ **附注（归因时顺手定位）**：36 例 r21 = **测试侧 GBK 解码缺陷**——`_script_flags()` 用 `subprocess.run(text=True)`（本机 locale=GBK）解码 a4 的 UTF-8 `--help` 输出 ⇒ reader 线程 `UnicodeDecodeError` ⇒ 开关集为空 ⇒ 全部 a4 preset 判红。**与 ASM 无关**（改动前同红 36），修复窗口归测试侧/后续裁定。
- **守卫回归（本批自曝自修）**：本批最初写的 3 处互斥守卫 `getattr` 兜底（`softmax_tau/perception_noise/w_fear_health` 用了"机制关"旧闸值 0.0）被 `test_config_fallback_audit` 判红 ⇒ 已按 **R208 §三/R213 §六** 改为 == config 默认（0.15/0.05/0.5）⇒ 该文件 **8/8 绿**；C7 digest 重跑仍 **252 passed**。
- **性能（配对实测）** —— `experiments/asm_perf_probe.py --ticks 150 --reps 3 --freeze-repro`；480×960 / patches=1700 / 三通道**两臂同开** / N 2921→624(py)·734(rust) / `concurrency=1` / `[实测]`本机。`--freeze-repro` = 繁殖基因置满 ⇒ N 轨迹贴近，**隔离"N 轨迹差"混淆**：

  | 路径 | Δ 中位 | 极差 | 相对 |
  |---|---|---|---|
  | py（`use_sim_core=False`） | **+1.78 ms/tick** | +1.59 .. +1.90 | +5.7% .. +7.0% |
  | rust（`use_sim_core=True`） | **+1.75 ms/tick** | +1.07 .. +1.79 | +5.3% .. +9.0% |

  其中**纯前置段** `_asm_update_modes` ≈ **0.40 ms/tick** @N≈2.9k（三通道读 ≈0.27 ms）；剩余 ≈ 模式内目标替换带来的路径差。
  - ⚠️ 口径：Δ = 两臂**实测**差，含两臂 N 轨迹残差 ⇒ 非"纯机制税"上限；设计稿 §四-5 `[估算]` "<0.5 ms/tick" **不成立**（实测 ≈2 ms/tick 量级，需按此口径预算）。
  - 产物：`results/asm_v1/asm_perf.json`（**数据仓**，主仓 gitignore）。

**三、🔴 需重建 sim_core（提交后同时解锁天平的 g22 运行时验证）**

`movement.rs`/`lib.rs` 有真实改动 + `step_movement` **新增 5 个 pyo3 参数**（签名变化）⇒ 未重建环境 `use_sim_core=True` 走旧语义 ⇒ **必须 maturin 重编**（本机已重编 ✅；产物不入库，教训⑰）。

**🔴 且：本线在途改动已全部提交 ⇒ 工作区无阻塞 ⇒ 天平可立即重编 `sim_core` + 跑 g22 注册表/接线/C7 验收 + ASM 运行时验证**（R260 §二 挂起项解除）。

**四、批 A 边界与遗留（规格 §3.3）**

- 批 A 红线：① **信号不进模式**（既不进显著度、也不进模式内目标 ⇒ 批 A 信号→移动整段断开）；② **HM ② 在仲裁档下关闭**（`_hm2_on = _hm_on ∧ ¬_asm_on`，由 `w_hunger` 承担，避免双重调制）。
- 批 B 遗留：`×(1+fear_gene)` 乘子；阈值/权重走基因位（8 位）；信号→模式切换。
- 纪律：🔴 fusion vs arbitration 是**构造级行为差 ⇒ 禁跨纪元比较**；仲裁与互斥表内机制**不得同批混跑**（构造期守卫拦）。

**五、下一件**

等验收/裁定。可选顺位（等派工）：巨石拆分（R260 §三 立项：`sphere_engine.py` 6250 行按域拆，**纯重构逐位等价**，窗口 = "轻舟完成记忆基因位+模式仲裁后，批跑间歇期"——ASM 交付即窗口到）。

—— [本地开发·性能线·轻舟] 2026-09-29 13:08
