# -*- coding: utf-8 -*-
"""晨检快读：g22 双端扰动 + 设计 4（go/rand）头号数字。"""
import csv
import glob
import os

def rows(p):
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))

def f(x, k, d=float("nan")):
    try:
        return float(x[k])
    except Exception:
        return d

print("=" * 78)
print("g22 双端扰动（seed 165=A支 / 167=B支；初始 0.1 与 0.9）")
print("-" * 78)
print("%-26s %8s %9s %9s %9s" % ("run", "K_end", "g22@2k", "g22@10k", "g22@20k"))
for p in sorted(glob.glob("_rerun_logs/g22_local/*.csv")):
    r = rows(p)
    n = os.path.basename(p)[:-4]
    d = {x["tick"]: x for x in r}
    def g(t):
        return f(d[t], "g22_mean") if t in d else float("nan")
    print("%-26s %8s %9.4f %9.4f %9.4f"
          % (n, r[-1]["pop"], g("2000"), g("10000"), g("20000")))

print()
print("设计 4（go=移除出走型 / rand=等量随机；12k tick）")
print("-" * 78)
print("%-28s %7s %10s %10s %10s %10s" % ("run", "K_end", "dr_stay", "dr_go", "out_frac", "g22_end"))
for p in sorted(glob.glob("_rerun_logs/d4_local/*.csv")):
    r = rows(p)
    n = os.path.basename(p)[:-4]
    x = r[-1]
    out_frac = 1.0 - f(x, "hr_hist_0_5") if x.get("hr_hist_0_5") else float("nan")
    print("%-28s %7s %10.4f %10.4f %10.4f %10.4f"
          % (n, x["pop"], f(x, "hr_dr_stay"), f(x, "hr_dr_go"), out_frac, f(x, "g22_mean")))

print()
print("=" * 78)
print("设计 3 本机（12 个文件应各 101 行）")
print("-" * 78)
for p in sorted(glob.glob("_rerun_logs/d3_local2/*.csv")):
    r = rows(p)
    print("  %-26s rows=%d  K_end=%s" % (os.path.basename(p)[:-4], len(r) + 1, r[-1]["pop"]))
