# -*- coding: utf-8 -*-
"""R303 冒烟：run 中途被杀 ⇒ 已采样行是否保住（sample 级落盘验证）。"""
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY = os.path.join(ROOT, ".venv", "Scripts", "python.exe")
OUT = os.path.join(ROOT, "_trash_local", "_smoke_r303.csv")
SNAP = os.path.join(ROOT, "_trash_local", "_smoke_r303_snap")
LOG = os.path.join(ROOT, "_trash_local", "_smoke_r303.log")
os.makedirs(SNAP, exist_ok=True)
if os.path.exists(OUT):
    os.remove(OUT)

cmd = [PY, "-u", "-m", "experiments.s3_memory_probe",
       "--rows", "60", "--cols", "120", "--pop", "300", "--patches", "50",
       "--ticks", "30000", "--sample", "100", "--save-every", "100",
       "--snapshot-dir", SNAP, "--out", OUT, "--arms", "off", "--seeds", "999"]
logf = open(LOG, "w", encoding="utf-8")
p = subprocess.Popen(cmd, cwd=ROOT, stdout=logf, stderr=subprocess.STDOUT)
print(f"[spawn] pid={p.pid}")
time.sleep(40)
subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)],
               capture_output=True)
time.sleep(2)
logf.close()
n = 0
if os.path.exists(OUT):
    with open(OUT, encoding="utf-8") as f:
        n = max(0, sum(1 for _ in f) - 1)
print(f"[result] 中途被杀后 CSV 数据行数 = {n}  （0 = 修复未生效 / >0 = sample 级落盘生效）")
sys.exit(0 if n > 0 else 1)
