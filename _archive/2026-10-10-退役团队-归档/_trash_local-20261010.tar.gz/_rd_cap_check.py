# A2 前置核验：rd.capacity_from_base() vs 装置档 ResourceField._capacity 逐位一致性
#   装置 = S3/flagship（bg_low_prod_frac=0.4, bg_low_cap_mult=0.05, rd on, bgzero）
#   用法：cd _wt_lq_rd && python ../the-world/_trash_local/_rd_cap_check.py
import sys
from pathlib import Path

WT = Path(r"C:\Users\圣羽\Desktop\temp\tempCode\_wt_lq_rd")
sys.path.insert(0, str(WT))

import numpy as np  # noqa: E402

from experiments.steady_k_probe import make_cfg, apply_post_build  # noqa: E402
from simulation.sphere_engine import SphereEngine  # noqa: E402


def build(rd_on: bool, sparse: bool):
    c, notes = make_cfg(
        42, 480, 960, 200, 1700, True, 0.125, 0.125, 80, 2.5, 30000, 1.195,
        bg_low_prod_frac=0.4, bg_low_cap_mult=0.05,
    )
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = bool(rd_on)
    if sparse:
        c.simulation.sparse_fields = True
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    return eng


def report(tag: str, eng):
    f = eng.resources
    rd = eng._rd
    cap0 = np.asarray(f._capacity, dtype=np.float64)
    cap_rd = rd.capacity_from_base()
    neq = cap0 != cap_rd
    m = np.asarray(f._patch_mask, dtype=bool)
    low = np.asarray(getattr(f, "_bg_low_mask", np.zeros_like(m)), dtype=bool)
    bg = ~m
    print(f"\n[{tag}] rd.enabled={rd.enabled} sparse={eng._sparse_fields} lazy={f._lazy}")
    print(f"  p_mult={rd.patch_capacity_mult!r} b_mult={rd.bg_capacity_mult!r}")
    print(f"  cap==cap_rd ? {not neq.any()}   mismatch={int(neq.sum())}")
    if neq.any():
        for name, sel in (("patch", m), ("bg", bg), ("bg_low", low)):
            bad = sel & neq
            print(f"    {name}: cells={int(sel.sum())} mismatch={int(bad.sum())}")
        i = int(np.flatnonzero(neq)[0])
        print(f"    first i={i} field={cap0[i]!r} rd={cap_rd[i]!r} "
              f"patch={bool(m[i])} low={bool(low[i])}")


eng_off = build(rd_on=False, sparse=False)
report("rd OFF (field baseline)", eng_off)
del eng_off

eng_on = build(rd_on=True, sparse=False)
report("rd ON  (device)", eng_on)
