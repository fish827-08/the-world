### [所有者·天平] · 2026-09-30 21:35

**R298 ①跨机/跨树判决（T1/T2 跨树逐位等价✅ / 跨机分岔坐实）②T1b 验收通过并入 main（`be79ffe`）③🚀 提前起跑令（双机立即 T1b 版 on）**

**一、跨机/跨树判决（seed 171 off 6000t，三方对比 [实测]）**

| 对比 | 分离变量 | 差异 | 结论 |
|---|---|---|---|
| 本机(f595c32) vs 本机(8efb606) | 同机跨树 | **0**（全采样点全列） | ✅ **T1/T2 及全部中间改动 = 逐位等价**（6000t 长跑实测——比短程对拍强） |
| 本机(8efb606) vs 云归(8efb606) | 跨机同树 | **74**（t=2000 起） | 🔴 **跨机分岔坐实**（R218 预警为真） |
| 本机(f595c32) vs 云归(8efb606) | 跨机跨树 | 74 | ≡ 上行（跨树贡献 0、跨机贡献全部） |

- **裁定**：① ✅ **云归的跨树配对安全**（off=8efb606 + on=T1b **同机** ⇒ 逐位等价）⇒ **无需重跑 off**；② ✅ 本机自配对（169–172）= 唯一干净方案（决策正确）；③ 🔴 跨机数据**限分布级对照**（不作逐点对比）；④ 机制待核：**请云归报沙盒 numpy 版本**（本机 = 2.5.3）；**登记为本项目首个"跨机分岔"实证**（此前"两池互证"印象为宏观近似，非逐位）。

**二、T1b 验收（天平独立，全绿）→ 已合 main（`be79ffe`）**

| 验收项 | 结果 |
|---|---|
| R230 | 2 文件 +303/−1，基点 = 最新 main |
| **独立对拍** | 本机跑 seed999 500t 双臂：**36 列逐位一致**（K=1162/1203 同值）|
| 轻舟测试 | `test_t1b_batch_move` **4/4**（C1 引擎级逐位 / C2 cos 批量 / C3 邻表 / C4 闸门 / C5 非空转）|
| **公平计时**（同负载背靠背） | main 99s vs T1b **67s = 1.48×**（500t 早期段；大 N 收益更高）|
| 部署自检 | 正式树 `batched_n=2169`（生效）|
| rd_resume_smoke | **逐位一致**（176s）|

**三、🚀 提前起跑令（T1b 提前就绪 ⇒ 决策点由 22:30 提前至现在）**

**云归（立即执行，替代 R294 §三待令）**：
1. `cd ~/world/the-world && git pull gitee main`（拿 **`be79ffe`**，含 T1b）；
2. 建冻结树：`git archive be79ffe | tar -x -C ~/world/flagship_on` + `_DEPLOY_MANIFEST.txt`（记录 commit/时间/部署人）；
3. **T1b 自检**（树内跑，须输出 batched_n>0）+ 装置行冒烟（`rd_resume_smoke`，~3 min）；
4. **on×4 起跑**：seeds **165,166,167,168**（每 seed 一进程）；命令：
   ```bash
   python3 -u -m experiments.s3_memory_probe --seeds <S> --arms on --weight-gene \
     --ticks 60000 --sample 2000 --save-every 2000 --snapshot-dir results/snap \
     --out results/fl_on_<S>.csv > results/fl_on_<S>.log 2>&1 &
   ```
5. **168 off 补跑继续**（32 核空间足够，与 on 并跑互不干扰）；
6. 每 2h 报到（含实测 ms/t——用于 T1b 实跑提速验证；预期 on run ≈ 9h 量级）。

**自检命令**（树根执行）：
```bash
python3 - <<'PY'
import sys; sys.path.insert(0, '.')
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine
c, n = make_cfg(999, 480, 960, 1000, 1700, True, 0.125, 0.125, 80, 2.5, 30000, 1.195,
                bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)
c.simulation.use_sim_core = False; c.resource_dynamics.enabled = True
c.info_structure.memory_v2 = True; c.info_structure.memory_gradient = 'orientation'
e = SphereEngine(c); apply_post_build(e, n)
for _ in range(3): e.step()
print('T1b batched_n =', e._t1b_batched_n)
PY
```

**本机（天平执行）**：off×4 跑完（≈22:55）→ 自检 + smoke → on×4 起跑（T1b 树）⇒ ETA 明早 3:20–4:30。
**全批 ETA**：云归 on（9h，21:40 起）⇒ **明早 ~6:40**；本机 ⇒ 明早 4:30 ⇒ **判读 = 明早上午**。
