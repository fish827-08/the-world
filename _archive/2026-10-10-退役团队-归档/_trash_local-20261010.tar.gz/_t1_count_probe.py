# -*- coding: utf-8 -*-
"""T1 计数器探针：实测 memv2 热点调用形状（只计数 + 计时，不改引擎行为）。

回答：
  - S3 装置里 nb 是 VN-4 还是 Moore-8？（决定方向表设计）
  - _cell_dir_slot 的调用来源拆分（cos 循环 vs write 循环 vs 其他）
  - _memory_egocentric_cos 早退率（avg dirs/call vs 候选数）
  - step_one / write 的次数与批大小
"""
import sys, os, time
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine

B = dict(rows=480, cols=960, patches=1700, pop=10000,
         speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
         bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)


def build(seed, mem_on=True):
    c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                        B["speed_max"], B["gain"], B["subdiv"], B["k"],
                        B["max_count"], B["rgm"],
                        bg_low_prod_frac=B["bg_low_prod_frac"],
                        bg_low_cap_mult=B["bg_low_cap_mult"])
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = True
    c.info_structure.memory_v2 = bool(mem_on)
    c.info_structure.memory_gradient = "orientation" if mem_on else "none"
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    return eng


eng = build(104, True)
ifc = eng.config.info_structure
print("=== 配置事实 ===")
print("info_structure.enabled =", getattr(ifc, "enabled", None))
print("perception_radius =", ifc.perception_radius,
      "| perception_noise =", ifc.perception_noise,
      "| softmax_tau =", ifc.softmax_tau)
print("memory_v2 =", ifc.memory_v2, "| _mem_noise =", eng._mem_noise,
      "| _mem_ttl =", eng._mem_ttl, "| _mem_gain =", eng._mem_gain)
print("_ars_on =", eng._ars_on, "| rows =", eng.world.rows, "| cols =", eng.world.cols)

stats = Counter()
tim = Counter()
cos_cand = Counter()
wr_sizes = []
b_sizes = []
ctx = {"src": None}

orig_dirs = SphereEngine._cell_dir_slot
orig_cos = SphereEngine._memory_egocentric_cos
orig_step = SphereEngine._mem_v2_step_one
orig_write = SphereEngine._mem_v2_write
orig_pairs = SphereEngine._cell_dir_slot_pairs
orig_batch = SphereEngine._mem_v2_step_batch


def _w_dirs(self, cur, target):
    t0 = time.perf_counter()
    r = orig_dirs(self, cur, target)
    dt = time.perf_counter() - t0
    src = ctx["src"] or "other"
    stats["dirs:" + src] += 1
    tim["dirs:" + src] += dt
    return r


def _w_cos(self, idx, cur, nb, heading_now):
    t0 = time.perf_counter()
    ctx["src"] = "cos"
    r = orig_cos(self, idx, cur, nb, heading_now)
    ctx["src"] = None
    tim["cos"] += time.perf_counter() - t0
    stats["cos"] += 1
    cos_cand[len(nb)] += 1
    return r


def _w_step(self, idx, hd_old, hd_new, steps):
    t0 = time.perf_counter()
    r = orig_step(self, idx, hd_old, hd_new, steps)
    tim["step"] += time.perf_counter() - t0
    stats["step"] += 1
    return r


def _w_write(self, idx_arr, cur_flat, tick):
    t0 = time.perf_counter()
    wr_sizes.append(int(len(idx_arr)))
    ctx["src"] = "write"
    r = orig_write(self, idx_arr, cur_flat, tick)
    ctx["src"] = None
    tim["write"] += time.perf_counter() - t0
    stats["write"] += 1
    return r


def _w_pairs(self, cur_arr, tar_arr):
    t0 = time.perf_counter()
    r = orig_pairs(self, cur_arr, tar_arr)
    dt = time.perf_counter() - t0
    src = ctx["src"] or "other"
    stats["pairs:" + src] += 1
    tim["pairs:" + src] += dt
    return r


def _w_batch(self, idx_list, hd_old_list, hd_new_list, steps):
    t0 = time.perf_counter()
    r = orig_batch(self, idx_list, hd_old_list, hd_new_list, steps)
    tim["batch"] += time.perf_counter() - t0
    stats["batch"] += 1
    b_sizes.append(int(len(idx_list)))
    return r


for name, f in (("_cell_dir_slot", _w_dirs), ("_memory_egocentric_cos", _w_cos),
                ("_mem_v2_step_one", _w_step), ("_mem_v2_write", _w_write),
                ("_cell_dir_slot_pairs", _w_pairs),
                ("_mem_v2_step_batch", _w_batch)):
    setattr(SphereEngine, name, f)

WARM = int(sys.argv[1]) if len(sys.argv) > 1 else 20
T = int(sys.argv[2]) if len(sys.argv) > 2 else 30
for _ in range(WARM):
    eng.step()
stats.clear(); tim.clear(); cos_cand.clear(); wr_sizes.clear(); b_sizes.clear()
t_all0 = time.perf_counter()
for _ in range(T):
    eng.step()
t_all = time.perf_counter() - t_all0

print(f"\n=== t{WARM+1}-{WARM+T} 统计（{T} tick）===")
print(f"N = {len(eng._flat)}")
print(f"总墙钟 = {t_all/T*1e3:.1f} ms/tick")
print(f"cos calls/tick = {stats['cos']/T:.1f}")
print("cos 候选数分布 (len(nb) -> 次数):", dict(cos_cand))
tot_dirs = sum(v for k, v in stats.items() if k.startswith("dirs"))
print(f"dir_slot 总调用/tick = {tot_dirs/T:.1f}")
for k in sorted(stats):
    if k.startswith("dirs"):
        print(f"  {k}: {stats[k]/T:.1f}/t, 累计 {tim[k]/T*1e3:.2f} ms/t")
avg_dirs_per_cos = (stats["dirs:cos"] / stats["cos"]) if stats["cos"] else float("nan")
print(f"avg dirs/cos call = {avg_dirs_per_cos:.3f}")
print(f"cos 自身时耗 = {tim['cos']/T*1e3:.2f} ms/t（含嵌套 dir_slot：{tim['dirs:cos']/T*1e3:.2f}）"
      f" ⇒ 非 dirs 部分 ≈ {(tim['cos']-tim['dirs:cos'])/T*1e3:.2f} ms/t")
print(f"step_one calls/tick = {stats['step']/T:.1f}, 时耗 = {tim['step']/T*1e3:.2f} ms/t"
      f"（{tim['step']/max(stats['step'],1)*1e6:.2f} µs/call）")
print(f"write calls/tick = {stats['write']/T:.2f}, 时耗 = {tim['write']/T*1e3:.2f} ms/t")
if wr_sizes:
    s = sorted(wr_sizes)
    print(f"write 批大小(idx_arr) min/med/max = {s[0]}/{s[len(s)//2]}/{s[-1]}"
          f", 均值 = {sum(s)/len(s):.1f}")
    print(f"write 内层 dir_slot/write = {stats['dirs:write']/max(stats['write'],1):.1f}")
print(f"step_batch calls/tick = {stats['batch']/T:.2f}, 时耗 = {tim['batch']/T*1e3:.2f} ms/t"
      f"（{tim['batch']/max(stats['batch'],1)*1e6:.0f} µs/批）")
if b_sizes:
    s = sorted(b_sizes)
    print(f"batch 批大小 min/med/max = {s[0]}/{s[len(s)//2]}/{s[-1]}"
          f", 均值 = {sum(s)/len(s):.1f}")
for _k in sorted(stats):
    if _k.startswith("pairs"):
        print(f"  {_k}: {stats[_k]/T:.2f}/t, 累计 {tim[_k]/T*1e3:.2f} ms/t")
if stats["dirs:other"]:
    print(f"⚠️ 其他来源 dir_slot = {stats['dirs:other']/T:.1f}/t")
