# -*- coding: utf-8 -*-
"""R290 大 N 性能审计：seed101 on 臂跑到 t=800（N~2800）后，计数器法测 100t 热点构成。
目的：S3 实测 on-off 差 ~1100ms/t @N6000（超小样本外推 10x）——定位大 N 真实热点。"""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine
from world.resource_dynamics import ResourceDynamics
from world.resource_field import ResourceField
from world.signal_field import SignalField

def build(seed, mem_on=True):
    B = dict(rows=480, cols=960, patches=1700, pop=10000,
             speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
             bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)
    c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                        B["speed_max"], B["gain"], B["subdiv"], B["k"], B["max_count"], B["rgm"],
                        bg_low_prod_frac=B["bg_low_prod_frac"], bg_low_cap_mult=B["bg_low_cap_mult"])
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = True
    c.info_structure.memory_v2 = bool(mem_on)
    c.info_structure.memory_gradient = "orientation" if mem_on else "none"
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    return eng

# ---- patch 计数器 ----
stats = {}
def wrap(cls, name, label=None):
    if not hasattr(cls, name):
        print(f"  [skip] {cls.__name__}.{name} 不存在"); return
    orig = getattr(cls, name)
    tag = label or f"{cls.__name__}.{name}"
    def f(*a, **k):
        t0 = time.perf_counter()
        r = orig(*a, **k)
        dt = time.perf_counter() - t0
        s = stats.setdefault(tag, [0, 0.0]); s[0] += 1; s[1] += dt
        return r
    setattr(cls, name, f)

TARGETS = [
    (SphereEngine, "_advance_one_tick"), (SphereEngine, "_step_population"),
    (SphereEngine, "_memory_egocentric_cos"), (SphereEngine, "_mem_v2_write"),
    (SphereEngine, "_mem_v2_step_batch"), (SphereEngine, "_mem_v2_step_one"),
    (SphereEngine, "_update_patch_centroid_incremental"), (SphereEngine, "_build_patch_centroid"),
    (SphereEngine, "_update_pleasure"),
    (ResourceDynamics, "note_tick"), (ResourceDynamics, "rotate"),
    (ResourceDynamics, "capacity_from_base"), (ResourceDynamics, "growth_multiplier"),
    (ResourceField, "_regrowth_amount"), (SignalField, "tick"),
]
for cls, name in TARGETS:
    wrap(cls, name)

eng = build(101, mem_on=True)
print("[预热] 跑到 t=800 …", flush=True)
t_all = time.perf_counter()
for i in range(800):
    eng.step()
    if (i + 1) % 200 == 0:
        print(f"  t={i+1} 累计 {(time.perf_counter()-t_all):.0f}s", flush=True)

for s in stats.values():  # 清预热计数
    s[0] = 0; s[1] = 0.0

N0 = getattr(eng, "_alive_count", None) or getattr(eng, "n_alive", "?")
print(f"[测量] t800→900，N≈{N0}", flush=True)
T = 100
t0 = time.perf_counter()
for _ in range(T):
    eng.step()
dt = time.perf_counter() - t0
print(f"\n===== 窗口结果（无 profile 放大）=====")
print(f"总墙钟: {dt:.1f}s / {T}t = {dt/T*1e3:.1f} ms/t")
print(f"{'方法':>44} {'次/t':>10} {'ms/t':>9} {'占比':>7} {'µs/次':>8}")
items = sorted(stats.items(), key=lambda kv: -kv[1][1])
for tag, (n, tot) in items:
    if n == 0: continue
    mspt = tot / T * 1e3
    print(f"{tag:>44} {n/T:>10.1f} {mspt:>9.2f} {tot/dt*100:>6.1f}% {tot/n*1e6:>8.1f}")
covered = sum(t for _, (n, t) in stats.items() if n > 0)
print(f"\n计数器覆盖: {covered/dt*100:.1f}% | 未覆盖: {(1-covered/dt)*100:.1f}%")
