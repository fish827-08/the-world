# -*- coding: utf-8 -*-
"""seed117 off 臂 cProfile（t100-150）：定位"随时间增长的世界级成本"。"""
import sys, os, time, cProfile, pstats, io
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine

def build(seed):
    B = dict(rows=480, cols=960, patches=1700, pop=10000,
             speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
             bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)
    c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                        B["speed_max"], B["gain"], B["subdiv"], B["k"], B["max_count"], B["rgm"],
                        bg_low_prod_frac=B["bg_low_prod_frac"], bg_low_cap_mult=B["bg_low_cap_mult"])
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = True
    c.info_structure.memory_v2 = False
    c.info_structure.memory_gradient = "none"
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    return eng

eng = build(117)
print("[预热] 跑到 t=100 …", flush=True)
t_all = time.perf_counter()
for i in range(100):
    eng.step()
    if (i+1) % 50 == 0:
        print(f"  t={i+1} 累计 {time.perf_counter()-t_all:.0f}s", flush=True)

for _ in range(10):
    eng.step()
T = 50
pr = cProfile.Profile()
pr.enable()
t0 = time.perf_counter()
for _ in range(T):
    eng.step()
dt = time.perf_counter() - t0
pr.disable()
print(f"\n===== seed117 off t110-160: {dt:.1f}s / {T}t = {dt/T*1e3:.1f} ms/t =====")
s = io.StringIO()
st = pstats.Stats(pr, stream=s); st.sort_stats("tottime"); st.print_stats(30)
# 过滤输出
for line in s.getvalue().split("\n"):
    if "ncalls" in line or "tottime" in line or line.strip() == "":
        continue
    if any(k in line for k in ["resource_", "sphere_engine", "numpy", "regrow", "{method", "function"]):
        print(line)
