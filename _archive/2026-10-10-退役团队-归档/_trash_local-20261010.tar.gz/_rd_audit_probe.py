# -*- coding: utf-8 -*-
"""R291 §四 派工 ①：rd 成本审计探针（仅观测/原型，不改引擎）。

内容：
A. 逐段计时（class 级 patch，逐 tick 累计）：_regrowth_amount / growth_multiplier /
   note_tick / rotate / capacity_from_base（按调用点分账）/ _promote_same_row；
   并把 temperature / _ensure_cache 拆出去看看 12ms 里有多少是温度链。
B. 低垂果实：capacity 合并（cache）等价性 —— 每 tick 比对 "note_tick 处的重算值"
   与 "上一 tick 引擎回写处的值"（掩码未变应逐位相等）⇒ 验证缓存方案可行。
C. regrowth 子集链再评估：enable_lazy() 在 60k 装置上的前提检查 + 脏格占比 +
   子集/全场耗时；再深拷贝引擎做 **40 tick 逐位 A/B**（全场 vs 惰性子集）。
D. 微基准：pow(x,1.0) 跳过 / 三路 where → 预计算 LUT / 温度全量 gather 免拷贝 /
   ones 复用 / rotate 扫描成本（真实数组、真实形状）。

用法：PYTHONIOENCODING=utf-8 .venv/Scripts/python.exe _trash_local/_rd_audit_probe.py [seed] [warm] [timed_ticks] [ab_ticks]
⚠️ 本机在跑 6 路 60k 批跑 ⇒ 绝对 ms 偏大；本探针以**同进程配对比值**为准。
"""
import sys, os, time, hashlib, copy

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine
from world.resource_field import ResourceField
from world.resource_dynamics import ResourceDynamics
from world.light_and_temperature import LightAndTemperature

seed = int(sys.argv[1]) if len(sys.argv) > 1 else 101
warm = int(sys.argv[2]) if len(sys.argv) > 2 else 800
timed_ticks = int(sys.argv[3]) if len(sys.argv) > 3 else 30
ab_ticks = int(sys.argv[4]) if len(sys.argv) > 4 else 40

B = dict(rows=480, cols=960, patches=1700, pop=10000,
         speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
         bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)

c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                    B["speed_max"], B["gain"], B["subdiv"], B["k"],
                    B["max_count"], B["rgm"],
                    bg_low_prod_frac=B["bg_low_prod_frac"],
                    bg_low_cap_mult=B["bg_low_cap_mult"])
c.simulation.use_sim_core = False
c.resource_dynamics.enabled = True
c.info_structure.memory_v2 = True
c.info_structure.memory_gradient = "orientation"
c.info_structure.memory_weight_gene = True
eng = SphereEngine(c)
apply_post_build(eng, notes)
print(f"预热到 t={warm} …", flush=True)
for _ in range(warm):
    eng.step()
N = len(eng._flat)
rf = eng.resources
rd = eng._rd
lt = rf.lt
print(f"N = {N}（t={warm}）", flush=True)

# ---------------- 装置事实 ----------------
print("—" * 72)
print("【装置事实】")
print(f"  rd.enabled={rd.enabled} bgzero={rd.bg_production_zero} rotate_moves_patch={rd.rotate_moves_patch}")
print(f"  distribution={rf.distribution} _lazy={rf._lazy} _sparse_fields={eng._sparse_fields}")
print(f"  temp_sensitivity={rf.temp_sensitivity} light_sensitivity={rf.light_sensitivity} "
      f"regrowth_rate={rf.regrowth_rate}")
print(f"  mults: patch={rf._patch_regrowth_mult} bg={rf._bg_regrowth_mult} "
      f"bglow={rf._bg_low_regrowth_mult}")
print(f"  rd mults: dead={rd.dead_regen_mult} rest={rd.rest_regen_mult} "
      f"kill_denom={rd.kill_denom} kill_frac={rd.kill_frac}")
print(f"  状态：dead={int(rd._dead.sum())} resting={int((rd._rest_until >= 0).sum())} "
      f"damage>=rest_thr={int((rd._damage >= rd.rest_threshold).sum())}", flush=True)

# ---------------- A. 逐段计时（class 级 patch） ----------------
S = {}          # name -> [calls, seconds]


def reg(name):
    def deco(fn):
        def wrap(*a, **k):
            t0 = time.perf_counter()
            try:
                return fn(*a, **k)
            finally:
                s = S.setdefault(name, [0, 0.0])
                s[0] += 1
                s[1] += time.perf_counter() - t0
        return wrap
    return deco


CAP_SITE = {}   # caller-lineno -> [calls, seconds]
_cap_vals = {"note_tick": None, "engine": None}
_cap_eq = [0, 0]   # [equal, total]

orig_cap = ResourceDynamics.capacity_from_base


def cap_wrapped(self, *a, **k):
    t0 = time.perf_counter()
    out = orig_cap(self, *a, **k)
    dt = time.perf_counter() - t0
    f = sys._getframe(1)
    ln = f.f_lineno
    nm = f.f_code.co_name
    key = f"{nm}:{ln}"
    s = CAP_SITE.setdefault(key, [0, 0.0])
    s[0] += 1
    s[1] += dt
    # B. 缓存等价性：note_tick 处（掩码=上一 tick 末）的值 应 == 上一 tick 引擎回写处的值
    if nm == "note_tick":
        if _cap_vals["engine"] is not None:
            _cap_eq[1] += 1
            if np.array_equal(out, _cap_vals["engine"]):
                _cap_eq[0] += 1
    elif nm == "_advance_one_tick":
        _cap_vals["engine"] = out.copy()
    return out


patches = [
    (ResourceField, "_regrowth_amount", "regrowth_amount"),
    (ResourceDynamics, "growth_multiplier", "growth_multiplier"),
    (ResourceDynamics, "note_tick", "note_tick"),
    (ResourceDynamics, "rotate", "rotate"),
    (ResourceDynamics, "_promote_same_row", "promote_same_row"),
    (LightAndTemperature, "temperature", "lt.temperature"),
    (LightAndTemperature, "_ensure_cache", "lt.ensure_cache"),
]
saved = []
for cls, name, label in patches:
    old = getattr(cls, name)
    saved.append((cls, name, old))
    setattr(cls, name, reg(label)(old))
ResourceDynamics.capacity_from_base = cap_wrapped

# note_tick 输入统计（eaten 占比）
NT = {"eaten_frac": [], "intake_max": []}
orig_nt = ResourceDynamics.note_tick


def nt_wrapped(self, intake, growth, tick):
    NT["eaten_frac"].append(float((intake > 0).mean()))
    NT["intake_max"].append(float(intake.max()))
    return orig_nt(self, intake, growth, tick)


ResourceDynamics.note_tick = nt_wrapped

print("—" * 72)
print(f"【A. 逐段计时】{timed_ticks} tick（class 级 patch；含嵌套，下附净值）")
eng.step()   # 热身
for _ in range(timed_ticks):
    eng.step()
for cls, name, old in saved:
    setattr(cls, name, old)
ResourceDynamics.capacity_from_base = orig_cap
ResourceDynamics.note_tick = orig_nt

print(f"  {'段':<22} {'次/t':>8} {'含嵌套ms/t':>10}")
for k in ["regrowth_amount", "growth_multiplier", "note_tick", "rotate",
          "capacity_from_base", "promote_same_row", "lt.temperature",
          "lt.ensure_cache"]:
    v = S.get(k)
    if v:
        print(f"  {k:<22} {v[0]/timed_ticks:>8.2f} {v[1]/timed_ticks*1e3:>10.2f}")
print("  capacity_from_base 调用点分账：")
for k, v in sorted(CAP_SITE.items(), key=lambda kv: -kv[1][1]):
    print(f"    {k:<34} {v[0]/timed_ticks:>6.2f} 次/t  {v[1]/timed_ticks*1e3:>7.2f} ms/t")
rg = S.get("regrowth_amount", [0, 0]); tp = S.get("lt.temperature", [0, 0])
ec = S.get("lt.ensure_cache", [0, 0])
print(f"  净值：regrowth 去 temperature 后 = {(rg[1]-tp[1])/timed_ticks*1e3:.2f} ms/t；"
      f"temperature 中 ensure_cache（每 tick 重建温度场）= {ec[1]/timed_ticks*1e3:.2f} ms/t")
print(f"  note_tick 输入：eaten 格占比 中位 {np.median(NT['eaten_frac'])*100:.2f}%；"
      f"intake.max 中位 {np.median(NT['intake_max']):.3f}")

# ---------------- B. capacity 合并等价性 ----------------
print("—" * 72)
print("【B. capacity 合并（低垂果实）等价性】")
print(f"  note_tick 处重算值 vs 上一 tick 引擎回写值：相等 {_cap_eq[0]}/{_cap_eq[1]} tick"
      f"（全等 ⇒ 缓存方案逐位可行）")
v = S.get("capacity_from_base")
if v:
    print(f"  ⇒ 省一次调用 = {v[1]/v[0]*1e3:.2f} ms/t（按当前单次成本）")

# ---------------- C. regrowth 子集链再评估 ----------------
print("—" * 72)
print("【C. regrowth 子集链（惰性）再评估】")
ok = rf.enable_lazy()
print(f"  enable_lazy() ⇒ {ok}（前提：patchy/temp_sens==1/light==0/倍率非负）")
if ok:
    idx = np.flatnonzero(rf._dirty_mask)
    print(f"  脏格占比 = {idx.size}/{rf.world.n_cells} = {idx.size/rf.world.n_cells*100:.2f}%"
          f"（growing 格；净格跳过 = 逐位 no-op）")
    tick_now = int(eng._tick)
    reps = 30
    t0 = time.perf_counter()
    for _ in range(reps):
        g_full = rf._regrowth_amount(tick_now)
    t_full = (time.perf_counter() - t0) / reps * 1e3
    t0 = time.perf_counter()
    for _ in range(reps):
        g_sub = rf._regrowth_amount(tick_now, idx)
    t_sub = (time.perf_counter() - t0) / reps * 1e3
    t0 = time.perf_counter()
    for _ in range(reps):
        _ = np.flatnonzero(rf._dirty_mask)
    t_scan = (time.perf_counter() - t0) / reps * 1e3
    same = np.array_equal(g_full[idx], g_sub)
    print(f"  子集逐位一致（全场[idx] == 子集）：{same}")
    print(f"  耗时：全场 {t_full:.2f} ms ｜ 子集 {t_sub:.2f} ms ＋ 掩码扫描 {t_scan:.2f} ms "
          f"⇒ 净省 {t_full - (t_sub + t_scan):.2f} ms/t")
    rf._lazy = False   # 复位（下面 A/B 用显式开关）

print(f"  深拷贝引擎做 {ab_ticks} tick 逐位 A/B（A=全场，B=惰性子集）…", flush=True)
eng_b = copy.deepcopy(eng)
ok_b = eng_b.resources.enable_lazy()
assert ok_b


def digest(e):
    h = hashlib.blake2b(digest_size=16)
    for arr in (e.resources._grid, e.resources._capacity, e._flat, e._genes,
                e.signals._marks, e._age, e._energy, np.array([e._tick])):
        h.update(np.ascontiguousarray(arr).tobytes())
    h.update(np.array([e._rd._dead.sum(), (e._rd._rest_until >= 0).sum(),
                       e._flat.size]).tobytes())
    return h.hexdigest()


div = None
tA = tB = 0.0
for k in range(ab_ticks):
    t0 = time.perf_counter(); eng.step(); tA += time.perf_counter() - t0
    t0 = time.perf_counter(); eng_b.step(); tB += time.perf_counter() - t0
    if digest(eng) != digest(eng_b):
        div = k
        break
if div is None:
    print(f"  A/B 逐位一致 ✓（{ab_ticks} tick 全等）")
else:
    print(f"  🔴 A/B 第 {div} tick 分裂！（需查前提）")
print(f"  配对墙钟：A(全场) {tA/ab_ticks*1e3:.1f} ms/t ｜ B(惰性) {tB/ab_ticks*1e3:.1f} ms/t "
      f"⇒ rd 段省 {tA/ab_ticks*1e3 - tB/ab_ticks*1e3:.2f} ms/t（本机并发负载下，比值参考）")

# ---------------- D. 微基准（其余纯算法候选） ----------------
print("—" * 72)
print("【D. 微基准（真实数组/形状）】")
n = rf.world.n_cells
grid = rf._grid
cap = rf._capacity
pm = rf._patch_mask
low = rf._bg_low_mask
prev = np.zeros(n, dtype=bool)


def bench(name, fn, rep=20):
    fn()
    t0 = time.perf_counter()
    for _ in range(rep):
        fn()
    dt = (time.perf_counter() - t0) / rep * 1e3
    print(f"  {name:<46} {dt:7.3f} ms/次")
    return dt


# D1: 温度因子链（clip + pow）
temps = lt.temperature(np.arange(n), int(eng._tick))
f1 = np.clip((temps + 20.0) / 20.0, 0.0, 1.0)
print(f"  D1 pow 跳过等价：np.array_equal(pow(f,1.0), f) = "
      f"{np.array_equal(np.power(f1, 1.0), f1)}（real factor 范围 "
      f"[{f1.min():.3f},{f1.max():.3f}]）")
t_clip = bench("clip((T+20)/20,0,1) 全场", lambda: np.clip((temps + 20.0) / 20.0, 0.0, 1.0))
t_pow = bench("np.power(factor, 1.0) 全场", lambda: np.power(f1, 1.0))
t_gather = bench("temperature 全场 gather（cache[arange]）", lambda: lt.temperature(np.arange(n), int(eng._tick)))

# D2: 三路 where → LUT
g = grid * 1.03
t_3way = bench("三路 where 再生倍率（现状）",
               lambda: np.where(pm, g * rf._patch_regrowth_mult,
                                np.where(low, g * rf._bg_low_regrowth_mult,
                                         g * rf._bg_regrowth_mult)))
lut = np.where(pm, rf._patch_regrowth_mult,
               np.where(low, rf._bg_low_regrowth_mult, rf._bg_regrowth_mult))
same = np.array_equal(
    np.where(pm, g * rf._patch_regrowth_mult,
             np.where(low, g * rf._bg_low_regrowth_mult, g * rf._bg_regrowth_mult)),
    g * lut)
t_lut = bench("预计算 LUT 后 1 次乘法", lambda: g * lut)
t_lut_build = bench("LUT 构建（掩码变才做）", lambda: np.where(pm, rf._patch_regrowth_mult,
                                                             np.where(low, rf._bg_low_regrowth_mult,
                                                                      rf._bg_regrowth_mult)))
print(f"  D2 LUT 逐位等价：{same}（构建 {t_lut_build:.3f} + 使用 {t_lut:.3f} vs {t_3way:.3f}/tick）")

# D3: ones 复用 + 扫描成本
t_ones = bench("np.ones(n) 分配", lambda: np.ones(n, dtype=np.float64))
t_restscan = bench("(_rest_until >= 0) 扫描", lambda: (rd._rest_until >= 0))
t_deadany = bench("dead.any() 扫描", lambda: rd._dead.any())
t_dmgscan = bench("(_damage >= rest_thr) 扫描", lambda: (rd._damage >= rd.rest_threshold))
t_rotate_seg = bench("rotate 等价扫描段（过期判定 3 算子）",
                     lambda: (rd._rest_until >= 0) & (~rd._dead) & (int(eng._tick) >= rd._rest_until))

# D4: growth_multiplier 现状成本（enabled 档）
t_gm = bench("growth_multiplier（现状）", lambda: rd.growth_multiplier())
print("完成。", flush=True)
