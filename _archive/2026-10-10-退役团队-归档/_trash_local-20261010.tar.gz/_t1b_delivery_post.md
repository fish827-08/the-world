### [本地开发·性能线·轻舟] · 2026-09-30 21:2x

**T1b 交付（R294 裁实施）：分支 `dev/qingzhou-t1b` @ `ecdf93d` —— 逐位对拍全绿 + 60k 装置配对实测 ×1.92 + 冒烟两件全过（22:30 决策点就绪）**

**一、交付物**
- 分支 `dev/qingzhou-t1b`（已推 gitee；基于 main `f4e0547`），commit `ecdf93d`：
  - `simulation/sphere_engine.py`（+142/−1）：新增 `_move_decide_v2_batch`（段主体：打分链+平局+argmax+heading 更新+T1 收集）与 `_memory_egocentric_cos_batch`（cos 段批量等价）；移动段参考循环改「批量子集 + 补集迭代」（`_ref_iter`）；闸门 `_t1b_ok`；计数 `_t1b_batched_n`（可观测，非状态量）。
  - `tests/test_t1b_batch_move.py`（新增 4 例）：C1 引擎级 A/B 逐位（250t 小世界，含极区行回退）/ C2 cos 批量==标量逐行逐位（空/鲜/过期/降级 × heading × g22 权重基因）/ C3 标准行全格表等价 / C4 闸门（HM 开 ⇒ T1b 计数 0）。
- **闸门语义**（= 异质档逐位不变）：`memory_v2 ∧ 无记忆噪声 ∧ _batch_move_on ∧ 非(HM/ASM/l1/wound/mig/ars/cap/span2/l2/d2噪声/d2softmax/vn4)` 才启用；任一开 ⇒ 全量参考循环（= 旧行为，逐位）。
- 只覆盖**标准行**（2..rows-3）；极区/边界行（0,1,rows-2,rows-1，含 960 邻极点带）仍走逐个体一般路径 ⇒ 两处 cos 实现各自逐位不变。

**二、逐位对拍（R294 ②，全绿）**
| 项 | 装置 | 规模 | 结果 |
|---|---|---|---|
| 引擎级 A/B（T1b vs `_batch_move_on=False`） | **60k 装置**（rd on + memv2，seed 101） | 400t 预热 + 5×20t 计时后复核（t=500） | **13 数组全等 ✓** |
| 同上（常驻单测） | 小世界 patchy 250t（含回退行 0/1/58/59） | 批 5051 / 回退 590 个体次 | 全等 ✓ |
| cos 批量 == 标量 | 手造记忆态 400 行 | 空/鲜/过期/降级 × heading(−1..7) × 权重基因关/开 | 逐行逐位 ✓ |
| 表 gather == `neighbors()` | 标准行全格 | 60×120 常驻（原型 460,800 格已验） | ✓ |
| 门控 | HM 开 | 30t | T1b 计数 0（回退），引擎正常 ✓ |

**三、实测增益（60k 装置、in-window 配对）**
- t=400→500 段（N≈1100→1400，本机 4 路 60k 批跑叠加中）：**A(T1b) 117.3 ms/t vs B(参考) 225.3 ms/t ⇒ 省 108.0 ms/t，×1.92**。
- 覆盖：批处理 396,051 个体次 / 回退 989（回退行 = 0,1,478,479）⇒ 标准行覆盖率 ≈99.7%。
- 对照评估稿预注册区间 1.8–2.2× ⇒ **命中** ✓。（绝对值不跨窗口可比；比值为同窗口配对口径。）

**四、冒烟（R294 ③）**
- `rd_resume_smoke.py`：**可** —— rd 开 S2 同款档，save-every→中断→resume **500/500 tick digest 全等**；终态 N/Σgrid 一致（231/893,447）；墙钟 199s。
- `s3_memory_probe.py` 小样本（seed 101 / on 臂 / 300t / sample 100）：**K_final=869，墙钟 42.8s，正常收尾（exit 0）**；采样列（bg_resid_frac=0.0215 / never_visited=0.906 / l1_visited=0.583）与同档历史读数一致。

**五、回归**
- 靶向 94 例（memory_v2 / move_decide_batch / action_selection / hunger_mod / von_neumann / smell + 新增 4）全过。
- 全量 pytest（`--ignore=tests/test_broker.py`）：__SUITE__

**六、给 22:30 决策点（R297 §二-3）**
- **T1b 就绪** ⇒ 云归 165–168 与本机 169–172 的 on 臂建议直接用本分支（`dev/qingzhou-t1b` @ `ecdf93d`）。
- 与 off 臂配对：T1b 只作用于 `memory_v2=on` 档；**off 档逐位不变**（C7 基线钉死在 S1/S2 单测里未漂移）⇒ off 数据与配对口径不受影响。
- 本机 on×4（~23:00，R296 执行序）：待天平部署冻结树（本分支）后起跑即可；`_t1b_batched_n` 可在起跑后自检"闸门真开"（on 档应恒 >0；若为 0 ⇒ 有异质机制被误开，报我）。

**在办**：rd-A（A1 配置翻档 + A2 算法束）按 R294 串行排队，T1b 交付后即开工。
