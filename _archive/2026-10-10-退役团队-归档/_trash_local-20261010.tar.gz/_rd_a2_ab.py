"""rd-A2 引擎级 A/B：同一脚本在两棵树各跑一次，逐 tick 全状态 digest 对拍。

用法（分别在树根目录运行，输出 JSONL）：
    <py> _trash_local/_rd_a2_ab.py --mode bgzero       --ticks 300 --out _trash_local/rd_a2_<tag>.jsonl
    <py> _trash_local/_rd_a2_ab.py --mode bgzero_sparse --ticks 300 --out ...
    <py> _trash_local/_rd_a2_ab.py --mode patchy_kill  --ticks 200 --out ...
    <py> _trash_local/_rd_a2_ab.py --mode mv2_kill     --ticks 200 --out ...
    <py> _trash_local/_rd_a2_ab.py --mode bgzero_snap  --ticks 120 --out ... --snap <npz>

比较：python _rd_a2_ab.py --compare A.jsonl B.jsonl
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys

import numpy as np


def sha(a) -> str:
    return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()


def _rng_sha(rng) -> str:
    st = rng.bit_generator.state
    return hashlib.sha256(
        json.dumps(st, sort_keys=True, default=str).encode()).hexdigest()


def digest(e) -> dict:
    n = e.world.n_cells
    rd = e._rd
    d = {
        "t": int(e.tick),
        "n": int(len(e._flat)),
        "flat": int(e._flat.sum()),
        "ids": int(e._id.sum()),
        "e": float(e._energy.sum()),
        "grid": sha(e.resources._grid),
        "cap": sha(e.resources._capacity),
        "pmask": sha(e.resources._patch_mask
                     if e.resources._patch_mask is not None
                     else np.zeros(n, dtype=bool)),
        "marks": sha(e.signals._marks),
        "age": sha(e.signals._age),
        "rd_mask": sha(rd._mask),
        "rd_dead": sha(rd._dead),
        "rd_rest": sha(rd._rest_until),
        "rd_dsince": sha(rd._dead_since),
        "rd_damage": sha(rd._damage),
        "rd_cnt": [int(rd.patch_kill_n), int(rd.patch_reborn_n),
                   int(rd.forced_reborn_n), int(rd.promote_n),
                   int(rd.rest_set_n)],
        "rd_rng": _rng_sha(rd._rng),
    }
    pc = getattr(e, "_patch_centroid", None)
    if pc is not None:
        d["centroid"] = sha(pc)
    return d


def _cfg(mode: str):
    from simulation.config import InfoStructureConfig, SimConfig
    c = SimConfig(seed=42)
    c.world.rows, c.world.cols = 60, 120
    c.population.initial_count = 300
    c.simulation.use_sim_core = False
    c.simulation.ticks = 10 ** 9
    c.resources.distribution = "patchy"
    c.resources.patch_count = 30
    c.resource_dynamics.enabled = True
    if mode in ("bgzero", "bgzero_sparse", "bgzero_snap",
                "bgzero_fast", "bgzero_fast_sparse",
                "bgzero_force", "bgzero_force_sparse"):
        c.resources.bg_production_zero = True
        c.resources.patch_regrowth_mult = 1.195
    if mode in ("bgzero_sparse", "bgzero_fast_sparse", "bgzero_force_sparse"):
        c.simulation.sparse_fields = True
    if mode in ("patchy_kill", "mv2_kill", "patchy_fast_bgzero"):
        c.resources.bg_production_zero = False
        c.predation.forage_tradeoff_k = 0.0
        c.population.max_count = 600
        if mode == "patchy_fast_bgzero":
            c.resources.bg_production_zero = True
            c.predation.forage_tradeoff_k = 0.0
    if mode in ("bgzero_fast", "bgzero_fast_sparse", "patchy_fast_bgzero"):
        # 快节奏 rd 参数：让 due（到期重生）/ force（反荒漠化闸）/ expired（休耕恢复）
        # 三条路径在短跑内真正触发（默认 dead_regen_ticks=2000 在 2000 tick 内只差 1 tick 触发）
        c.resource_dynamics.dead_regen_ticks = 40
        c.resource_dynamics.rest_ticks = 20
        c.resource_dynamics.dead_cell_max_frac = 0.01
    if mode in ("bgzero_force", "bgzero_force_sparse"):
        # 隔离 force 路径：死格永不自然到期（regen=2000）+ 闸阈极低 ⇒ 强制重生密集触发
        c.resource_dynamics.dead_regen_ticks = 2000
        c.resource_dynamics.rest_ticks = 20
        c.resource_dynamics.dead_cell_max_frac = 0.0005
        if mode == "bgzero_force_sparse":
            c.simulation.sparse_fields = True
    if mode == "mv2_kill":
        c.info_structure = InfoStructureConfig(
            enabled=True, learning_rate=0.05,
            memory_gradient="orientation",
            memory_v2=True,
            memory_dist_scale=15.0,
            memory_degrade_thr=20.0,
            memory_coarse_gain=0.15,
            memory_ttl=1000,
            memory_v2_dynamic_centroid=True,
        )
        c.organisms.young_mob_mult = 0.55
        c.organisms.old_mob_mult = 0.55
        c.organisms.far_cap = 32
        c.organisms.max_energy = 600.0
        c.organisms.initial_energy = 300.0
        c.organisms.starve_frac = 0.30
        c.organisms.exhaust_frac = 0.17
    return c


def _inject_kill(e) -> int:
    """确定性击杀注入：前 8 个斑块格被吃 10× 容量 ⇒ 走补充通道（两树同调用）。"""
    rd = e._rd
    cells = np.flatnonzero(rd._mask)[:8]
    if cells.size == 0:
        return 0
    intake = np.zeros(e.world.n_cells, dtype=np.float64)
    intake[cells] = 10.0 * np.asarray(rd.capacity_from_base())[cells]
    rd.note_tick(intake, np.ones(e.world.n_cells, dtype=np.float64), int(e.tick))
    return int(cells.size)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", required=False)
    ap.add_argument("--ticks", type=int, default=300)
    ap.add_argument("--out", required=False)
    ap.add_argument("--snap", default=None)
    ap.add_argument("--compare", nargs=2, default=None)
    args = ap.parse_args()

    if args.compare:
        a = [json.loads(x) for x in open(args.compare[0], encoding="utf-8")]
        b = [json.loads(x) for x in open(args.compare[1], encoding="utf-8")]
        if len(a) != len(b):
            print(f"LEN DIFF: {len(a)} vs {len(b)}")
        for i, (x, y) in enumerate(zip(a, b)):
            if x != y:
                ka = [k for k in x if x[k] != y.get(k)]
                print(f"FIRST DIVERGENCE at t={x.get('t')}: keys={ka}")
                for k in ka:
                    print(f"  {k}: A={x[k]}  B={y[k]}")
                return 1
        print(f"IDENTICAL: {len(a)} ticks, all digests bitwise equal")
        return 0

    from simulation.sphere_engine import SphereEngine

    cfg = _cfg(args.mode)
    e = SphereEngine(cfg)
    lines = []

    def emit(tag: str):
        d = digest(e)
        d["tag"] = tag
        lines.append(json.dumps(d, sort_keys=True))

    if args.mode in ("patchy_kill", "mv2_kill"):
        k = _inject_kill(e)
        print(f"# injected kill on {k} patch cells", file=sys.stderr)

    if args.mode == "bgzero_snap":
        half = args.ticks // 2
        for _ in range(half):
            if e.extinct:
                break
            e.step()
        emit("pre")
        e.save_snapshot(args.snap)
        e = SphereEngine.load_snapshot(args.snap, cfg)
        emit("loaded")
        for _ in range(args.ticks - half):
            if e.extinct:
                break
            e.step()
            emit("post")
    else:
        emit("init")
        for _ in range(args.ticks):
            if e.extinct:
                break
            e.step()
            emit("t")

    with open(args.out, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(f"# mode={args.mode} ticks={e.tick} extinct={e.extinct} "
          f"promote_n={e._rd.promote_n} kill_n={e._rd.patch_kill_n} "
          f"lines={len(lines)} -> {args.out}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
