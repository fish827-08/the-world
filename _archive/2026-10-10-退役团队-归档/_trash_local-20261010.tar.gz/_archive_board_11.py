# -*- coding: utf-8 -*-
"""第 11 轮讨论板归档（AGENT.md §3.3）。

默认 dry-run：只打印分界统计。
--apply：写新板 + 写 archive 文件（新板头取自 _trash_local/_board_head_new.md）。
"""
import os
import re
import sys

ROOT = r"C:\Users\圣羽\Desktop\temp\tempCode\the-world"
BOARD = os.path.join(ROOT, "_share", "讨论板.md")
ARCH_DIR = os.path.join(ROOT, "_share", "archive")
ARCH = os.path.join(ARCH_DIR, "讨论板-20261001.md")
HEAD = os.path.join(ROOT, "_trash_local", "_board_head_new.md")
KEEP_BYTES = 150_000
APPLY = "--apply" in sys.argv

text = open(BOARD, encoding="utf-8").read()
lines = text.split("\n")
pat = re.compile(r"^### \[")
pin_end = next(i for i, l in enumerate(lines) if "PIN-END" in l)
first_post = next(i for i, l in enumerate(lines) if i > pin_end and pat.match(l))

blocks, cur = [], []
for l in lines[first_post:]:
    if pat.match(l) and cur:
        blocks.append(cur)
        cur = [l]
    else:
        cur.append(l)
if cur:
    blocks.append(cur)

def bsize(b):
    return len("\n".join(b).encode("utf-8"))

keep, used = [], 0
for b in reversed(blocks):
    s = bsize(b)
    if used + s > KEEP_BYTES:
        break
    keep.insert(0, b)
    used += s
arch = blocks[: len(blocks) - len(keep)]

print(f"总帖数 {len(blocks)}｜保留 {len(keep)}（{used} B）｜归档 {len(arch)}"
      f"（{sum(bsize(b) for b in arch)} B）")
print("保留起帖:", keep[0][0][:70] if keep else "(无)")
print("归档末帖:", arch[-1][0][:70] if arch else "(无)")
print("板原大小:", len(text.encode("utf-8")), "B")

if not APPLY:
    print("\n（dry-run，未写盘；加 --apply 执行）")
    sys.exit(0)

head = open(HEAD, encoding="utf-8").read().rstrip("\n")
body = "\n".join("\n".join(b) for b in keep).strip("\n")
new_board = head + "\n\n" + body + "\n"
open(BOARD, "w", encoding="utf-8", newline="\n").write(new_board)

os.makedirs(ARCH_DIR, exist_ok=True)
arch_head = (
    f"# 讨论板归档 · 第 11 轮\n\n"
    f"- **原文件**：`_share/讨论板.md`（同一会话，非独立会话）\n"
    f"- **归档范围**：自 2026-09-27 00:55（第十轮归档）起的全部帖子，"
    f"截至归档点前的最后一条（{arch[-1][0][:70] if arch else '—'}）\n"
    f"- **板面保留**：自「{keep[0][0][:70] if keep else '—'}」起，共 {len(keep)} 帖 / {used} B\n"
    f"- **依据**：`AGENT.md §3.3`（板面上限 200KB；本次归档前 {len(text.encode('utf-8'))} B）\n"
    f"- **归档即知**：默认不读；仅当引用链明确指向本区间时才回溯\n"
    f"- **执行**：`[所有者·天平]`，2026-10-01\n\n---\n\n"
)
arch_body = "\n".join("\n".join(b) for b in arch).strip("\n")
open(ARCH, "w", encoding="utf-8", newline="\n").write(arch_head + arch_body + "\n")

print("\n[apply] 新板:", len(new_board.encode("utf-8")), "B ⇒", BOARD)
print("[apply] 归档:", len((arch_head + arch_body).encode("utf-8")), "B ⇒", ARCH)
