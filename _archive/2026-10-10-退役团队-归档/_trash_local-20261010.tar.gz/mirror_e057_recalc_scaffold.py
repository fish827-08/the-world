# -*- coding: utf-8 -*-
"""E-057 rep_w 档扫批 独立复算脚手架（镜 · R394④ 独立脚本 · WIP 候数据）。

状态：**脚手架**，数据未落盘（32 run 云机批在途）。放 _trash_local（gitignored），
数据到齐→核真实 header/summary 键→按实际列名调 FIELD 表→转正 tools/mirror_e057_recalc.py。

R394④：纯 stdlib，**不 import** s3/e057_readout/引擎/任何我参与链路模块；只读原始 CSV+summary。

口径来源：预注册 E-057 @7605da1（PI 会签 @2306949 采纳 +8 同树锚臂）+ §五复算计划：
- index 式段切（PI 裁②）：k=int(0.25n)；F=首段窗1..k，L=末段窗(n-k+1)..n，**M=中段窗8..13**
  （n=20：中央6窗，floor(0.35n)..ceil(0.65n)−1 零基 → 7..12 → 一基第8..13窗）；
  P=max(窗1..n) 全窗，peak_gain=P−F；
- **K1 辅判（形态）**：peak_gain≥0.010 且 M≥F ⇒ 上升形态计数（档内仅形态描述+K2合理性核对，
  不单独判正；基线 7/8 命中=单档形态门无鉴别力）；
- **K2 主判据（配对差）**：Δ = (M−F)_E057档 − (M−F)_**同树锚臂 solo∧rep_w=0.0**（逐 seed 207–214 配对），
  某档 **Δ>0 计数 ≥4/5 seed 同向** ⇒ 该档 rep_w 抬升中段-首段差成立；
  **E-056 降为跨树核验列**（不作 K2 基线，只 sanity check 同树锚臂≈E-056）；旁证 Δpeak_gain 同向计数只报不判；
- K3 生态门（前置）：每档 ≥5/8 存活至 2000t + P3 pop_end≥6945（沿用）；不过门档 K1/K2 不可执行；
- §四-4 全 20 窗敏感性：主判据按锁定段（窗8-13），**双口径并报**（另给"中央对称窗窗7-14"敏感性列，
  若镜/砚提议改段可对照，但主判据仍锁定段）。

字段假设（数据到必核，见 §FIELD_VERIFY）：
"""
from __future__ import annotations
import argparse
import csv
import glob
import json
import math
import os
import re
import statistics

# ---- 段算子（口径核心，独立于字段名，可先自测）------------------------------------
def seg_stats(vals, mid_lo=8, mid_hi=13):
    """vals=逐窗 g15_mean 列表（1..n）。返回 F/M/L/peak/peak_gain/mid_minus_first。

    index 式：k=int(0.25n)；中段默认窗8..13（1基，闭区间），落表按 n 校验。
    """
    n = len(vals)
    k = int(0.25 * n)
    F = statistics.mean(vals[:k])
    L = statistics.mean(vals[-k:]) if k > 0 else float("nan")
    lo = max(0, mid_lo - 1)
    hi = min(n, mid_hi)
    M = statistics.mean(vals[lo:hi])
    P = max(vals)
    return {"n": n, "k": k, "F": F, "M": M, "L": L, "P": P,
            "peak_gain": P - F, "m_minus_f": M - F}


def k1_form(seg, delta_pk=0.010):
    """K1 形态辅判：peak_gain≥delta_pk 且 M≥F。"""
    return (seg["peak_gain"] >= delta_pk) and (seg["M"] >= seg["F"])


def k2_pair(arm_segs, anchor_segs, min_same=4, denom=5):
    """K2 主判据：某档逐 seed Δ=(M−F)_档−(M−F)_锚臂，Δ>0 计数 ≥min_same/denom 同向。

    arm_segs/anchor_segs: {seed: seg}。返回 (阳性 bool, 同向数, 逐 seed Δ)。
    """
    deltas = {}
    pos = 0
    for seed in sorted(arm_segs):
        if seed in anchor_segs:
            d = arm_segs[seed]["m_minus_f"] - anchor_segs[seed]["m_minus_f"]
            deltas[seed] = d
            if d > 0:
                pos += 1
    return pos >= min_same, pos, len(deltas), deltas


# ---- 字段核验占位（数据到填）------------------------------------------------------
FIELD_VERIFY = """
数据到齐首件事，核对并回填本表：
1) 32 run 文件命名 & 档/臂识别：e057_..._s{seed}_... 目录/后缀如何区分 solo∧0.0 锚臂 vs 三档？
2) CSV 列：g15_mean / g6_emit_events_window / g6_emit_person_ticks_cum / g5_dir_diff /
   g5_move_diff / g4_mem_bit_frac / pop / tick —— 逐一确认列名与 E-056 同构。
3) summary run 级：reputation_weight_effective（RPW-KNOB 键，@7605da1 锁定）/
   info_structure_enabled_effective / stop / emit_rate_first/last/ratio —— 用于按档分组+ solo 校验。
4) 锚臂 solo∧0.0 是否与三档同信息结构指纹（enabled=True 贯穿）⇒ 确认 K2 同树前提。
5) e057_readout.py（砚读数器）到位后：我独立读路与其交叉，报 max|Δ|（self-consistent 核验）。
"""


def _read_g15(fp):
    rows = list(csv.DictReader(open(fp, encoding="utf-8")))
    rows.sort(key=lambda r: int(float(r.get("tick", 0))))
    return [float(r["g15_mean"]) for r in rows], rows


def selftest():
    """合成 g15 序列验证段算子/K2 逻辑（无真数据即验核心正确性）。"""
    print("=== 自测（合成，不依赖真数据）===")
    # 上升中段：首段(窗1-5)0.50，中段(窗8-13)0.52，末段0.49；峰值放末段窗16(不污染F/M)
    v = ([0.50] * 7 + [0.52] * 6 + [0.49] * 7)
    v[15] = 0.53
    s = seg_stats(v, 8, 13)
    assert s["k"] == 5, s["k"]
    assert abs(s["F"] - 0.50) < 1e-9
    assert abs(s["M"] - 0.52) < 1e-9
    assert abs(s["peak_gain"] - (0.53 - 0.50)) < 1e-9
    assert k1_form(s) is True
    # K2：档普遍比锚臂中段-首段高 0.005 ⇒ 8/8 Δ>0 ⇒ 阳性
    arm = {str(207 + i): {"m_minus_f": 0.02} for i in range(8)}
    anc = {str(207 + i): {"m_minus_f": 0.015} for i in range(8)}
    ok, pos, nn, _ = k2_pair(arm, anc)
    assert ok and pos == 8 and nn == 8
    # K2 反例：档=锚臂 ⇒ Δ全0 ⇒ 非阳性
    ok2, pos2, _, _ = k2_pair(arm, arm)
    assert ok2 is False and pos2 == 0
    print("自测通过：seg_stats/k1_form/k2_pair 逻辑正确（index式k=5、中段8-13、峰差、配对≥4/5）。")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="")
    ap.add_argument("--selftest", action="store_true", default=True)
    a = ap.parse_args()
    selftest()
    if a.data and glob.glob(os.path.join(a.data, "*.csv")):
        print("\n[数据已就位] 但字段核验未回填 → 见 FIELD_VERIFY，先核 header 再实算：")
        print(FIELD_VERIFY)
    else:
        print("\n[候数据] 32 run 未落盘。数据到→回填 FIELD_VERIFY→按档/锚臂分组→跑 K1/K2/K3+双口径。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
