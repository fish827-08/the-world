# -*- coding: utf-8 -*-
"""T1b 部署自检：60k 装置下跑 3 tick，打印批量计数（>0 = T1b 生效）。
用法：在冻结树根目录执行  python _t1b_selfcheck.py"""
import sys
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine

c, notes = make_cfg(999, 480, 960, 1000, 1700, True,
                    0.125, 0.125, 80, 2.5, 30000, 1.195,
                    bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)
c.simulation.use_sim_core = False
c.resource_dynamics.enabled = True
c.info_structure.memory_v2 = True
c.info_structure.memory_gradient = "orientation"
eng = SphereEngine(c)
apply_post_build(eng, notes)
for _ in range(3):
    eng.step()
n = eng._t1b_batched_n
print(f"T1b batched_n = {n} =>", "生效 OK" if n > 0 else "未生效 (FAIL)")
sys.exit(0 if n > 0 else 1)
