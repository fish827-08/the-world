# 派生量抽奖核验：rd.bg_production_zero 派生自"第一个背景格"的容量倍率采样
#   b_mult = cap[~m][0] / base[~m][0]  —— 若首背景格恰是 bg_low 格 ⇒ b_mult=0.05
#   ⇒ rd.bg_production_zero=False ⇒ (a) sparse 构造期守卫会炸 (b) dead/rest_regen_mult 默认改 0.0
#   (c) rotate 搬移开关放行。逐 seed 报 b_mult / 派生值。
import sys
from pathlib import Path

WT = Path(r"C:\Users\圣羽\Desktop\temp\tempCode\_wt_lq_rd")
sys.path.insert(0, str(WT))

import numpy as np  # noqa: E402

from world.sphere_world import SphereWorld  # noqa: E402
from world.resource_field import ResourceField  # noqa: E402
from world.light_and_temperature import LightAndTemperature  # noqa: E402

ROWS, COLS = 480, 960
PATCHES = 1700
BG_LOW_FRAC, BG_LOW_MULT = 0.4, 0.05


def sample_b_mult(seed: int):
    world = SphereWorld(ROWS, COLS)
    n = world.n_cells
    lt = LightAndTemperature(world)
    rf = ResourceField(
        world, lt, capacity_per_area=40.0, regrowth_rate=0.01,
        temp_sensitivity=1.0, distribution="patchy", patch_count=PATCHES,
        patch_radius=2, patch_capacity_mult=3.0, patch_regrowth_mult=1.195,
        background_fill=0.1, initial_fill=0.5, patch_seed=seed,
        bg_production_zero=True, bg_low_prod_frac=BG_LOW_FRAC,
        bg_low_cap_mult=BG_LOW_MULT,
    )
    cap = rf._capacity
    m = rf._patch_mask
    base = world.cell_area(np.arange(n)) * 40.0
    b_mult = float(cap[~m][0] / base[~m][0])
    first_bg = int(np.flatnonzero(~m)[0])
    low = bool(rf._bg_low_mask[first_bg])
    return b_mult, low, int(m.sum())


print(f"{'seed':>5} {'b_mult':>7} {'first_bg_low':>12} {'派生bgzero':>10}")
flips = []
for s in range(42, 173):
    bm, low, nmask = sample_b_mult(s)
    derived = (bm == 0.0)
    if not derived:
        flips.append(s)
    if s <= 50 or s >= 160 or not derived:
        print(f"{s:>5} {bm:>7.3f} {str(low):>12} {str(derived):>10}")
print()
print(f"派生 bgzero=False（sparse 会被构造期守卫拒绝）的 seed 数：{len(flips)} / 131")
print("清单：", flips)
