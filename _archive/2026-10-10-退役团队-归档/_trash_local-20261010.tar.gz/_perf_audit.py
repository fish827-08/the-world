# -*- coding: utf-8 -*-
"""R290 性能审计：T1 后 memv2 on 臂整 tick 热点全分布（为'下沉 Rust 收益'量化）。"""
import sys, os, time, cProfile, pstats, io
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine

def build(seed, mem_on=True, weight_gene=False):
    B = dict(rows=480, cols=960, patches=1700, pop=10000,
             speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
             bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)
    c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                        B["speed_max"], B["gain"], B["subdiv"], B["k"], B["max_count"], B["rgm"],
                        bg_low_prod_frac=B["bg_low_prod_frac"], bg_low_cap_mult=B["bg_low_cap_mult"])
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = True
    c.info_structure.memory_v2 = bool(mem_on)
    c.info_structure.memory_gradient = "orientation" if mem_on else "none"
    if weight_gene:
        c.info_structure.memory_weight_gene = True
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    return eng

T = 250
arm = sys.argv[1] if len(sys.argv) > 1 else "on"
eng = build(104, mem_on=(arm == "on"), weight_gene=(arm == "on"))
for _ in range(50):
    eng.step()
N = getattr(eng, "_alive_count", None) or getattr(eng, "n_alive", "?")
pr = cProfile.Profile()
pr.enable()
t0 = time.perf_counter()
for _ in range(T):
    eng.step()
dt = time.perf_counter() - t0
pr.disable()
print(f"\n===== seed104 {arm} 臂，预热50 + 测量{T}t：{dt:.1f}s（{dt/T*1e3:.1f} ms/t）=====")
s = io.StringIO()
st = pstats.Stats(pr, stream=s)
st.sort_stats("tottime")
st.print_stats(28)
out = s.getvalue()
# 只保留函数行
for line in out.split("\n"):
    print(line)
