# -*- coding: utf-8 -*-
"""T1 前置验证：向量化方向量化 vs 标量 `_cell_dir_slot` 的**槽位级一致**。

用途：在改引擎（L1 cos 快路径 / L4 写路径向量化）之前，先钉死三件事：
  ① `float ** 0.5`（CPython float_pow） vs `np.sqrt` —— 全整数平方和值域穷举
  ② `unit @ u`（BLAS dgemv） vs 显式 ufunc 二项内积 / BLAS (8,2)@(2,m) / einsum
     —— 全 (dr,dcc) 箱穷举（该箱覆盖世界内一切可能 pair 的几何）
  ③ 候选端到端 vec_slot vs `_cell_dir_slot` —— 真实写路径 pair 样本（数组管道）
  ④ L1 常量（参考格构造） vs 标准行标量 —— 关键行 × 全列

判据：槽位级零 mismatch（槽位 = 写入 `_mem_az` 的整数 = 轨迹的全部信息）。
"""
import sys, os, time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine

B = dict(rows=480, cols=960, patches=1700, pop=10000,
         speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
         bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)


def build(seed):
    c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                        B["speed_max"], B["gain"], B["subdiv"], B["k"],
                        B["max_count"], B["rgm"],
                        bg_low_prod_frac=B["bg_low_prod_frac"],
                        bg_low_cap_mult=B["bg_low_cap_mult"])
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = True
    c.info_structure.memory_v2 = True
    c.info_structure.memory_gradient = "orientation"
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    return eng


def vec_slot(cur_arr, tar_arr, unit, cols, form="ufunc"):
    """候选：向量化方向量化（与 `_cell_dir_slot` 同式，只去解释器循环）。"""
    cur_arr = np.asarray(cur_arr, dtype=np.int64)
    tar_arr = np.asarray(tar_arr, dtype=np.int64)
    cr, cc = np.divmod(cur_arr, cols)
    tr, tc = np.divmod(tar_arr, cols)
    dr = (tr - cr).astype(np.float64)
    dcc = ((tc - cc).astype(np.float64) + cols / 2.0) % cols - cols / 2.0
    ln2 = dr * dr + dcc * dcc
    out = np.full(cur_arr.shape, -1, dtype=np.int64)
    ok = (cur_arr != tar_arr) & (ln2 >= 1e-12)
    if not ok.any():
        return out
    ln = np.sqrt(ln2[ok])
    u0 = dr[ok] / ln
    u1 = dcc[ok] / ln
    if form == "ufunc":
        sc = unit[:, 0][:, None] * u0[None, :] + unit[:, 1][:, None] * u1[None, :]
        out[ok] = np.argmax(sc, axis=0)
    elif form == "bt":
        sc = unit @ np.stack([u0, u1])                     # (8, m) BLAS dgemv
        out[ok] = np.argmax(sc, axis=0)
    elif form == "tb":
        sc = np.stack([u0, u1], axis=1) @ unit.T           # (m, 8) BLAS gemm
        out[ok] = np.argmax(sc, axis=1)
    elif form == "einsum":
        sc = np.einsum("ij,jk->ik", unit, np.stack([u0, u1]))
        out[ok] = np.argmax(sc, axis=0)
    else:
        raise ValueError(form)
    return out


def ulp_diff(a, b):
    ia = np.asarray(a, dtype=np.float64).view(np.int64)
    ib = np.asarray(b, dtype=np.float64).view(np.int64)
    return np.abs(ia - ib)


t_all = time.perf_counter()
print(f"numpy={np.__version__}  platform={sys.platform}", flush=True)
eng = build(104)
unit = eng._ars_unit
cols, rows = int(eng.world.cols), int(eng.world.rows)
print(f"engine ok：rows={rows} cols={cols} unit.shape={unit.shape}", flush=True)

# ── ① pow(0.5) vs sqrt —— 全整数平方和值域 ──────────────────────────────────
distinct = np.unique(
    (np.arange(0, rows)[:, None].astype(np.int64) ** 2
     + np.arange(0, cols // 2 + 1)[None, :].astype(np.int64) ** 2).ravel())
pow_vals = np.array([float(int(v)) ** 0.5 for v in distinct], dtype=np.float64)
sqrt_vals = np.sqrt(distinct.astype(np.float64))
ud = ulp_diff(pow_vals, sqrt_vals)
n_bad = int((ud > 0).sum())
print(f"\n① pow(0.5) vs sqrt：{distinct.size} 个值域点，ULP 不等 {n_bad} 个"
      f"（max ULP={int(ud.max())}）", flush=True)
if n_bad:
    i = int(np.flatnonzero(ud > 0)[0])
    print(f"   例：v={int(distinct[i])}  pow={pow_vals[i]!r}  sqrt={sqrt_vals[i]!r}", flush=True)

# ── ② / ③ 全 (dr,dcc) 箱穷举：m ≈ 92 万 pair ────────────────────────────────
dr_vals = np.concatenate([np.arange(0, rows, dtype=np.int64),
                          np.arange(-(rows - 1), 0, dtype=np.int64)])
dcc_vals = np.arange(-(cols // 2), cols // 2, dtype=np.int64)     # [-480, 479]
cur = np.empty(dr_vals.size * dcc_vals.size, dtype=np.int64)
tar = np.empty_like(cur)
for i, dr in enumerate(dr_vals):
    r0, r1 = (0, int(dr)) if dr >= 0 else (rows - 1, rows - 1 + int(dr))
    c0 = cols // 2
    base = i * dcc_vals.size
    cur[base:base + dcc_vals.size] = r0 * cols + c0
    tar[base:base + dcc_vals.size] = r1 * cols + (c0 + dcc_vals) % cols
print(f"\n② 箱穷举 pair 数 = {cur.size}", flush=True)

t0 = time.perf_counter()
ref = np.empty(cur.size, dtype=np.int64)
for i in range(cur.size):
    ref[i] = eng._cell_dir_slot(int(cur[i]), int(tar[i]))
print(f"   标量参考：{time.perf_counter()-t0:.1f}s", flush=True)

for form in ("ufunc", "bt", "tb", "einsum"):
    t0 = time.perf_counter()
    got = vec_slot(cur, tar, unit, cols, form)
    dt = time.perf_counter() - t0
    nm = int((got != ref).sum())
    print(f"   form={form:6s}: mismatch={nm}  用时 {dt*1e3:.0f} ms", flush=True)
    if nm:
        bad = np.flatnonzero(got != ref)[:3]
        for b in bad:
            print(f"      例 cur={int(cur[b])} tar={int(tar[b])} ref={int(ref[b])} got={int(got[b])}",
                  flush=True)

# ── ④ L1 常量 vs 标准行标量 ─────────────────────────────────────────────────
ref_cell = (rows // 2) * cols + cols // 2
nb_ref = np.asarray(eng.world.neighbors(ref_cell))
const8 = np.array([eng._cell_dir_slot(ref_cell, int(x)) for x in nb_ref], dtype=np.int64)
VN_IDX = list(eng.world._VON_NEUMANN_IDX)
const4 = const8[VN_IDX]
print(f"\n④ const8={const8.tolist()}  const4={const4.tolist()}"
      f"（期望 [0..7] / [1,3,4,6]）", flush=True)
for r in (1, 2, 3, 10, 239, 300, 476, 477, 478):
    m8 = m4 = 0
    for c in range(cols):
        cell = r * cols + c
        nb8 = np.asarray(eng.world.neighbors(cell))
        d8 = np.array([eng._cell_dir_slot(cell, int(x)) for x in nb8], dtype=np.int64)
        m8 += int((d8 != const8).sum())
        nb4 = eng.world.neighbors_von_neumann(cell)
        d4 = np.array([eng._cell_dir_slot(cell, int(x)) for x in nb4], dtype=np.int64)
        m4 += int((d4 != const4).sum())
    tag = "✅" if (m8 == 0 and m4 == 0) else "⬜(预期：边界行→回退)"
    print(f"   row {r:3d}: 8邻 mismatch={m8:5d}  4邻 mismatch={m4:5d}  {tag}", flush=True)
pole_nb = np.asarray(eng.world.neighbors(0))
print(f"   pole row0 nb len={pole_nb.size}（≠8/4 ⇒ 回退路径）", flush=True)

# ── ⑤ 真实写路径 pair 样本（数组管道 + 实际分布）────────────────────────────
n_sample = 0
n_bad_ufunc = n_bad_bt = 0
for t in range(1, 61):
    eng.step()
    if t % 5:
        continue
    cur_flat = eng._flat.astype(np.int64)
    ccell = eng._patch_centroid[cur_flat]
    ok = ccell >= 0
    if not ok.any():
        continue
    pc, pt = cur_flat[ok], ccell[ok].astype(np.int64)
    refs = np.array([eng._cell_dir_slot(int(a), int(b)) for a, b in zip(pc, pt)],
                    dtype=np.int64)
    n_sample += pc.size
    n_bad_ufunc += int((vec_slot(pc, pt, unit, cols, "ufunc") != refs).sum())
    n_bad_bt += int((vec_slot(pc, pt, unit, cols, "bt") != refs).sum())
print(f"\n⑤ 真实写路径 pair：{n_sample} 个（60 tick 采样），"
      f"ufunc mismatch={n_bad_ufunc}  bt mismatch={n_bad_bt}", flush=True)

# ── 性能 sanity：vec 两种形态的吞吐 ─────────────────────────────────────────
m = 700
rr = np.random.default_rng(0)
pc = rr.integers(0, rows * cols, m).astype(np.int64)
pt = rr.integers(0, rows * cols, m).astype(np.int64)
for form in ("ufunc", "bt"):
    t0 = time.perf_counter()
    for _ in range(200):
        vec_slot(pc, pt, unit, cols, form)
    print(f"   vec[{form}] m={m}: {(time.perf_counter()-t0)/200*1e6:.0f} µs/批"
          f"（{m} 行）", flush=True)
t0 = time.perf_counter()
for _ in range(200):
    for a, b in zip(pc[:50], pt[:50]):
        eng._cell_dir_slot(int(a), int(b))
print(f"   标量 50 行: {(time.perf_counter()-t0)/200*1e6:.0f} µs/批 ⇒ "
      f"单行 ∝ {(time.perf_counter()-t0)/200/50*1e6:.2f} µs", flush=True)

print(f"\n总用时 {time.perf_counter()-t_all:.1f}s", flush=True)
