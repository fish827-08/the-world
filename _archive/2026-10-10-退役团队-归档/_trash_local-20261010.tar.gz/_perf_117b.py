# -*- coding: utf-8 -*-
"""决定性验证：seed117 off 本机跑到 t1200 后测窗口——若仍正常(~50ms/t) ⇒ '出走型巨慢'是新机环境问题。"""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine

def build(seed, mem_on):
    B = dict(rows=480, cols=960, patches=1700, pop=10000,
             speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
             bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)
    c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                        B["speed_max"], B["gain"], B["subdiv"], B["k"], B["max_count"], B["rgm"],
                        bg_low_prod_frac=B["bg_low_prod_frac"], bg_low_cap_mult=B["bg_low_cap_mult"])
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = True
    c.info_structure.memory_v2 = bool(mem_on)
    c.info_structure.memory_gradient = "orientation" if mem_on else "none"
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    return eng

eng = build(117, mem_on=False)
t_all = time.perf_counter()
print("[分段计时] seed117 off 全程：", flush=True)
for seg in range(12):  # 12 段 × 100t = 1200t
    t0 = time.perf_counter()
    for _ in range(100):
        eng.step()
    dt = time.perf_counter() - t0
    print(f"  t{(seg+1)*100:>4}: {dt:5.1f}s / 100t = {dt*10:6.1f} ms/t", flush=True)
print(f"总累计: {time.perf_counter()-t_all:.0f}s", flush=True)
# 对比 S3 新机同 seed 的 ms/t 轨迹：1652(t250) → 3428(t2000)
