**[本地开发·性能线·轻舟] R328 甲案交付：from_field 直读显式 bg_production_zero（分支 dev/qingzhou-rd-bgzero）＋ A1 新档自检结论**

**一、交付内容**（分支 `dev/qingzhou-rd-bgzero` @ **786d2c4**〔已推 gitee，`ls-remote` 已对账〕，基 cd74452，3 文件）

1. `world/resource_dynamics.py::from_field`：背景产能倍率改**直读显式真值** `rfield.bg_production_zero`——显式 True ⇒ `b_mult = 0.0`（确定性"纯斑块/A 支"，不再看首格）；显式 False（均匀背景档）⇒ 保留原单格推断（该档背景均匀，首格即精确值 ⇒ 逐位兼容）。R300 抽奖根因（`cap[~m][0]` 单格反推）去除。
2. `tools/check_bg_lottery.py`：判据翻转——修复后**任何档**（含 0.4/0.05 旧档）都必须 0 例 B 支（"全图可产"）；非零档再现 B 例即报"抽奖回来了"并 rc=1。工具从"复现缺陷"转为"回归守卫"。
3. `tests/test_242_bg_low_prod.py`：+2 测试（8 既有 + 3 参数化 + 1 兼容例 = **12 用例**）。`test_from_field_no_lottery_band_world`（seed 42/43/44：42/43 = 原 R300 复现里"背景首格恰在带内"的 seed，44 = 首格在荒漠；修复后三者**一律** A 支，含"旧推断前置反证"断言——seed 表失效会显式报错）；`test_from_field_legacy_uniform_bg_keeps_inferred_mult`（显式 False 档仍单格推断且值与旧实现逐位相同）。

**二、证据**

① **靶向单测**：`pytest tests/test_242_bg_low_prod.py -q` ⇒ **12 passed**（含 4 新增用例）。

② **check_bg_lottery 复测**（修复后代码，同工具同参数三档）：
   - 旧档全池扫描 40–210（171 world，0.4/0.05）：修复前 **56/171 判成 B 支**（R325 已录名单 41,42,43,…,203,204）→ 修复后 **0/171**；
   - 旗舰旧档 165–172（8 world，R300 表口径）：修复前 A:165/166/168/169/171、B:167/170/172 → 修复后 **0/8 全 A**；
   - 现档 0.0/0.0（12 world）：0/12（恒 A，与修复前同）。
   ⇒ "抽奖消失"的可执行证明 = **同一工具、同一旧档参数，56 例 B 直接归零**。

③ **现档逐位零变化**（`_bgfix_bitwise.py` 同脚本两树各跑：main = 修复前 / _wt_lq_bgfix = 修复后；seed 201，rd 开，800 预热 + 1000 tick = 1800t；终态 17 键 digest = t/n/flat/ids/e_energy + grid/cap/pmask/marks/age + rd 五数组 + rd 计数器 + rd RNG 态）：
   - sparse 0 双档：main vs wt **digest 全同**；
   - sparse 1 双档：main vs wt **digest 全同**（且两树 sparse 均**真激活**：`sparse_engine=True / lazy=True`，见下）；
   - **附加**：sparse 0 vs sparse 1 四跑 digest 亦两两全同 ⇒ 新档（0.0/0.0 + rd 开）**sparse on/off 终态逐位等价**（1800t，独立进程各跑）。
   两树闸诊断均为 `rd_bgzero=True / rd_bg_mult=0.0`（新档背景全零 ⇒ 修复前后同值 = 零变化符合预期；旧档的"修复前抽奖 → 修复后恒 A"见 ②）。两树均无 `sim_core.so`（本机未构建 Rust 扩展，纯 Python 单路 ⇒ 不涉 云启 LT/.so 分岔）。

④ **全量 pytest 对账**（两树各一次全量，`-q --ignore=tests/test_broker.py`）：
   - main（修复前）：**60 failed / 1060 passed / 8 skipped**（534.6s）；
   - wt（修复后）：**60 failed / 1064 passed / 8 skipped**（540.1s）；
   - **FAILED 集合逐项 diff = 完全一致**（60 项，均为存量环境型：GBK/inspect/CLI 子进程类，与甲修复无关）；wt 恰 **+4 passed = 本次新增 4 用例全绿**；
   - `pytest tests/test_242_bg_low_prod.py` 单跑 ⇒ **12 passed**（2.4s）。
   （注：main 树全量跑时含 R330 修订〔`_tail_mean` n=3→20，现已由天平落为 d1c3da3/4059f24〕——该修订不碰甲案 3 文件、亦无单测钉死，对账结论不受影响。）

**三、A1 新档自检结论（随下批翻档就绪）**

`_bgfix_a1_selfcheck.py`（wt）：新档（s2 预设 480×960/1700 斑块/pop 10000/rgm 1.195 + rd 开 + 纯零背景）**sparse off vs on 双引擎同进程逐 tick digest 对拍 1050t**：
- **1050 tick 全程 digest 一致 ✓**（含构造态 t=0；digest = flat/grid/cap/marks/age/energy/stomach + rd 五数组 + rd 计数器）；
- 闸真开（fail-loud 断言）：on 臂 `_sparse_fields=True` + 资源 `_lazy=True` + 信号 `_sparse=True`；off 臂全关；两臂 `rd_bgzero=True b_mult=0.0`；
- 非空转证据：脏格非空 **1050/1050** tick、活跃信号格非空 **1050/1050** tick；
- CPU 软参考（本机高载，非静默口径）：on = off 的 **64.1%**（140.1 → 89.8 ms/t）；末态 N=3783 未灭绝。
- **翻档通道**：`experiments/s2_depletion_probe.py --sparse-fields` 旗标已在（R244 v1 通道，`--help` 已核）；**注意批跑命令/编排器须显式带该旗标**——当前 `_trash_local/_run_s2g2.py` 未见透传 sparse 旗标，起跑令时请确认加旗标（否则批跑=旧行为，A1 未生效、白丢稀疏收益〔静默档地板税 −72% 量级〕）。

**四、请裁**

1. 甲案验收（合 main；分支 `dev/qingzhou-rd-bgzero`，3 文件：靶向 12/12 + 旧档抽奖归零 + 现档逐位零变化 + 全量对账）。
2. A1 生效方式确认：批跑加 `--sparse-fields`（探针原生旗标）即可；是否需要我把旗标默认值/编排器一并处理，请示意。
   - 另：云启其四通道批问"是否随 A1 翻档"——按 R329 表，我理解的翻档范围 = **S2 判据② 批**；若欲含四通道批，需先补**含 smell 的** sparse 对拍（云启已列 ~2 run 计划），请起跑令时统一明示。

—— 轻舟 2026-10-02
