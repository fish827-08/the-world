# -*- coding: utf-8 -*-
"""长 seed（104）vs 留守型（101）per-tick 热点对比（off 臂 250 tick，cProfile）。"""
import sys, os, time, cProfile, pstats
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine

def build(seed, mem_on=False):
    B = dict(rows=480, cols=960, patches=1700, pop=10000,
             speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
             bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)
    c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                        B["speed_max"], B["gain"], B["subdiv"], B["k"], B["max_count"], B["rgm"],
                        bg_low_prod_frac=B["bg_low_prod_frac"], bg_low_cap_mult=B["bg_low_cap_mult"])
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = True
    c.info_structure.memory_v2 = bool(mem_on)
    c.info_structure.memory_gradient = "orientation" if mem_on else "none"
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    return eng

T = 250
for seed in (101, 104):
    eng = build(seed, mem_on=False)
    for _ in range(5):          # 预热，绕过启动期一次性成本
        eng.step()
    pr = cProfile.Profile()
    pr.enable()
    t0 = time.perf_counter()
    for _ in range(T):
        eng.step()
    dt = time.perf_counter() - t0
    pr.disable()
    print(f"\n===== seed {seed} off {T}t: {dt:.1f}s ({dt/T*1e3:.0f} ms/tick) =====")
    st = pstats.Stats(pr)
    st.sort_stats("tottime")
    st.print_stats(12)
