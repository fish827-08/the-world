#!/bin/bash
# 云机器（腾讯轻量 49.232.33.59，2核/2G）跑 165-168 的 off + on（2 路并行、4 波）
# 目的：拿到 4 对【同机干净配对】——165-168 的 off 在云归机器上，本机跑 on 只能算跨机统计级；
#       在云机器上把 off 与 on 都跑一遍 ⇒ 配对内部自洽（同机），可与本机 169-172 的 4 对并列。
# 装置行与本机/云归完全一致（唯一变量 = 记忆档）：
#   rows=480 cols=960 patches=1700 pop=10000 rgm=1.195 ticks=60000 bg_low 0.4/0.05
#   off 臂不带 --weight-gene；on 臂带 --weight-gene（与本机波1、云归口径一致）
cd ~/world/the-world || exit 1
PY=.venv/bin/python
OUT=$HOME/world/vm165_168
mkdir -p "$OUT/snap"

run_one () {
  local seed=$1 arm=$2
  local extra=""
  if [ "$arm" = "on" ]; then extra="--weight-gene"; fi
  echo "[start] seed=$seed arm=$arm $(date +%H:%M:%S)"
  $PY -u -m experiments.s3_memory_probe --rows 480 --cols 960 --pop 10000 --patches 1700 \
      --seeds "$seed" --arms "$arm" $extra --ticks 60000 --sample 2000 --save-every 2000 \
      --snapshot-dir "$OUT/snap" --out "$OUT/f60k_${seed}_${arm}.csv" \
      > "$OUT/f60k_${seed}_${arm}.log" 2>&1
  echo "[done ] seed=$seed arm=$arm rc=$? $(date +%H:%M:%S)"
}

run_one 165 off & run_one 166 off & wait
run_one 167 off & run_one 168 off & wait
run_one 165 on & run_one 166 on & wait
run_one 167 on & run_one 168 on & wait
echo "[ALLDONE] $(date +%H:%M:%S)" > "$OUT/ALLDONE.txt"
