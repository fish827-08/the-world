### [所有者·天平] · 2026-09-29 12:40

**R260 仓库大扫除：分支 19→2 + 陈旧草稿归档 + 巨石/结构优化立项**

**一、分支清理（fish 指示；先甄别后删除，历史零丢失）**
- **删除 12 个已合 main 分支**（提交全在 main 历史）：dev/13.4-wave1、corpse-health-s1、qingwu-a2a4、**qingwu-memv2**、terrain-s1/s2、yunqi-smell-v1、snap-shard、t2t3、work-13.8、**yunqui-r242-rebased**、**yunqui-s3-script**；
- **删除 7 个未合分支（先打归档 tag）**：qingwu-c3 / qingwu-t5 / predator-dash / work-p0.0-scale / yunqui-r240-step1 / r241-layers / rd-fix ⇒ tag `archive/<名>-<sha>` 已推 gitee（**任何历史可凭 tag 找回**）；
- **保留 2 个**：`main` + `yunqui-r242-geometry`（新机 S2 复现部署的 provenance 来源 `6957651`，S2 终判引用）；`github/*` 镜像分支不动（备份性质）；
- 本地删除 check-corpse-s1 / review-p0.0-scale；**gitee 分支 19 → 2**。

**二、轻舟记忆基因位（g22）验收声明**
- `79f60aa`（五步曲 + 乘子 2×g22 默认关 + S12 三例）**已在 main**（轻舟 smell 合并解禁后直推，**未走预验收——下不为例，分支交付验收流程重申**）；
- 天平补验收：代码审阅通过（五步曲齐 + fail-loud + 纪元登记跟随）；🔴 **运行时验证挂起**——sim_core 需重建，但工作区有轻舟在途改动（+511 行）不能编入 ⇒ **等轻舟提交后重编 + 跑注册表/接线/C7 测试**，完成前 S3.5 不开跑。

**三、巨石文件与项目结构：立项规划（不动手，等批跑间歇 + F-R9）**

| 巨石 | 现状 | 拆分方向 | 时机 |
|---|---|---|---|
| `simulation/sphere_engine.py` | **6250 行** | 按域拆：movement / memory_v2 / snapshot / signal / predation / 构造装配——**纯重构逐位等价**（C7 基线不动，拆后跑逐位对拍验证） | 轻舟完成记忆基因位+模式仲裁后，批跑间歇期 |
| `simulation/config.py` | 1626 行 | 子配置拆文件（单例 asdict 接口不变，§12.10） | 同上 |
| `AGENT.md` | 1107 行 | 细则（§7+ 时代纪要）下沉 `docs/`，主文件留纪律骨架 | 天平顺手 |

**四、陈旧草稿清理**
- `_trash_local`：467 文件/15MB → **316/7.6MB**（删 2 天前旧草稿 151 个；**全部内容先打包 `_archive/_trash_local-20260929.tar.gz`（4.4MB）**，零丢失）；
- `_rerun_logs` 313KB 保留（快照侧车在用）。

**五、纪律重申**：① 分支交付须等验收，禁直推 main（轻舟 g22 直推已记，下不为例）② 删分支必先甄别（已合直删/未合归档 tag）③ 大重构须批跑间歇 + 逐位对拍。
