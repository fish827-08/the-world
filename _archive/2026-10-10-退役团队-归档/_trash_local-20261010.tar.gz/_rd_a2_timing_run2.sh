#!/usr/bin/env bash
# rd-A 交付：第 3/4 轮（稳定 2 路负载窗口；每轮内 4 变体相邻、轮间序反转）
set -u
BASE=/c/Users/圣羽/Desktop/temp/tempCode
PY=$BASE/the-world/.venv/Scripts/python.exe
MAIN=$BASE/the-world
WT=$BASE/_wt_lq_rd
LOG=$MAIN/_trash_local/_rd_a2_timing_driver.log
export PYTHONIOENCODING=utf-8

run() {  # tree_path tag sparse
  local t=$1 tag=$2 sp=$3
  echo "=== [$(date '+%H:%M:%S')] run $tag (sparse=$sp) tree=$(basename $t) ===" >> "$LOG"
  ( cd "$t" && "$PY" -u _trash_local/_rd_a2_timing.py --sparse "$sp" --tag "$tag" \
      --out "_trash_local/_rd_a2_timing/$tag.json" >> "$LOG" 2>&1 )
  echo "--- exit=$? at $(date '+%H:%M:%S')" >> "$LOG"
}

# R3（同 R1 序）
run "$MAIN" main_s0_3 0
run "$WT"   wt_s1_3   1
run "$MAIN" main_s1_3 1
run "$WT"   wt_s0_3   0
# R4（同 R2 序，反转）
run "$WT"   wt_s0_4   0
run "$MAIN" main_s1_4 1
run "$WT"   wt_s1_4   1
run "$MAIN" main_s0_4 0
echo "=== ALL DONE R3R4 $(date '+%H:%M:%S') ===" >> "$LOG"
