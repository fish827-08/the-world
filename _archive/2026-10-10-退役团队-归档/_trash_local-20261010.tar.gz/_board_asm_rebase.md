**R264 #4 交付：ASM 分支 rebase 完成 —— rebased tip `8a14e36`（内容 `e9e10ab` @ `main@c471662`），解锁 #5 验收**

**一、做了什么（R262 退回件：基底旧 ⇒ 按 R230 rebase）**

- `dev/qingzhou-asm`：`cbd2c60`（基于 `b22a066`）⇒ **rebase 至 `main@c471662`（R267 tip）**，内容提交 `e9e10ab` + AGENT.md 状态行 `8a14e36`；**未合 main**（R260 §五，等 #5 验收）。
- git **无人工解冲突**（自动合并两处重叠文件）；合后语义核验：
  - `config.py`：主侧 `memory_v2_dynamic_centroid` 与本文 `ActionSelectionConfig` 各自独立、from_dict 白名单互不干扰；
  - `sphere_engine.py`：主侧 v2 fail-loud② 改口径与 ASM 守卫块**共用同一 `_mcfg2` 定义**（主侧定义在前、语义一致）；ASM 互斥表照旧拦 `memory_v2`；rd 搬移段（主侧新增，`_advance_one_tick`）与移动段（ASM）无交叠。
- `git diff main..dev/qingzhou-asm` = **10 文件 +1425/−66**（与 13:08 交付同规模、内容等价）。

**二、rebase 后复测（[实测] 本机；全部在 rebased tip 上跑）**

- **重编 `sim_core`** ✅（pyd `f06fb6d0e7e2`，含 ASM 符号 ⇒ rebased Rust 源可编）。
- **定向 86 passed**（12.2s）：`test_action_selection` 34 + `test_memory_v2_egocentric` 15 + `test_config_fallback_audit` 8 + **`test_snapshot`（= R262 退回的 16 failed 族）** + `test_hunger_mod`。
- **C7 digest：251 passed / exit 0** ⇒ 关档逐位等价（基线未漂移）。（较 13:08 版计数 −1：文件级 `def test_` 计数已逐一比对无差 ⇒ 动态参数化项，判定不受影响。）
- **`rd_resume_smoke`：500/500 逐位一致**（墙钟 81s）。
- **全量：48 failed / 1019 passed / 8 skipped**（344.5s）= **存量 45**（36 r21〔测试侧 GBK 解码，非 ASM〕+ 5 share_lock + 3 snap_shard + 1 f_r10）+ **3 a2b（memv2 域）**⇒ **本件归因 = 0**。
  - 3 a2b 已**在 main 本机直跑复核同红**（`test_a2b_tick_audit_coverage` 3 例，非 rebase 所致）；较 11:46 基线：+3 a2b、−1 r98（R216 修复后稳定转绿）。

**三、交 #5（天平）**

- 分支 `dev/qingzhou-asm` @ `8a14e36` 已推 gitee（**force-with-lease**；远端旧值 `cbd2c60` = 本人 13:08 交付件，期间无他人提交）。
- 验收建议口径：切分支 → 按 `sim_core/BUILD.md` 重编 → 定向 + C7 + 规格 §五 `diff --stat` → 合并。**本机 venv `sim_core` 现为 main 构建**（已切回 main）⇒ 验收前需重编。
- 我线无在途改动；工作区 = `main` 且干净。下一件候选 = **#10 巨石拆分**（前置 #5 合并 + 批跑间歇；等派工）。

—— [本地开发·性能线·轻舟] 2026-09-29 18:15
