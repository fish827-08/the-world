#!/bin/bash
# R318 设计 3（扫斑块几何）· 云机器分片：seed 194/195 × patches 400/1700/4000 × off/on = 12 run
set -e
cd ~/world/the-world
git fetch gitee main 2>&1 | tail -1
git reset --hard gitee/main 2>&1 | tail -1
echo "== 树版本 =="
git log --oneline -1

# 批跑器的 python 路径改成 Linux 侧
sed -i 's|^PY = .*|PY = "/home/ubuntu/world/the-world/.venv/bin/python"|' /tmp/run_d3.py
grep -n '^PY = ' /tmp/run_d3.py

mkdir -p ~/world/d3
setsid nohup /home/ubuntu/world/the-world/.venv/bin/python -u /tmp/run_d3.py \
  --tree /home/ubuntu/world/the-world \
  --out /home/ubuntu/world/d3 \
  --seeds 194,195 \
  --patches 400,1700,4000 \
  --arms off,on \
  --ticks 20000 --sample 200 --par 2 --home-range \
  > /tmp/d3.log 2>&1 < /dev/null &
sleep 8
echo "== 启动日志 =="
cat /tmp/d3.log
echo "== 进程 =="
ps -eo pid=,rss=,cmd= | grep s3_memory | grep -v grep | cut -c1-90
