#!/bin/bash
# LTO-1 接续器（R333）：等云启气味场批 ALLDONE ⇒ 自动起 LTO-1 双臂
# 让位条款（fish）：云机器有正事优先 ⇒ 本脚本起的进程可随时被中止
set -u
P=/home/ubuntu/world/the-world/.venv/bin/python
T=/home/ubuntu/world/lto1

echo "[lto1] 等待云启批完成 $(date)"
for i in $(seq 1 180); do
  if grep -q ALLDONE /tmp/sm4_off.log 2>/dev/null && grep -q ALLDONE /tmp/sm4_on.log 2>/dev/null; then
    echo "[lto1] 云启批 ALLDONE 检出（轮询 $i 次）"
    break
  fi
  sleep 60
done

# 建冻结树（最新 main）
cd /home/ubuntu/world/the-world || exit 1
git fetch gitee main 2>&1 | tail -1
rm -rf "$T"
mkdir -p "$T/results"
git archive gitee/main | tar -x -C "$T"
echo "[lto1] 冻结树已建 @ $(git rev-parse --short gitee/main)"

cd "$T" || exit 1
echo "[lto1] 起 LTO-1 双臂 $(date)"
setsid nohup "$P" -u -m experiments.s3_memory_probe \
  --rows 480 --cols 960 --pop 10000 --patches 1700 \
  --seeds 165 --arms off --ticks 300000 --sample 2000 --home-range \
  --out "$T/results/lto1_165_off.csv" > /tmp/lto1_off.log 2>&1 < /dev/null &
setsid nohup "$P" -u -m experiments.s3_memory_probe \
  --rows 480 --cols 960 --pop 10000 --patches 1700 \
  --seeds 165 --arms on --weight-gene --ticks 300000 --sample 2000 --home-range \
  --out "$T/results/lto1_165_on.csv" > /tmp/lto1_on.log 2>&1 < /dev/null &

sleep 25
echo -n "[lto1] 在跑进程数: "
ps -eo cmd= | grep s3_memory | grep -v grep | wc -l
echo "[lto1] 装置回显:"
head -2 /tmp/lto1_off.log | tail -1 | cut -c1-160
