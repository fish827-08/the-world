# -*- coding: utf-8 -*-
"""R317 设计 1 判读：r_kin（亲子）vs r_placebo（同格/邻近非亲缘）。

判据（预注册）：r_kin ≈ r_placebo ⇒ 行为差异全来自环境（支持"基因不分"）；
              r_kin >> r_placebo ≈ 0 ⇒ 存在遗传成分（但不是 g22）。
口径：活跃度 = move / (seen-1)（每次采样的累计位移），仅取 seen>=3 的个体。
"""
import csv
import glob
import os

import numpy as np

RNG = np.random.default_rng(0)
RES = "_rerun_logs/disp_20k_v2/results"


def load(p):
    with open(p, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def act(x):
    try:
        s = int(x["seen"])
        if s < 3:
            return None
        return float(x["move"]) / (s - 1)
    except Exception:
        return None


def pearson(a, b):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    if len(a) < 10:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


print("%-16s %8s %9s %8s %10s %8s" % ("run", "r_kin", "n_kin", "r_plac", "n_plac", "n_同格"))
for p in sorted(glob.glob(os.path.join(RES, "*.pairs.csv"))):
    tag = os.path.basename(p).replace("disp_", "").replace(".pairs.csv", "")
    rs = load(p)
    by_id = {x["id"]: x for x in rs}

    # --- r_kin ---
    ka, kb = [], []
    for x in rs:
        pid = x.get("parent", "-1")
        y = by_id.get(pid)
        if y is None:
            continue
        va, vb = act(x), act(y)
        if va is None or vb is None:
            continue
        ka.append(va)
        kb.append(vb)
    r_kin = pearson(ka, kb)

    # --- r_placebo：同出生格（或 ±3 格）内的非亲缘配对 ---
    groups = {}
    for x in rs:
        v = act(x)
        if v is None:
            continue
        try:
            k = (int(x["birth_r"]), int(x["birth_c"]))
        except Exception:
            continue
        groups.setdefault(k, []).append((int(x["id"]), v))
    pa, pb = [], []
    for k, lst in groups.items():
        if len(lst) < 2:
            continue
        ids = [t[0] for t in lst]
        idx = RNG.permutation(len(lst))
        for i in range(0, len(idx) - 1, 2):
            (i1, v1) = lst[idx[i]]
            (i2, v2) = lst[idx[i + 1]]
            # 排除亲缘对（互为亲子）
            p1 = by_id.get(str(i1), {}).get("parent")
            p2 = by_id.get(str(i2), {}).get("parent")
            if str(i1) == str(p2) or str(i2) == str(p1):
                continue
            pa.append(v1)
            pb.append(v2)
    r_plac = pearson(pa, pb)
    n_grp = sum(1 for lst in groups.values() if len(lst) >= 2)
    print("%-16s %8.3f %9d %8.3f %10d %8d"
          % (tag, r_kin, len(ka), r_plac, len(pa), n_grp))
