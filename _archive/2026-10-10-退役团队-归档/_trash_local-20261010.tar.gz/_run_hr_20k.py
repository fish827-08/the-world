# -*- coding: utf-8 -*-
"""R308 短批：个体活动范围（hr_*）+ g22 十桶直方图。

20k tick × 4 seed（189-192）× 2 臂（off → on），每波 4 路并行；
冻结树 `_rerun_logs/short_hr_20k`（@834bf43，含 R308 探针 v4）；
`--keep-ckpt` 保留终态快照（可离线复算个体分布）。
"""
import os
import subprocess
import time

ROOT = r"C:\Users\圣羽\Desktop\temp\tempCode\the-world"
TREE = os.path.join(ROOT, "_rerun_logs", "short_hr_20k")
PY = os.path.join(ROOT, ".venv", "Scripts", "python.exe")
OUT = os.path.join(TREE, "results")
SNAP = os.path.join(OUT, "snap")
os.makedirs(SNAP, exist_ok=True)
SEEDS = ["189", "190", "191", "192"]


def launch(arm, extra):
    ps = []
    for s in SEEDS:
        cmd = [PY, "-u", "-m", "experiments.s3_memory_probe",
               "--rows", "480", "--cols", "960", "--pop", "10000",
               "--patches", "1700", "--seeds", s, "--arms", arm,
               "--ticks", "20000", "--sample", "2000", "--save-every", "2000",
               "--home-range", "--keep-ckpt", "--snapshot-dir", SNAP,
               "--out", os.path.join(OUT, f"hr_{s}_{arm}.csv")] + extra
        logf = open(os.path.join(OUT, f"hr_{s}_{arm}.log"), "w", encoding="utf-8")
        p = subprocess.Popen(cmd, cwd=TREE, stdout=logf, stderr=subprocess.STDOUT)
        ps.append((s, p, logf))
        print(f"[spawn] {s}_{arm} pid={p.pid}", flush=True)
        time.sleep(3)
    while any(p.poll() is None for _, p, _ in ps):
        time.sleep(60)
        n = sum(1 for _, p, _ in ps if p.poll() is None)
        print(f"[mon] {time.strftime('%H:%M')} {arm} alive={n}", flush=True)
    for _, _, f in ps:
        f.close()


print("[wave] off 起跑", flush=True)
launch("off", [])
print(f"[wave] off 完成 {time.strftime('%H:%M')} ⇒ on 起跑", flush=True)
launch("on", ["--weight-gene"])
print(f"[ALLDONE] {time.strftime('%H:%M')}", flush=True)
