# -*- coding: utf-8 -*-
"""T1b 验收对拍：两版输出 CSV 逐列对比（排除 ms_per_tick —— 速度列本就不同）。
用法：python _t1b_bitcompare.py old.csv new.csv"""
import csv
import sys

EXCL = {"ms_per_tick", "wall_s"}


def load(path):
    return list(csv.DictReader(open(path, encoding="utf-8")))


def main():
    if len(sys.argv) < 3:
        print("用法: _t1b_bitcompare.py <old.csv> <new.csv>"); sys.exit(2)
    a, b = load(sys.argv[1]), load(sys.argv[2])
    if len(a) != len(b):
        print(f"🔴 行数不同: {len(a)} vs {len(b)}"); sys.exit(1)
    diffs = 0
    cols = list(a[0].keys())
    for i, (ra, rb) in enumerate(zip(a, b)):
        for k in cols:
            if k in EXCL:
                continue
            if ra.get(k) != rb.get(k):
                diffs += 1
                if diffs <= 12:
                    print(f"  行{i} [{ra.get('seed')}/{ra.get('arm')}/t={ra.get('tick')}] {k}: {ra.get(k)} vs {rb.get(k)}")
    print(f"对比完成：{len(a)} 行 × {len(cols)} 列；排除列 {EXCL}；差异数 = {diffs}")
    print("✅ 逐位一致（T1b 等价达标）" if diffs == 0 else "🔴 存在差异 —— 逐项核查")


if __name__ == "__main__":
    main()
