# -*- coding: utf-8 -*-
"""R294 本机并行衰减曲线实测（20:05）。

目的：判定「本机少量并行（2/3/4 路）能否承接 60k 分片（169-172）」。
方法：同 seed(189) 同工作量，N 路并行 vs 1 路基准，测每路墙钟（衰减系数）；
      + BLAS=1 环境变量对照（numpy 线程固定的影响）；
      + 6 路档复现现场（验证方法可靠性，现场 6 路曾衰减 5×）。
矩阵：off 800t × {1,2,3,4,6 路, 4路+BLAS1}；on 500t × {1,2,3,4 路, 4路+BLAS1}
输出：_trash_local/_parcurve/results.jsonl + 控制台逐档表格
"""
import json
import os
import subprocess
import time

ROOT = r"C:\Users\圣羽\Desktop\temp\tempCode\the-world"
PY = os.path.join(ROOT, ".venv", "Scripts", "python.exe")
DIR = os.path.join(ROOT, "_trash_local", "_parcurve")
os.makedirs(DIR, exist_ok=True)

BLAS1 = {
    "OMP_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "NUMEXPR_NUM_THREADS": "1",
    "VECLIB_MAXIMUM_THREADS": "1",
}

SEED = "189"
RESULT_FILE = os.path.join(DIR, "results.jsonl")


def measure(arm, ticks, nproc, blas1):
    tag = f"{arm}_{ticks}t_p{nproc}" + ("_b1" if blas1 else "")
    procs = []
    for i in range(nproc):
        env = os.environ.copy()
        if blas1:
            env.update(BLAS1)
        out = os.path.join(DIR, f"{tag}_{i}.csv")
        logf = open(os.path.join(DIR, f"{tag}_{i}.log"), "w", encoding="utf-8")
        cmd = [PY, "-u", "-m", "experiments.s3_memory_probe",
               "--seeds", SEED, "--arms", arm, "--ticks", str(ticks),
               "--sample", str(ticks), "--out", out]
        t0 = time.perf_counter()
        p = subprocess.Popen(cmd, cwd=ROOT, stdout=logf, stderr=subprocess.STDOUT, env=env)
        procs.append([p, logf, t0, None])
    # 独立记录每个进程的完成时刻
    remaining = set(range(nproc))
    while remaining:
        for i in list(remaining):
            p, logf, t0, _ = procs[i]
            if p.poll() is not None:
                procs[i][3] = time.perf_counter() - t0
                logf.close()
                remaining.discard(i)
        time.sleep(0.2)
    walls = [pr[3] for pr in procs]
    rcs = [pr[0].returncode for pr in procs]
    rec = {"tag": tag, "arm": arm, "ticks": ticks, "nproc": nproc, "blas1": blas1,
           "per_proc_wall_s": [round(w, 1) for w in walls],
           "max_wall_s": round(max(walls), 1), "rcs": rcs}
    with open(RESULT_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    print(f"[档完成] {tag}: 每路墙钟 {rec['per_proc_wall_s']}s rc={rcs}", flush=True)
    return rec


# 顺序：关键档优先（off×4 / on×4 先出），补细节档在后
MATRIX = [
    ("off", 800, 1, False),   # 基准
    ("off", 800, 4, False),   # 主判断：4 路
    ("on", 500, 1, False),    # on 基准
    ("on", 500, 4, False),    # 主判断：4 路
    ("off", 800, 2, False),
    ("off", 800, 3, False),
    ("on", 500, 2, False),
    ("on", 500, 3, False),
    ("off", 800, 6, False),   # 复现现场 6 路
    ("off", 800, 4, True),    # BLAS=1 对照
    ("on", 500, 4, True),
]

print(f"[开始] 共 {len(MATRIX)} 档，seed={SEED}", flush=True)
t_start = time.perf_counter()
for arm, ticks, nproc, b1 in MATRIX:
    print(f"[档启动] {arm} {ticks}t × {nproc} 路{'(BLAS1)' if b1 else ''} @ {time.strftime('%H:%M:%S')}", flush=True)
    measure(arm, ticks, nproc, b1)
print(f"[全部完成] 总耗时 {(time.perf_counter()-t_start)/60:.1f} 分钟", flush=True)

# ---- 汇总 ----
print("\n===== 汇总表 =====", flush=True)
recs = [json.loads(l) for l in open(RESULT_FILE, encoding="utf-8")]
base = {}
for r in recs:
    if r["nproc"] == 1 and not r["blas1"]:
        base[r["arm"]] = r["per_proc_wall_s"][0]
print(f"{'档':>16} {'每路墙钟(s)':>12} {'衰减×':>7} {'吞吐(核当量)':>12}")
for r in recs:
    if r["nproc"] == 1:
        continue
    b = base.get(r["arm"])
    slow = r["max_wall_s"] / b if b else float("nan")
    thr = r["nproc"] / slow
    name = f"{r['arm']}×{r['nproc']}" + ("+b1" if r["blas1"] else "")
    print(f"{name:>16} {r['max_wall_s']:>12.1f} {slow:>7.2f} {thr:>12.2f}", flush=True)
print("[done]", flush=True)
