# -*- coding: utf-8 -*-
"""T1 方向常量穷举验证：对全部格验证 dirs[j] == _dirs8_const[j]（Moore）/ VN4 常量。

结论决定 _memory_egocentric_cos 快路径的门（哪些行可用常量、哪些行必须走回退）。
理论预期：rows 2..rows-3 为标准区（rows 1 / rows-2 有极点钳制邻居、rows 0/rows-1 是极区整行）。
"""
import sys, os, time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine

B = dict(rows=480, cols=960, patches=1700, pop=10000,
         speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
         bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)


def build(seed, mem_on=True):
    c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                        B["speed_max"], B["gain"], B["subdiv"], B["k"],
                        B["max_count"], B["rgm"],
                        bg_low_prod_frac=B["bg_low_prod_frac"],
                        bg_low_cap_mult=B["bg_low_cap_mult"])
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = True
    c.info_structure.memory_v2 = bool(mem_on)
    c.info_structure.memory_gradient = "orientation" if mem_on else "none"
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    return eng


eng = build(104, True)
world = eng.world
cols, rows = world.cols, world.rows
ref = (rows // 2) * cols + cols // 2
nb_ref = np.asarray(world.neighbors(ref))
dirs8 = np.array([eng._cell_dir_slot(ref, int(x)) for x in nb_ref], dtype=np.int64)
print("参考格", ref, "nb_ref =", nb_ref)
print("dirs8_const =", dirs8.tolist())

nbv_ref = np.asarray(world.neighbors_von_neumann(ref))
dirs4 = np.array([eng._cell_dir_slot(ref, int(x)) for x in nbv_ref], dtype=np.int64)
print("dirs4_const (VN 序) =", dirs4.tolist(), " nbv_ref =", nbv_ref.tolist())

t0 = time.perf_counter()
bad8 = {}
bad4 = {}
lens = {}
for f in range(world.n_cells):
    row = f // cols
    nb = np.asarray(world.neighbors(f))
    lens[len(nb)] = lens.get(len(nb), 0) + 1
    if len(nb) == 8:
        for j in range(8):
            if int(eng._cell_dir_slot(f, int(nb[j]))) != int(dirs8[j]):
                bad8.setdefault(row, []).append((f, j))
                break
    if len(nb) == 4 or len(nb) == 8:
        nbv = np.asarray(world.neighbors_von_neumann(f))
        if len(nbv) == 4:
            for j in range(4):
                if int(eng._cell_dir_slot(f, int(nbv[j]))) != int(dirs4[j]):
                    bad4.setdefault(row, []).append((f, j))
                    break
        elif nbv.size != 8:
            bad4.setdefault(row, []).append((f, -1))
print(f"穷举耗时 {time.perf_counter()-t0:.1f}s")
print("len(nb) 分布:", lens)
print("Moore 8 常量失配行分布:", {r: len(v) for r, v in sorted(bad8.items())})
print("VN4 常量失配行分布:", {r: len(v) for r, v in sorted(bad4.items())})
for r in sorted(bad8):
    if bad8[r]:
        f, j = bad8[r][0]
        print(f"  例：row={r} flat={f} j={j} nb={np.asarray(world.neighbors(f)).tolist()}")
        break
# 额外：单格多邻时 dirs8 常量对标准行列还成立吗（取一个样本看值范围）
f_std = (rows // 3) * cols + 123
nb_std = np.asarray(world.neighbors(f_std))
print("标准格样本 dirs:", [eng._cell_dir_slot(f_std, int(x)) for x in nb_std], "nb=", nb_std.tolist())
# 极区格样本（rows-1 行）
f_pole = (rows - 1) * cols + 5
nb_pole = np.asarray(world.neighbors(f_pole))
print("极区格样本 len(nb) =", len(nb_pole), "前 6 个 nb =", nb_pole[:6].tolist())
print("极区格样本 dirs 前 12 =", [eng._cell_dir_slot(f_pole, int(x)) for x in nb_pole[:12]])
