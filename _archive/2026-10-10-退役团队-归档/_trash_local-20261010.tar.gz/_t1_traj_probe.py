# -*- coding: utf-8 -*-
"""T1 轨迹探针：on/off 两臂 500 tick 分块墙钟 + 人口（无计数器包裹，纯净成本）。"""
import sys, os, time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine

B = dict(rows=480, cols=960, patches=1700, pop=10000,
         speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
         bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)


def build(seed, mem_on):
    c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                        B["speed_max"], B["gain"], B["subdiv"], B["k"],
                        B["max_count"], B["rgm"],
                        bg_low_prod_frac=B["bg_low_prod_frac"],
                        bg_low_cap_mult=B["bg_low_cap_mult"])
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = True
    c.info_structure.memory_v2 = bool(mem_on)
    c.info_structure.memory_gradient = "orientation" if mem_on else "none"
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    return eng


BLOCK = 50
NBLK = 10
seed = int(sys.argv[1]) if len(sys.argv) > 1 else 104
for mem_on in (True, False):
    eng = build(seed, mem_on)
    print(f"\n===== seed {seed} arm={'on' if mem_on else 'off'} =====", flush=True)
    t_all = time.perf_counter()
    for b in range(NBLK):
        t0 = time.perf_counter()
        for _ in range(BLOCK):
            eng.step()
        dt = time.perf_counter() - t0
        n = len(eng._flat)
        print(f"  t{b*BLOCK+1:4d}-{(b+1)*BLOCK:4d}: {dt/BLOCK*1e3:7.1f} ms/t   N={n:5d}"
              f"   {dt/BLOCK*1e3/max(n,1)*1000:5.3f} µs/t·千人口", flush=True)
    print(f"  总: {time.perf_counter()-t_all:.1f}s", flush=True)
