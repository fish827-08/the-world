# -*- coding: utf-8 -*-
"""60k 本机分片编排器 v2（T1b 版冻结树）：169-172 全臂，on 先（关键路径）→ off 接力（自配对）。
装置 = T1b 验收后的冻结树（路径 TREE 在部署时确认）；产物落 results/。"""
import ctypes
import os
import subprocess
import sys
import time

ROOT = r"C:\Users\圣羽\Desktop\temp\tempCode\the-world"
TREE = os.path.join(ROOT, "_rerun_logs", "flagship60k_t1b")
PY = os.path.join(ROOT, ".venv", "Scripts", "python.exe")
OUT = os.path.join(TREE, "results")
SNAP = os.path.join(OUT, "snap")
os.makedirs(SNAP, exist_ok=True)

SEEDS = ["169", "170", "171", "172"]
BASE = ["--ticks", "60000", "--sample", "2000",
        "--save-every", "2000", "--snapshot-dir", SNAP]


def avail_gb():
    class M(ctypes.Structure):
        _fields_ = [("l", ctypes.c_ulong), ("load", ctypes.c_ulong),
                    ("tot", ctypes.c_ulonglong), ("avail", ctypes.c_ulonglong),
                    ("tp", ctypes.c_ulonglong), ("ap", ctypes.c_ulonglong),
                    ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong),
                    ("aev", ctypes.c_ulonglong)]
    m = M(); m.l = ctypes.sizeof(m)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
    return m.avail / 1024**3


def spawn(seed, arm):
    tag = f"{seed}_{arm}"
    logf = open(os.path.join(OUT, f"f60k_{tag}.log"), "w", encoding="utf-8")
    extra = ["--weight-gene"] if arm == "on" else []
    cmd = [PY, "-u", "-m", "experiments.s3_memory_probe", "--seeds", seed,
           "--arms", arm] + BASE + extra + \
          ["--out", os.path.join(OUT, f"f60k_{tag}.csv")]
    p = subprocess.Popen(cmd, cwd=TREE, stdout=logf, stderr=subprocess.STDOUT)
    print(f"[spawn] {tag} pid={p.pid} (avail={avail_gb():.1f}GB)", flush=True)
    return [p, logf]


def run_stage(arm, procs):
    """等该阶段全部完成"""
    while any(p.poll() is None for p, _ in procs):
        time.sleep(120)
        alive = sum(1 for p, _ in procs if p.poll() is None)
        print(f"[mon-{arm}] {time.strftime('%H:%M')} 存活 {alive}/{len(procs)} avail={avail_gb():.1f}GB", flush=True)
    for p, logf in procs:
        logf.close()
    rcs = [p.returncode for p, _ in procs]
    print(f"[stage-{arm} 完成] rc={rcs}", flush=True)
    return rcs


if __name__ == "__main__":
    print(f"[开始] 本机分片 v2（T1b 树）：on×4 关键路径优先", flush=True)
    on_procs = [spawn(s, "on") for s in SEEDS]
    time.sleep(50)
    print("[阶段 on] 装置行核验打开（人工）：见 results/f60k_169_on.log 首行", flush=True)
    rc_on = run_stage("on", on_procs)

    print(f"[接力] on 完成 ⇒ 起 off×4（自配对）", flush=True)
    off_procs = [spawn(s, "off") for s in SEEDS]
    rc_off = run_stage("off", off_procs)

    rc = any(r for r in (rc_on + rc_off))
    print(f"[all] 本机分片 v2 全部完成 rc={rc}", flush=True)
    sys.exit(1 if rc else 0)
