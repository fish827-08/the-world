# -*- coding: utf-8 -*-
"""接力：等波1（169-172 on）跑完 ⇒ 自动起波2（165-168 on，caa7cf2 树）。

波2 用修好的树（sample 级行落盘）⇒ 中途被打断也只丢未采样段；
与波1（184f68a）已对拍：36 列中唯一差异 = ms_per_tick（性能读数），科学列逐位一致。
"""
import ctypes
import os
import subprocess
import sys
import time

ROOT = r"C:\Users\圣羽\Desktop\temp\tempCode\the-world"
TREE = os.path.join(ROOT, "_rerun_logs", "flagship60k_on2")
PY = os.path.join(ROOT, ".venv", "Scripts", "python.exe")
OUT = os.path.join(TREE, "results")
SNAP = os.path.join(OUT, "snap")
os.makedirs(SNAP, exist_ok=True)

# 波1 的真解释器 PID（4 个 run）+ 编排器
WAVE1 = [8736, 23388, 5856, 21428, 9472]
SEEDS = ["165", "166", "167", "168"]

_k32 = ctypes.WinDLL("kernel32", use_last_error=True)
_Q = 0x1000  # PROCESS_QUERY_LIMITED_INFORMATION


def alive(pid):
    h = _k32.OpenProcess(_Q, False, pid)
    if h:
        _k32.CloseHandle(h)
        return True
    return False


print("[chain] 等待波1 结束（PID %s）" % WAVE1, flush=True)
while any(alive(p) for p in WAVE1):
    time.sleep(60)
print("[chain] 波1 已结束 ⇒ 起波2", flush=True)
time.sleep(10)

procs = []
for s in SEEDS:
    tag = f"{s}_on"
    logf = open(os.path.join(OUT, f"f60k_{tag}.log"), "w", encoding="utf-8")
    cmd = [PY, "-u", "-m", "experiments.s3_memory_probe", "--seeds", s, "--arms", "on",
           "--weight-gene", "--ticks", "60000", "--sample", "2000",
           "--save-every", "2000", "--snapshot-dir", SNAP,
           "--out", os.path.join(OUT, f"f60k_{tag}.csv")]
    p = subprocess.Popen(cmd, cwd=TREE, stdout=logf, stderr=subprocess.STDOUT)
    procs.append((tag, p, logf))
    print(f"[spawn] {tag} pid={p.pid}", flush=True)
    time.sleep(3)

print("[stage] on 波2（165-168）已起跑，进入监控（120s）", flush=True)
while any(p.poll() is None for _, p, _ in procs):
    time.sleep(120)
    al = [t for t, p, _ in procs if p.poll() is None]
    print(f"[mon] {time.strftime('%H:%M')} alive={len(al)}", flush=True)

rc = 0
for t, p, logf in procs:
    logf.close()
    print(f"[done] {t} rc={p.returncode}", flush=True)
    rc |= (p.returncode or 0)
print(f"[all] 波2 完成 rc={rc}", flush=True)
sys.exit(1 if rc else 0)
