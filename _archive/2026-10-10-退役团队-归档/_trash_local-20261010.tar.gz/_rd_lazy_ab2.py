# -*- coding: utf-8 -*-
"""R291 §四 派工 ①（补跑）：惰性子集 A/B（60k 装置、引擎级逐位）+ D 微基准。

v1 探针 `_rd_audit_probe.py` 已完成：段计时 / capacity 合并等价（30/30）/ 子集逐位一致；
但 C 的深拷贝 A/B 因 provenance `__getattr__` 递归崩溃、D 未跑。本补跑：
- C′：双引擎（同 seed 同装置，确定性 ⇒ 状态逐位可比）
      A = 全场路径（sparse 关，现状）｜B = `sparse_fields=True`（构造期即开，模拟"装置改配置"）
      预热 800 后逐位 digest；再 A/B 各 100 tick 逐 tick digest + **配对计时**（同窗口 ⇒ 负载抵消）。
- D：微基准（pow(x,1.0) 跳过 / 三路 where→LUT / 温度全量 gather / ones 复用 / 扫描）。

用法：PYTHONIOENCODING=utf-8 .venv/Scripts/python.exe _trash_local/_rd_lazy_ab2.py [seed] [warm] [ab_ticks]
⚠️ 本机在跑 60k 批跑 ⇒ 绝对 ms 偏大；一切比值/配对为主口径。
"""
import sys, os, time, hashlib

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from experiments.steady_k_probe import make_cfg, apply_post_build
from simulation.sphere_engine import SphereEngine

seed = int(sys.argv[1]) if len(sys.argv) > 1 else 101
warm = int(sys.argv[2]) if len(sys.argv) > 2 else 800
ab_ticks = int(sys.argv[3]) if len(sys.argv) > 3 else 100

B = dict(rows=480, cols=960, patches=1700, pop=10000,
         speed_max=0.125, gain=0.125, subdiv=80, k=2.5, max_count=30000, rgm=1.195,
         bg_low_prod_frac=0.4, bg_low_cap_mult=0.05)


def build(sparse_on):
    c, notes = make_cfg(seed, B["rows"], B["cols"], B["pop"], B["patches"], True,
                        B["speed_max"], B["gain"], B["subdiv"], B["k"],
                        B["max_count"], B["rgm"],
                        bg_low_prod_frac=B["bg_low_prod_frac"],
                        bg_low_cap_mult=B["bg_low_cap_mult"])
    c.simulation.use_sim_core = False
    c.resource_dynamics.enabled = True
    c.info_structure.memory_v2 = True
    c.info_structure.memory_gradient = "orientation"
    c.info_structure.memory_weight_gene = True
    if sparse_on:
        c.simulation.sparse_fields = True
    eng = SphereEngine(c)
    apply_post_build(eng, notes)
    return eng


def digest(e):
    h = hashlib.blake2b(digest_size=16)
    for arr in (e.resources._grid, e.resources._capacity, e.resources._patch_mask,
                e._flat, e._genes, e.signals._marks, e._age, e._energy,
                e._mem_az, e._mem_dist, e._mem_tick, e._rd._damage):
        h.update(np.ascontiguousarray(arr).tobytes())
    h.update(np.array([e._tick, e._rd._dead.sum(),
                       int((e._rd._rest_until >= 0).sum())]).tobytes())
    return h.hexdigest()


FIELDS = [("grid", lambda e: e.resources._grid),
          ("capacity", lambda e: e.resources._capacity),
          ("patch_mask", lambda e: e.resources._patch_mask),
          ("flat", lambda e: e._flat),
          ("genes", lambda e: e._genes),
          ("marks", lambda e: e.signals._marks),
          ("age", lambda e: e._age),
          ("energy", lambda e: e._energy),
          ("mem_az", lambda e: e._mem_az),
          ("mem_dist", lambda e: e._mem_dist),
          ("mem_tick", lambda e: e._mem_tick),
          ("damage", lambda e: e._rd._damage)]


def first_diff(e1, e2):
    for name, fn in FIELDS:
        a, b = fn(e1), fn(e2)
        if not np.array_equal(a, b):
            n = int((a != b).sum())
            return f"{name} 差异 {n}（首个 {np.flatnonzero((a != b).ravel())[:3]}）"
    return None


engA = build(False)
engB = build(True)
print(f"装置：A sparse=关（现旗舰档）｜B sparse=开"
      f"（_sparse_fields={engB._sparse_fields} resources._lazy={engB.resources._lazy} "
      f"signals._sparse={engB.signals._sparse}）", flush=True)
print(f"预热到 t={warm}（双引擎）…", flush=True)
for _ in range(warm):
    engA.step()
    engB.step()
print(f"N = {len(engA._flat)}｜B: N = {len(engB._flat)}", flush=True)
idxB = np.flatnonzero(engB.resources._dirty_mask)
print(f"B 脏格占比 = {idxB.size}/{engB.resources.world.n_cells} = "
      f"{idxB.size / engB.resources.world.n_cells * 100:.2f}%", flush=True)

dA, dB = digest(engA), digest(engB)
print(f"【t={warm} 逐位】A == B：{dA == dB}"
      + ("" if dA == dB else f"｜{first_diff(engA, engB)}"), flush=True)

print(f"【A/B 各 {ab_ticks} tick 逐位 + 配对计时】…", flush=True)
tA = tB = 0.0
div = None
for k in range(ab_ticks):
    t0 = time.perf_counter(); engA.step(); dtA = time.perf_counter() - t0
    t0 = time.perf_counter(); engB.step(); dtB = time.perf_counter() - t0
    tA += dtA; tB += dtB
    if digest(engA) != digest(engB):
        div = k
        break
if div is None:
    print(f"  逐 tick 逐位一致 ✓（{ab_ticks} tick 全等）", flush=True)
else:
    print(f"  🔴 第 {div} tick 分裂：{first_diff(engA, engB)}", flush=True)
print(f"  配对墙钟（本窗口）：A(全场) {tA / ab_ticks * 1e3:.1f} ms/t ｜ "
      f"B(惰性) {tB / ab_ticks * 1e3:.1f} ms/t ⇒ 装置级省 "
      f"{(tA - tB) / ab_ticks * 1e3:.2f} ms/t（同窗口配对，负载抵消）", flush=True)

# ---------------- D. 微基准（其余纯算法候选） ----------------
print("—" * 72)
print("【D. 微基准（真实数组/形状；同一负载窗口）】", flush=True)
rf = engA.resources
rd = engA._rd
lt = rf.lt
n = rf.world.n_cells


def bench(name, fn, rep=20):
    fn()
    t0 = time.perf_counter()
    for _ in range(rep):
        fn()
    dt = (time.perf_counter() - t0) / rep * 1e3
    print(f"  {name:<48} {dt:7.3f} ms/次", flush=True)
    return dt


temps = lt.temperature(np.arange(n), int(engA._tick))
f1 = np.clip((temps + 20.0) / 20.0, 0.0, 1.0)
print(f"  D1 pow 跳过等价：array_equal(pow(f,1.0), f) = "
      f"{np.array_equal(np.power(f1, 1.0), f1)}（real factor 范围 "
      f"[{f1.min():.3f},{f1.max():.3f}]）", flush=True)
bench("clip((T+20)/20,0,1) 全场", lambda: np.clip((temps + 20.0) / 20.0, 0.0, 1.0))
bench("np.power(factor, 1.0) 全场", lambda: np.power(f1, 1.0))
bench("temperature 全场 gather（cache[arange]）",
      lambda: lt.temperature(np.arange(n), int(engA._tick)))

g = rf._grid * 1.03
pm, low = rf._patch_mask, rf._bg_low_mask
t_3way = bench("三路 where 再生倍率（现状）",
               lambda: np.where(pm, g * rf._patch_regrowth_mult,
                                np.where(low, g * rf._bg_low_regrowth_mult,
                                         g * rf._bg_regrowth_mult)))
lut = np.where(pm, rf._patch_regrowth_mult,
               np.where(low, rf._bg_low_regrowth_mult, rf._bg_regrowth_mult))
same = np.array_equal(
    np.where(pm, g * rf._patch_regrowth_mult,
             np.where(low, g * rf._bg_low_regrowth_mult, g * rf._bg_regrowth_mult)),
    g * lut)
t_lut = bench("LUT 后 1 次乘法", lambda: g * lut)
bench("LUT 构建（掩码变才做）",
      lambda: np.where(pm, rf._patch_regrowth_mult,
                       np.where(low, rf._bg_low_regrowth_mult,
                                rf._bg_regrowth_mult)))
print(f"  D2 LUT 逐位等价：{same}", flush=True)

bench("np.ones(n) 分配", lambda: np.ones(n, dtype=np.float64))
bench("(_rest_until >= 0) 扫描", lambda: (rd._rest_until >= 0))
bench("dead.any() 扫描", lambda: rd._dead.any())
bench("(_damage >= rest_thr) 扫描", lambda: (rd._damage >= rd.rest_threshold))
bench("rotate 过期判定 3 算子",
      lambda: (rd._rest_until >= 0) & (~rd._dead)
      & (int(engA._tick) >= rd._rest_until))
bench("growth_multiplier（现状）", lambda: rd.growth_multiplier())
print("完成。", flush=True)
