# -*- coding: utf-8 -*-
"""R316 批跑：验证设计 1+2（行为可遗传性 + 队列消失率）。

装置 = 旗舰档（480×960 / 1700 斑块 / 10000 个体）；20 000 tick；采样间隔 200
（100 个采样点 ⇒ 99 个人·区间，够算 pooled 死亡率）。
seed 193–196（避开 42–100 已用区与 165–192）；双臂；on 臂带 --weight-gene。
两波各 4 路并行（本机实测甜蜜点 ≤4）。

产物：
  results/disp_<seed>_<arm>.csv        主表（含 hr_* 活动范围 + hr_dr_* 死亡率）
  results/disp_<seed>_<arm>.pairs.csv  存活个体活动量+父代 id（设计 1）
"""
import os
import subprocess
import time

ROOT = r"C:\Users\圣羽\Desktop\temp\tempCode\the-world"
TREE = os.path.join(ROOT, "_rerun_logs", "disp_20k")
OUT = os.path.join(TREE, "results")
PY = os.path.join(ROOT, ".venv", "Scripts", "python.exe")
SEEDS = [193, 194, 195, 196]
TICKS = 20000
SAMPLE = 200


def cmd(seed, arm):
    c = [PY, "-u", "-m", "experiments.s3_memory_probe",
         "--rows", "480", "--cols", "960", "--pop", "10000", "--patches", "1700",
         "--seeds", str(seed), "--arms", arm,
         "--ticks", str(TICKS), "--sample", str(SAMPLE),
         "--home-range", "--hr-pairs",
         "--out", os.path.join(OUT, "disp_%d_%s.csv" % (seed, arm))]
    if arm == "on":
        c += ["--weight-gene"]
    return c


def wave(arm):
    procs = []
    for s in SEEDS:
        log = open(os.path.join(OUT, "disp_%d_%s.log" % (s, arm)), "w",
                   encoding="utf-8")
        procs.append((s, subprocess.Popen(cmd(s, arm), cwd=TREE,
                                          stdout=log,
                                          stderr=subprocess.STDOUT)))
    print("[wave %s] 起跑 %d 路" % (arm, len(procs)), flush=True)
    bad = []
    for s, p in procs:
        rc = p.wait()
        print("[wave %s] seed=%d rc=%d" % (arm, s, rc), flush=True)
        if rc != 0:
            bad.append(s)
    return bad


def main():
    os.makedirs(OUT, exist_ok=True)
    t0 = time.time()
    print("=== R316 批：seed %s × 2 臂 × %d tick，sample=%d ==="
          % (SEEDS, TICKS, SAMPLE), flush=True)
    bad1 = wave("off")
    print("[wave off] 完成 %.1f min" % ((time.time() - t0) / 60), flush=True)
    t1 = time.time()
    bad2 = wave("on")
    print("[wave on] 完成 %.1f min" % ((time.time() - t1) / 60), flush=True)
    print("ALLDONE 总耗时 %.1f min，失败: off=%s on=%s"
          % ((time.time() - t0) / 60, bad1, bad2), flush=True)


if __name__ == "__main__":
    main()
